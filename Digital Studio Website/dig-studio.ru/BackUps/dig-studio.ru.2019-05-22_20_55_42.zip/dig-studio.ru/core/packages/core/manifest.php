<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '8fca322c6bc90533207500301097aeeb',
      'native_key' => 'core',
      'filename' => 'modNamespace/3646e9df7207ef8d63f61a48e81f3776.vehicle',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modWorkspace',
      'guid' => 'ba20e28008aa84b51068092a5d39639f',
      'native_key' => 1,
      'filename' => 'modWorkspace/0f1166e02c0e77a1196b45ea5b5959c6.vehicle',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modTransportProvider',
      'guid' => '39bb98a90114d9dc60e1ef3d581a6201',
      'native_key' => 1,
      'filename' => 'modTransportProvider/faa64f72591e61943484cfb679f7442b.vehicle',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '6db87f76604a8917c4b8dd9209f68836',
      'native_key' => 'topnav',
      'filename' => 'modMenu/b620e8535453d6e0b88d9dae56aa2330.vehicle',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '2344b7f91a7d8026886b55a8854bf2b1',
      'native_key' => 'usernav',
      'filename' => 'modMenu/3b99efa119e8248a33c54426abd6cb93.vehicle',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => 'cecc0f57f9f681e3c5f90296c511f04c',
      'native_key' => 1,
      'filename' => 'modContentType/0b4e0d463859a132fd6d12258dd84fe2.vehicle',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => '437175babd9929e16cf4fcf1a74ca124',
      'native_key' => 2,
      'filename' => 'modContentType/6b33397a37953871f079bcb48f967340.vehicle',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => '1d4b7b83b3ba9985ebd6765dc15b20b8',
      'native_key' => 3,
      'filename' => 'modContentType/a5b7d2796c40a41719d7faa5a7a1a6bf.vehicle',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => '19d065d7324d26635c724f00f6b30b5e',
      'native_key' => 4,
      'filename' => 'modContentType/15fe5a9dc43f4c65cce14c7e322b8297.vehicle',
    ),
    9 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => 'c4faca1622aad07b42893f06ad0c2d98',
      'native_key' => 5,
      'filename' => 'modContentType/a8bdc8ba224d526aa6b6d2ada654b761.vehicle',
    ),
    10 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => 'fc8979a422c0b0efeb06423465d79b8d',
      'native_key' => 6,
      'filename' => 'modContentType/05ff48099d5d82945a816ae64694c090.vehicle',
    ),
    11 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => '3464c7e32f10fd7532383c4a4d458c4d',
      'native_key' => 7,
      'filename' => 'modContentType/8a6929121d6f26441d02cda118f303b9.vehicle',
    ),
    12 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => 'a85c939dbe426e583f57b9c05be6ba97',
      'native_key' => 8,
      'filename' => 'modContentType/df3bfe73de18e81d180659bcf17dd3a5.vehicle',
    ),
    13 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => '1899c245d5b60be25f61bcd65c5a4fcb',
      'native_key' => NULL,
      'filename' => 'modClassMap/8cd8f5a438e24d74707f5f33d81d4856.vehicle',
    ),
    14 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => '4ae10733a4343457b3c3addc384b185f',
      'native_key' => NULL,
      'filename' => 'modClassMap/795998837df5ac6dec1fadb3244341cd.vehicle',
    ),
    15 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => '63d44af5fb97701c4fe718d7e7c27eae',
      'native_key' => NULL,
      'filename' => 'modClassMap/91ec8a30623771604467d176672332dd.vehicle',
    ),
    16 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => '6b45a1a72122aa72b0c6308f9df33c7a',
      'native_key' => NULL,
      'filename' => 'modClassMap/b3f836cfda5b398e8896f3fba0df5865.vehicle',
    ),
    17 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => '3c8f15d2e8493960731071d02376ae8c',
      'native_key' => NULL,
      'filename' => 'modClassMap/02fa7fb1b82e1705a982923ea916833a.vehicle',
    ),
    18 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => '0e3ba95926fba9e628b457d5ec5f7f3e',
      'native_key' => NULL,
      'filename' => 'modClassMap/5f188f83fefc4cedcabe8f90059bed86.vehicle',
    ),
    19 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => '5e343ad01022d7161c581fcb0268cdcc',
      'native_key' => NULL,
      'filename' => 'modClassMap/58fd3ef70a0264e493edb299872eedd7.vehicle',
    ),
    20 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => 'a071fd8b6101cd8b681605d98f329788',
      'native_key' => NULL,
      'filename' => 'modClassMap/949920f0dc842b3391678174cc64c43e.vehicle',
    ),
    21 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => '00d7c125375565537cd751d3556875c1',
      'native_key' => NULL,
      'filename' => 'modClassMap/401f9a6744df1ad0dacdcd26d579b165.vehicle',
    ),
    22 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '4bb281a7bd54af857e8dabb9f7ec8151',
      'native_key' => 'OnPluginEventBeforeSave',
      'filename' => 'modEvent/bc7e9156bda7f83da6a715a073be2faf.vehicle',
    ),
    23 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '394d099363c0b3dab552d54152c03aee',
      'native_key' => 'OnPluginEventSave',
      'filename' => 'modEvent/1138e0933626958364f7c92d82a3cfc7.vehicle',
    ),
    24 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '8fae9fce2d7cf32d2f835b942b08c212',
      'native_key' => 'OnPluginEventBeforeRemove',
      'filename' => 'modEvent/34e07aa8193663d63465e9dd72521d0d.vehicle',
    ),
    25 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '7a33bb8489d587ad40366858bb0b7f4b',
      'native_key' => 'OnPluginEventRemove',
      'filename' => 'modEvent/00ed45e1a58b28ca97709e399b0d473d.vehicle',
    ),
    26 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '34ec97568483bcc2d777e0fe56ad094c',
      'native_key' => 'OnResourceGroupSave',
      'filename' => 'modEvent/d5fe9a015b2587f18e6540bfcfe84a52.vehicle',
    ),
    27 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '60e6b84b84e1d706dfe7fdb8c31359fb',
      'native_key' => 'OnResourceGroupBeforeSave',
      'filename' => 'modEvent/0475ed6444d72fe47e88688d5e326918.vehicle',
    ),
    28 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '18c2a73f40f4b79e1759b777d1c40e77',
      'native_key' => 'OnResourceGroupRemove',
      'filename' => 'modEvent/5a1c5069ef1a79e776065e74241719eb.vehicle',
    ),
    29 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '26cfe540e2df00a7a538745540dc668e',
      'native_key' => 'OnResourceGroupBeforeRemove',
      'filename' => 'modEvent/2149547e0138fd6d5bcbfefe9f27beaf.vehicle',
    ),
    30 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2d4fda7f54859f5a10eb7968496c21f1',
      'native_key' => 'OnSnippetBeforeSave',
      'filename' => 'modEvent/f47a6dbc2c41f87e119cefd8fde714bd.vehicle',
    ),
    31 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '8291920506b5aacf55bb90be14a572f4',
      'native_key' => 'OnSnippetSave',
      'filename' => 'modEvent/3f79e1cf0f78f8c62c30d41b3383205b.vehicle',
    ),
    32 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '63912065824e83d0ab7c8d06cd41b0af',
      'native_key' => 'OnSnippetBeforeRemove',
      'filename' => 'modEvent/ef0a26909e16b526e7b72882287a7413.vehicle',
    ),
    33 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '0912d5a67b7b2cacd105403d129d58b1',
      'native_key' => 'OnSnippetRemove',
      'filename' => 'modEvent/29ab352be955430a3413e27c08fdc6bc.vehicle',
    ),
    34 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '1ae7c1d50a0fec4ca37b9ea697746458',
      'native_key' => 'OnSnipFormPrerender',
      'filename' => 'modEvent/2e7f5d5aef0f31b1da540eae99d8426c.vehicle',
    ),
    35 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e77606ddfb3c7664adebbf2d475fb778',
      'native_key' => 'OnSnipFormRender',
      'filename' => 'modEvent/2b19c196ff429e87a166abf99ec0292c.vehicle',
    ),
    36 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '90e58b5c8d068098149ceba25072270b',
      'native_key' => 'OnBeforeSnipFormSave',
      'filename' => 'modEvent/c3ff2677fdd82f918e967d041bb03b9d.vehicle',
    ),
    37 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a4cc6bc911d7b88995360df3614ed058',
      'native_key' => 'OnSnipFormSave',
      'filename' => 'modEvent/cf78ef8a8564eef71e697186329c43cb.vehicle',
    ),
    38 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '6c2fa01395dead3afcc7be375d937d92',
      'native_key' => 'OnBeforeSnipFormDelete',
      'filename' => 'modEvent/f99e35361ce7923079687f6a4117d1f2.vehicle',
    ),
    39 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'fa525ccb3502b4b56b51a291ad2a6be8',
      'native_key' => 'OnSnipFormDelete',
      'filename' => 'modEvent/49ddd53a6f57e843b7c97553bb57e2c8.vehicle',
    ),
    40 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '474517e23810e9d1f50f7defe2f2d9f6',
      'native_key' => 'OnTemplateBeforeSave',
      'filename' => 'modEvent/0e343152b880529ebe87504a4e7f5b64.vehicle',
    ),
    41 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '44d77c19e9f80c0cd50b148d15d959d1',
      'native_key' => 'OnTemplateSave',
      'filename' => 'modEvent/2be67cf5f0f23e94966889b0d69e85d5.vehicle',
    ),
    42 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '87c7e229d182f4bcd5ad9a48b98a4cc5',
      'native_key' => 'OnTemplateBeforeRemove',
      'filename' => 'modEvent/a55437fb1948102911333218b7f69d4c.vehicle',
    ),
    43 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '38076417ec893f6aece1da7e1add89f3',
      'native_key' => 'OnTemplateRemove',
      'filename' => 'modEvent/337f227677d1c0696a07ecca0d347910.vehicle',
    ),
    44 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '966f56d3f5f6c527621dbf9747492090',
      'native_key' => 'OnTempFormPrerender',
      'filename' => 'modEvent/16d44e602492d7b400008b3a635f3ae9.vehicle',
    ),
    45 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '0567e5d573d4cf1834ad73527d5a0b92',
      'native_key' => 'OnTempFormRender',
      'filename' => 'modEvent/618f97c33221383f2ffe01315f96f484.vehicle',
    ),
    46 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a1b83174c19b331389bc5cab3cbe9f42',
      'native_key' => 'OnBeforeTempFormSave',
      'filename' => 'modEvent/8ba264a91555295759132c8342dea112.vehicle',
    ),
    47 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '274467012a0557858af95df80d5eb742',
      'native_key' => 'OnTempFormSave',
      'filename' => 'modEvent/e972fac3efb45f96a9b350ef6327a5e9.vehicle',
    ),
    48 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'afab9223352f5a88185ebc4397ceae45',
      'native_key' => 'OnBeforeTempFormDelete',
      'filename' => 'modEvent/0a1aa8c17c42099b406fef49611b29a6.vehicle',
    ),
    49 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '197de6d63a186e317ced5fa34bba58e4',
      'native_key' => 'OnTempFormDelete',
      'filename' => 'modEvent/8cf5c9fd862b479db3898639453fdc28.vehicle',
    ),
    50 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'cd20c6cb815dc25f3200964ac24838a6',
      'native_key' => 'OnTemplateVarBeforeSave',
      'filename' => 'modEvent/d3a77b9a8e1904aeeacb2c9da52e360f.vehicle',
    ),
    51 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5fb679a2e1963b5c2f920a62ef77b178',
      'native_key' => 'OnTemplateVarSave',
      'filename' => 'modEvent/424cb7f996db2badcc47ee826e0b0689.vehicle',
    ),
    52 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd3f478c7e1c615a9db6c3b915e6b1020',
      'native_key' => 'OnTemplateVarBeforeRemove',
      'filename' => 'modEvent/d27a0c174773aa12bac8ff691733386b.vehicle',
    ),
    53 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '415a7e95bf63c9414078bcffc4d83954',
      'native_key' => 'OnTemplateVarRemove',
      'filename' => 'modEvent/b39fb1cb563173e5084860ca121fe3e0.vehicle',
    ),
    54 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2026c8006fcd3912edbc72f29aea5588',
      'native_key' => 'OnTVFormPrerender',
      'filename' => 'modEvent/e5a4781e1c727a74290e95ee3d3bfa75.vehicle',
    ),
    55 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '1937aa7eca449c42a6271b9006b1a7b9',
      'native_key' => 'OnTVFormRender',
      'filename' => 'modEvent/52512da0ae04445279a9e722ae582725.vehicle',
    ),
    56 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '06ebfa42fb754d73175464f503331ce8',
      'native_key' => 'OnBeforeTVFormSave',
      'filename' => 'modEvent/d78953774c2b1265a1499d4218551d0d.vehicle',
    ),
    57 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd9f65da0e0e6544802231afa4d4c6b36',
      'native_key' => 'OnTVFormSave',
      'filename' => 'modEvent/fab38e746e2d64063c974720178d5110.vehicle',
    ),
    58 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c055ddca6c6bc7a3a5b2e142521f3b87',
      'native_key' => 'OnBeforeTVFormDelete',
      'filename' => 'modEvent/ac28e5933e2a9d5d1d37a04c86cb24b0.vehicle',
    ),
    59 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '91b15364ee127aa84f773ed8efc1979b',
      'native_key' => 'OnTVFormDelete',
      'filename' => 'modEvent/fd2a11ebdfa40de804a0cf8d037fb964.vehicle',
    ),
    60 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '96c99e082a29f1cf84fe0e7518851847',
      'native_key' => 'OnTVInputRenderList',
      'filename' => 'modEvent/fdf1801b31df4f7eedb7dd5480ff72dc.vehicle',
    ),
    61 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f36a62921e2681192529a255ed7295ef',
      'native_key' => 'OnTVInputPropertiesList',
      'filename' => 'modEvent/ac4d5855cbafe718535225b67bd7284d.vehicle',
    ),
    62 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'bc456d87d669249329e84ab73bfe5b02',
      'native_key' => 'OnTVOutputRenderList',
      'filename' => 'modEvent/f16a1e08208af9844912c07e8b1cc1e4.vehicle',
    ),
    63 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '1a701724e7cef1e8a8f82e4b761ee9fd',
      'native_key' => 'OnTVOutputRenderPropertiesList',
      'filename' => 'modEvent/49fbebd14429c52cd2104b418c49f9ac.vehicle',
    ),
    64 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ccf29b93282caef22ba72e59c6a7f2e3',
      'native_key' => 'OnUserGroupBeforeSave',
      'filename' => 'modEvent/98020c67c041211433ebdecc08286d0f.vehicle',
    ),
    65 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '7c5e214482620f9dcce59b65afc7d0d2',
      'native_key' => 'OnUserGroupSave',
      'filename' => 'modEvent/7d52e149e3135ed07ab7909c45af79d0.vehicle',
    ),
    66 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2e82f22ec7ab4b36f8e9c0c16b1c328e',
      'native_key' => 'OnUserGroupBeforeRemove',
      'filename' => 'modEvent/145bde32c582bd4e5297285541ca0ba1.vehicle',
    ),
    67 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'dfd92e2c66abe3fe73e7eb679008149b',
      'native_key' => 'OnUserGroupRemove',
      'filename' => 'modEvent/2d8880862af617ea657420089351db15.vehicle',
    ),
    68 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c5a9ad7a1f5f351ce54cd7cd8ab22e64',
      'native_key' => 'OnBeforeUserGroupFormSave',
      'filename' => 'modEvent/d574a5207934a0cb7fc341b48cbda220.vehicle',
    ),
    69 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '00e1209c88bf49633f312860cd50c783',
      'native_key' => 'OnUserGroupFormSave',
      'filename' => 'modEvent/2379e61577e2b706f82b3870c2aaa9e4.vehicle',
    ),
    70 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2ef043530f0e841d3d530f4a7616331f',
      'native_key' => 'OnBeforeUserGroupFormRemove',
      'filename' => 'modEvent/da9e28aba8bc2906e0f1d5065e9b885e.vehicle',
    ),
    71 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '51715ed434566f97e629a7d66ce49185',
      'native_key' => 'OnBeforeUserGroupFormRemove',
      'filename' => 'modEvent/2f7bfde13b26ad91b3b3687eec3e9bc0.vehicle',
    ),
    72 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b570096eb6caa38d7413c0bdf64b7562',
      'native_key' => 'OnUserProfileBeforeSave',
      'filename' => 'modEvent/0c8d9709d4bfc52beed6ee4fa06ef50d.vehicle',
    ),
    73 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '1e459466f0c7afc879eb18a1554ebdce',
      'native_key' => 'OnUserProfileSave',
      'filename' => 'modEvent/a6976ca4e8536b37fffe8c0e59ceefc5.vehicle',
    ),
    74 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '26f5a843ac0c11ac2d5f74211354cbea',
      'native_key' => 'OnUserProfileBeforeRemove',
      'filename' => 'modEvent/4f0adbb14236406b9668eea19ec93bbe.vehicle',
    ),
    75 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '02d890f5b3eb3882c29ea8f093ad750b',
      'native_key' => 'OnUserProfileRemove',
      'filename' => 'modEvent/3c2d6ea9a9f5f6ea2e597fd351bdfc75.vehicle',
    ),
    76 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '0c3fb7c351e7ebf0f6da5af6af1c951e',
      'native_key' => 'OnDocFormPrerender',
      'filename' => 'modEvent/3294fc1495405eef3cd46f23516a0a12.vehicle',
    ),
    77 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5979a129d1535823d67702cb7470d1b4',
      'native_key' => 'OnDocFormRender',
      'filename' => 'modEvent/c7ecd10a40119258b2da3710a0ceb0c7.vehicle',
    ),
    78 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c982a80a294bb92febc3607a4503c875',
      'native_key' => 'OnBeforeDocFormSave',
      'filename' => 'modEvent/c1f08cee3dd196a191f2aac417e0d2d7.vehicle',
    ),
    79 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '06656b9be8a3a9f758375542f77b54e2',
      'native_key' => 'OnDocFormSave',
      'filename' => 'modEvent/6b235bce097ead2dc0204e9509d56002.vehicle',
    ),
    80 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b6a3a3dd8d2922f6884c1c909f7a037d',
      'native_key' => 'OnBeforeDocFormDelete',
      'filename' => 'modEvent/b3fc544d3194fe8d6f5b30c4027b9ca1.vehicle',
    ),
    81 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c40c5bf6b7cc55f8a286f2e89dd196b2',
      'native_key' => 'OnDocFormDelete',
      'filename' => 'modEvent/f481903842965b226a402528433c4071.vehicle',
    ),
    82 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '1c108e17f47645751d12cf2ba9bc5ad6',
      'native_key' => 'OnDocPublished',
      'filename' => 'modEvent/837a6dfffe8630117433b9bf9b388ff9.vehicle',
    ),
    83 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '6591f1b37b53cbd0ca9be1619ccfe4dc',
      'native_key' => 'OnDocUnPublished',
      'filename' => 'modEvent/ebb69d716dfd5666df862c827820ac35.vehicle',
    ),
    84 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a4e9730eeb4ccbe9f8d9fdb7aa6a6192',
      'native_key' => 'OnBeforeEmptyTrash',
      'filename' => 'modEvent/681c5a16a432ecdcc1f6098b1e86f7e5.vehicle',
    ),
    85 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ff1c14ed762193adac361d732a258ba8',
      'native_key' => 'OnEmptyTrash',
      'filename' => 'modEvent/d9e8e085f6a498bb07d6621e6785fa39.vehicle',
    ),
    86 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '900b079cb54ee657f39df507e97f6b3b',
      'native_key' => 'OnResourceTVFormPrerender',
      'filename' => 'modEvent/79928d90d74ae76c2e205982417764af.vehicle',
    ),
    87 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b44c5f968dfa311897034e1840f56001',
      'native_key' => 'OnResourceTVFormRender',
      'filename' => 'modEvent/6c07726fafb72278f04bd2d1052b6f17.vehicle',
    ),
    88 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a67170e44eeac71e3eb0f1db991e027b',
      'native_key' => 'OnResourceAutoPublish',
      'filename' => 'modEvent/440f39c1dd6943d8889b8e1f75beb25c.vehicle',
    ),
    89 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '586da34f0752383ca87d63be079a9f28',
      'native_key' => 'OnResourceDelete',
      'filename' => 'modEvent/cb4edba08a723d6c05b28ee6000aeb8f.vehicle',
    ),
    90 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'fd95e95cb25eb911d774cf4fbf4a5ff2',
      'native_key' => 'OnResourceUndelete',
      'filename' => 'modEvent/a43a41121120d5feff36d1c193168ea7.vehicle',
    ),
    91 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9a731220af1c8a282f672b85434e5d1e',
      'native_key' => 'OnResourceBeforeSort',
      'filename' => 'modEvent/64c985036b1952ec4f59265f622b1b30.vehicle',
    ),
    92 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a096d4ece87d3cabe864d64ca647865f',
      'native_key' => 'OnResourceSort',
      'filename' => 'modEvent/3ff41bcf98b6d03483a73322f652a073.vehicle',
    ),
    93 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5048709e21229f83190c819a0344db2d',
      'native_key' => 'OnResourceDuplicate',
      'filename' => 'modEvent/e2aaf5b5f374a1f9af4e2a10357bea02.vehicle',
    ),
    94 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3beaa9bbd260278849f3cd74ded3efc4',
      'native_key' => 'OnResourceToolbarLoad',
      'filename' => 'modEvent/7fe0a004d6f06c5410d12c421dabba79.vehicle',
    ),
    95 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e9dc45922d65de044a9e3055c12424d8',
      'native_key' => 'OnResourceRemoveFromResourceGroup',
      'filename' => 'modEvent/8f808df6338a23047a3fb0b428d1b72e.vehicle',
    ),
    96 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '125ca07c37e74cd94fd8776c2e9027f3',
      'native_key' => 'OnResourceAddToResourceGroup',
      'filename' => 'modEvent/ed456d8c399d16182001a62b8440ee58.vehicle',
    ),
    97 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5789ea9d03253a7c426972c21c9e65bb',
      'native_key' => 'OnResourceCacheUpdate',
      'filename' => 'modEvent/54cd5feae21402d0ddd43a72c2a1f511.vehicle',
    ),
    98 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '6d597ab53578673291a3137452a063aa',
      'native_key' => 'OnRichTextEditorRegister',
      'filename' => 'modEvent/9506d5d8549c66e55209b49ae1907a97.vehicle',
    ),
    99 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '828e4327d29e2cb3e53cd05e1818e878',
      'native_key' => 'OnRichTextEditorInit',
      'filename' => 'modEvent/1e53dc1386b90ec7658f7e9fb9d99417.vehicle',
    ),
    100 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'cfba3b843aeebcb764e0887b872d2e4b',
      'native_key' => 'OnRichTextBrowserInit',
      'filename' => 'modEvent/fba28c02383e29da9da309eb64c43eb4.vehicle',
    ),
    101 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '33c5044bf3c13cbf6989e73cb56b99d9',
      'native_key' => 'OnWebLogin',
      'filename' => 'modEvent/118cbfff81ae29945690edbe12e056e4.vehicle',
    ),
    102 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '638ee2378e73a17997ac7f0001a64c4f',
      'native_key' => 'OnBeforeWebLogout',
      'filename' => 'modEvent/461a36610a6e5f9dd714c6f34a9307a3.vehicle',
    ),
    103 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '942ebd4c6a48385ec1d354bcea0756e9',
      'native_key' => 'OnWebLogout',
      'filename' => 'modEvent/b93d87342f05da8016e7c115c2bc9083.vehicle',
    ),
    104 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '03c3f1eecb65139ea32abc7b25a3be2f',
      'native_key' => 'OnManagerLogin',
      'filename' => 'modEvent/f1d9dd4ddb855f73ad0bd0c94e46b4ad.vehicle',
    ),
    105 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3d64653203e36ba49bed61d1522b5ba2',
      'native_key' => 'OnBeforeManagerLogout',
      'filename' => 'modEvent/990c4fb67b57a8a26b9c1c9e4cab6469.vehicle',
    ),
    106 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2901f8f9eb795a61d34b59f9bea30c54',
      'native_key' => 'OnManagerLogout',
      'filename' => 'modEvent/420a55d73f3f4bc9ec46f6a86b8ff8c6.vehicle',
    ),
    107 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c857094c5a2bdca24743c30b7eb44e7e',
      'native_key' => 'OnBeforeWebLogin',
      'filename' => 'modEvent/5cb94fb78e279d259d4e2fab8c6452c0.vehicle',
    ),
    108 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '56fd0b1627a3fc3e10ef1eff52faf717',
      'native_key' => 'OnWebAuthentication',
      'filename' => 'modEvent/d5b2226a55a92cfc9e2806f989e0a8b5.vehicle',
    ),
    109 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f7db735909047ca2a629d6aea0fe9686',
      'native_key' => 'OnBeforeManagerLogin',
      'filename' => 'modEvent/7b61cf5cf6762db2e163c3b9ad1dc942.vehicle',
    ),
    110 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '1b0dadf0e88c2fa1d472831da5608591',
      'native_key' => 'OnManagerAuthentication',
      'filename' => 'modEvent/746c9832d62399c14d8e2737888711f8.vehicle',
    ),
    111 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'dbca3b0523eb8efd4bbe2be7c5330fee',
      'native_key' => 'OnManagerLoginFormRender',
      'filename' => 'modEvent/e08c2d1ae505153f62e16ac30f72a896.vehicle',
    ),
    112 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a728b4c513e1c245ebea927394f41ad4',
      'native_key' => 'OnManagerLoginFormPrerender',
      'filename' => 'modEvent/ce3867399f217f5c51e327911f7fc7a2.vehicle',
    ),
    113 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e5f114ed7e5364ee8d2d925aa9b04cac',
      'native_key' => 'OnPageUnauthorized',
      'filename' => 'modEvent/636166caf4f1e8c55b7c9bcbabb2d599.vehicle',
    ),
    114 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e2d5a53a3bdd56b107674b6c4f42b0ef',
      'native_key' => 'OnUserFormPrerender',
      'filename' => 'modEvent/513c6b1ff319ac60b6c3ceb12a523508.vehicle',
    ),
    115 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd02d8cea9b8c748ff3eb9488a275035a',
      'native_key' => 'OnUserFormRender',
      'filename' => 'modEvent/aea40bb7da626c9a87590a1b7e040b84.vehicle',
    ),
    116 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9861e63ecd4a93ae3a10a22a022cd453',
      'native_key' => 'OnBeforeUserFormSave',
      'filename' => 'modEvent/c695eea8245939a4382bc26ad91234e3.vehicle',
    ),
    117 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '10345c443d0445989848b9941bd025e3',
      'native_key' => 'OnUserFormSave',
      'filename' => 'modEvent/ccc91f0da53320edbb327e96d39e80b7.vehicle',
    ),
    118 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd237c05c96d80086ce30fc8225b6dde5',
      'native_key' => 'OnBeforeUserFormDelete',
      'filename' => 'modEvent/0c7d652c8452de3a6e13651650f3bfdb.vehicle',
    ),
    119 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '69d95c4fef823fa06e64b115329f57e5',
      'native_key' => 'OnUserFormDelete',
      'filename' => 'modEvent/720e1477e3a1e59baeb379f09915e6b9.vehicle',
    ),
    120 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '26c13e9a06fb912b0399411d238180c4',
      'native_key' => 'OnUserNotFound',
      'filename' => 'modEvent/7dc48a10e9fbd112f5525cf8b758c340.vehicle',
    ),
    121 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '0b8b2d679421d2061df5f4f9b0f785d8',
      'native_key' => 'OnBeforeUserActivate',
      'filename' => 'modEvent/f709ec37b606e9e79d0e58380974713f.vehicle',
    ),
    122 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e592316d873bc1a7b78ff5b4d0d23975',
      'native_key' => 'OnUserActivate',
      'filename' => 'modEvent/cc0889b824806fe8261b914bccc5f87b.vehicle',
    ),
    123 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd8cb6e1858f28ec280decbc3c89a6632',
      'native_key' => 'OnBeforeUserDeactivate',
      'filename' => 'modEvent/4d26044aff15fa098606c595fbe09cc0.vehicle',
    ),
    124 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'fcf8b3c38a3a92a326ba570312bba29f',
      'native_key' => 'OnUserDeactivate',
      'filename' => 'modEvent/f4137ca0041ade4f6b27f662dea3ba0c.vehicle',
    ),
    125 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '879d4ee11b98b6974eae3f019917053d',
      'native_key' => 'OnBeforeUserDuplicate',
      'filename' => 'modEvent/323df0709163e546432e1cad317b64ba.vehicle',
    ),
    126 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '36d3f7f8333bcb28fc139f3419c4e91f',
      'native_key' => 'OnUserDuplicate',
      'filename' => 'modEvent/62190ae6a6651f6fe5afdaa5349c4caa.vehicle',
    ),
    127 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '95c825d3dc63842b50b9bd608d61b4b7',
      'native_key' => 'OnUserChangePassword',
      'filename' => 'modEvent/39c31d6384d16562d7d8f7054e52851c.vehicle',
    ),
    128 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '4afebc458964a67d39d148115804d129',
      'native_key' => 'OnUserBeforeRemove',
      'filename' => 'modEvent/73a040264b726eb02616ba74a7ede80b.vehicle',
    ),
    129 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '44a21f87b9b6eaa1fa9ed6e4e5a647ad',
      'native_key' => 'OnUserBeforeSave',
      'filename' => 'modEvent/a631efdb7dfff3b86edce554b7f89e33.vehicle',
    ),
    130 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '7d60884bb10211ffd877df3a6ef9ef44',
      'native_key' => 'OnUserSave',
      'filename' => 'modEvent/5b857e9e4eda6aa1c058b795f11d434c.vehicle',
    ),
    131 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e65a96e4246481ffa72a2ab9e268ccef',
      'native_key' => 'OnUserRemove',
      'filename' => 'modEvent/901c6c733887e21a030246450c2f83ba.vehicle',
    ),
    132 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3c40e84f2e6b6d66ea8bbead3749250c',
      'native_key' => 'OnUserBeforeAddToGroup',
      'filename' => 'modEvent/0a1e8dca61a96b4a02c11c4b42aa220b.vehicle',
    ),
    133 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2d5077c302d0ca8502700fe5591fc077',
      'native_key' => 'OnUserAddToGroup',
      'filename' => 'modEvent/d798814ac6421e4f84f635c2feef0280.vehicle',
    ),
    134 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '7bef3caaecc23adc4a4d36e33bdef7a0',
      'native_key' => 'OnUserBeforeRemoveFromGroup',
      'filename' => 'modEvent/61b44462ed7bc7781096da58aafbc4eb.vehicle',
    ),
    135 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3d91f5d033040ff428d944ded279cac4',
      'native_key' => 'OnUserRemoveFromGroup',
      'filename' => 'modEvent/a087ab261f24af2faf2029f39ee7c861.vehicle',
    ),
    136 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '0626e507c1a9bb1dd64ab70fda66fc9a',
      'native_key' => 'OnBeforeRegisterClientScripts',
      'filename' => 'modEvent/8fd7dcc15917cb35c120f7196d56c846.vehicle',
    ),
    137 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c471c8a68ede03f7a370817416c8d14d',
      'native_key' => 'OnWebPagePrerender',
      'filename' => 'modEvent/db6b8155699659d154b256ebdb1a534a.vehicle',
    ),
    138 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '6187cb627384476b6d577e113552cfad',
      'native_key' => 'OnBeforeCacheUpdate',
      'filename' => 'modEvent/e828b832430f8fe074ff159bb33b196f.vehicle',
    ),
    139 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '73539bcfd4bff0e464e9cabcebedc6da',
      'native_key' => 'OnCacheUpdate',
      'filename' => 'modEvent/b62293dfa6f744890b1982bc7ef68bc1.vehicle',
    ),
    140 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9c55152ae0363e9c0bb8dfebeac63d0e',
      'native_key' => 'OnLoadWebPageCache',
      'filename' => 'modEvent/68ddd2905eeafb2fb69e26391368b9c9.vehicle',
    ),
    141 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '67fcb2d8be41ce4a18dbf8616290498e',
      'native_key' => 'OnBeforeSaveWebPageCache',
      'filename' => 'modEvent/c01ead9b4ac557fb0ebbc91e26a8777f.vehicle',
    ),
    142 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'cb9f8f66423f999378f082fe0d3a6153',
      'native_key' => 'OnSiteRefresh',
      'filename' => 'modEvent/69b2072c2c9b6a9ac3a4ee8aef106bcd.vehicle',
    ),
    143 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5accf60ddde3701b8ea60d87cb9ac40a',
      'native_key' => 'OnFileManagerDirCreate',
      'filename' => 'modEvent/f52b2856cf4e55de3a55f78049d7dcb3.vehicle',
    ),
    144 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3d8cffb54dbb740c414ed09bc8729437',
      'native_key' => 'OnFileManagerDirRemove',
      'filename' => 'modEvent/2fa7420f6f8668b51510075af1dae910.vehicle',
    ),
    145 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '14cb8b1a53236778fcb88a5faf7109d9',
      'native_key' => 'OnFileManagerDirRename',
      'filename' => 'modEvent/dfb4cc58b5070cad06a7418f8364181e.vehicle',
    ),
    146 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '369de3af2c43cc603d69bfeadc7d9a77',
      'native_key' => 'OnFileManagerFileRename',
      'filename' => 'modEvent/932e1e5e49640045a12471ba786dc501.vehicle',
    ),
    147 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c5ed52280672849c72789f94b7461fe2',
      'native_key' => 'OnFileManagerFileRemove',
      'filename' => 'modEvent/7a427003509e13cdf8f47aa6980f4523.vehicle',
    ),
    148 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '8b130c53ad1ae99f874193b51d00ac3b',
      'native_key' => 'OnFileManagerFileUpdate',
      'filename' => 'modEvent/d2d376c4aa7c6b733757fe6284845c15.vehicle',
    ),
    149 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3bda5b1bbc81f06ba193b0cd8605ff37',
      'native_key' => 'OnFileManagerFileCreate',
      'filename' => 'modEvent/3d0bea767a77e45e04bb7b3e42e0fe9f.vehicle',
    ),
    150 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '6f015a7918c296d78438d72e802cabc2',
      'native_key' => 'OnFileManagerBeforeUpload',
      'filename' => 'modEvent/6811172c1b94b792e277e50ef16b43dc.vehicle',
    ),
    151 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5d70da395799662c6af89cd73f1efe49',
      'native_key' => 'OnFileManagerUpload',
      'filename' => 'modEvent/276b3bbf6b8afc64f3529b22daf1e28f.vehicle',
    ),
    152 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'aab0b0dafa504db9120327d7384c1df0',
      'native_key' => 'OnFileManagerMoveObject',
      'filename' => 'modEvent/2919a8dd953021078ef1e004ec8977ab.vehicle',
    ),
    153 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '04e1125e0f0904832b5a6cfa76ac3173',
      'native_key' => 'OnFileCreateFormPrerender',
      'filename' => 'modEvent/1d7f1f6a50e7aee2d2e92eb186c0d714.vehicle',
    ),
    154 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '76603cf51d5ac8938a299c018e1e7ecc',
      'native_key' => 'OnFileEditFormPrerender',
      'filename' => 'modEvent/42e197ffcb6426fccc1f37bfb2887f21.vehicle',
    ),
    155 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '55f8152e5d5f8cb71987576d1f016942',
      'native_key' => 'OnManagerPageInit',
      'filename' => 'modEvent/6eb04bede25f8b17368a3c2088c59130.vehicle',
    ),
    156 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a987c3ab0018d3dac4ebde41761f38bf',
      'native_key' => 'OnManagerPageBeforeRender',
      'filename' => 'modEvent/4c2e2f6571c5305bb6a995b399638302.vehicle',
    ),
    157 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5bc57d7299c90f85b12e1aba60347a82',
      'native_key' => 'OnManagerPageAfterRender',
      'filename' => 'modEvent/06637d8698036a70cc03ba24a2210db3.vehicle',
    ),
    158 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e80ae4a0c93783c5e5bf96ef519522fc',
      'native_key' => 'OnWebPageInit',
      'filename' => 'modEvent/bdb6d79a23cd3492ac5062489562bcac.vehicle',
    ),
    159 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'df5b56b6e7a3366fe8507d0ec14936d9',
      'native_key' => 'OnLoadWebDocument',
      'filename' => 'modEvent/f695568bc5b18bb3ac901a5c869784cf.vehicle',
    ),
    160 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '032496ccd52ec3dc4f5ecbc22819be69',
      'native_key' => 'OnParseDocument',
      'filename' => 'modEvent/3c32db528b926888243de1cf2c9b7a20.vehicle',
    ),
    161 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c9b781bd72e58db7f3eaaa3a3f33ac4c',
      'native_key' => 'OnWebPageComplete',
      'filename' => 'modEvent/be9e23905a568d8150708cfe82bbb85a.vehicle',
    ),
    162 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f874ee72888b3fab244b43024fa9dfc8',
      'native_key' => 'OnBeforeManagerPageInit',
      'filename' => 'modEvent/759a244bcf6f218247bfa2b43703410e.vehicle',
    ),
    163 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '315330c0b329c7125e167c1cf374416d',
      'native_key' => 'OnPageNotFound',
      'filename' => 'modEvent/96b02a1bb32d59c007a45410aeaf46ac.vehicle',
    ),
    164 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'cfe4a028cf4fac0035e3da3e6761a88a',
      'native_key' => 'OnHandleRequest',
      'filename' => 'modEvent/d038ca8c16083ae562f6714077fe014d.vehicle',
    ),
    165 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '051a9346d5ef322a2d31142dbac5fcf6',
      'native_key' => 'OnMODXInit',
      'filename' => 'modEvent/cd40aac250429b57d29070590922eb74.vehicle',
    ),
    166 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c7e69fb2115a835dc36642da704db072',
      'native_key' => 'OnElementNotFound',
      'filename' => 'modEvent/41203b386271e3b382859fc289f341fc.vehicle',
    ),
    167 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'bb45d3e08faf2c25e69355c1e94b7689',
      'native_key' => 'OnSiteSettingsRender',
      'filename' => 'modEvent/5c8b3cf237e5ccd75d2831ea0b329591.vehicle',
    ),
    168 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'bd90d49f9f73926e0f662b9c456749d7',
      'native_key' => 'OnInitCulture',
      'filename' => 'modEvent/9becce009d6b8d347f0fefa7237c4bd0.vehicle',
    ),
    169 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd4d625aca975b3ea1d48b7919ce289c2',
      'native_key' => 'OnCategorySave',
      'filename' => 'modEvent/bbf3ebd639c39882e55f9da3369cf8d2.vehicle',
    ),
    170 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '877f4ace7f09ab0f555dd9388566a4da',
      'native_key' => 'OnCategoryBeforeSave',
      'filename' => 'modEvent/8db1ae1dd8547b86747f4a53caa69a44.vehicle',
    ),
    171 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'be536883d692002ef8bf1a9e698277fb',
      'native_key' => 'OnCategoryRemove',
      'filename' => 'modEvent/90d7876bcb0625f08174a8a6bba894ad.vehicle',
    ),
    172 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'bc3cf82facd380670d3d6b1d5887fa5e',
      'native_key' => 'OnCategoryBeforeRemove',
      'filename' => 'modEvent/ffd7484ce3092e9d37498d8c66304913.vehicle',
    ),
    173 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '09d3724f972f9dd7e02bd69ec17e3ded',
      'native_key' => 'OnChunkSave',
      'filename' => 'modEvent/4ff513a7abf497a164c098b2d7243b62.vehicle',
    ),
    174 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2f3fdbafc33e2e15b3ab885ee233f8c4',
      'native_key' => 'OnChunkBeforeSave',
      'filename' => 'modEvent/7cb29110d838ab75e63bc5ec4b91b4fd.vehicle',
    ),
    175 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'eebfe33f039b5538cdfa529eff9c6ad0',
      'native_key' => 'OnChunkRemove',
      'filename' => 'modEvent/1527ee747fd2e92032aa3a1374122a77.vehicle',
    ),
    176 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '8e227236313333679c3319e5c270cada',
      'native_key' => 'OnChunkBeforeRemove',
      'filename' => 'modEvent/d27406ab75c92246459888954c16f5ff.vehicle',
    ),
    177 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '1019b764bd66751ec32badc193d20a42',
      'native_key' => 'OnChunkFormPrerender',
      'filename' => 'modEvent/b031e18fe7b36ab018ff487468e0c69e.vehicle',
    ),
    178 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a4ab71723d52991accbfe6943c08ee11',
      'native_key' => 'OnChunkFormRender',
      'filename' => 'modEvent/acd63864e1be11f6f90d89a41a8399cc.vehicle',
    ),
    179 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '0fdbc76dd608bf760533f9c914b42915',
      'native_key' => 'OnBeforeChunkFormSave',
      'filename' => 'modEvent/debb89ebbd248748353e460112c311f2.vehicle',
    ),
    180 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd893579537125c651c5622364e75dd17',
      'native_key' => 'OnChunkFormSave',
      'filename' => 'modEvent/8f7ea82a32078ae3814b565aa77d1f80.vehicle',
    ),
    181 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9271b29dc399adbd07b8180516b5288b',
      'native_key' => 'OnBeforeChunkFormDelete',
      'filename' => 'modEvent/f7d4343a41c5898a422047d93c08a940.vehicle',
    ),
    182 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'dbd3ed9234dc76f46d5dcdeb08e16871',
      'native_key' => 'OnChunkFormDelete',
      'filename' => 'modEvent/6d4d385a66b58fa662ab9a9994b8d870.vehicle',
    ),
    183 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd17398dff0014fb790e9340348ec1ebf',
      'native_key' => 'OnContextSave',
      'filename' => 'modEvent/d1fd003c98bdb68a820f5fcb49385a19.vehicle',
    ),
    184 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f384ad5068b9c7e632d3cf0f032d692d',
      'native_key' => 'OnContextBeforeSave',
      'filename' => 'modEvent/127d51ffe4216a9560550c025c6a5ae9.vehicle',
    ),
    185 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e8300cab2ed196f07804034d1b447320',
      'native_key' => 'OnContextRemove',
      'filename' => 'modEvent/2d5d824477139c3768eafa75bada5f40.vehicle',
    ),
    186 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '8c29fb217fa1dc21945d1429f5d4d3c7',
      'native_key' => 'OnContextBeforeRemove',
      'filename' => 'modEvent/77a593a11e7b6e026c2173c6b2afd70d.vehicle',
    ),
    187 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c5d8aca2c5ff2008d9274f2561d8b2ab',
      'native_key' => 'OnContextFormPrerender',
      'filename' => 'modEvent/f08ba50033036961591266cf5cdcd9f8.vehicle',
    ),
    188 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '1fbc5f650e46eda3295108459d8468d4',
      'native_key' => 'OnContextFormRender',
      'filename' => 'modEvent/516b7d27e6eb7304acc397c30aaa127a.vehicle',
    ),
    189 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '7c38130d73d40755f208317b50a7f115',
      'native_key' => 'OnPluginSave',
      'filename' => 'modEvent/69931709d1d084d6258662b726843022.vehicle',
    ),
    190 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e120a37a456269c6efc4b04359a962a3',
      'native_key' => 'OnPluginBeforeSave',
      'filename' => 'modEvent/a239809b4138d7cc74879ade89854e81.vehicle',
    ),
    191 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '716996fb2cbc903de4aab27ca03c6d65',
      'native_key' => 'OnPluginRemove',
      'filename' => 'modEvent/84c42feae483523482dfcbcb8e1eed3c.vehicle',
    ),
    192 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '178bd0fe4f54ead8d46b4c2009c4016d',
      'native_key' => 'OnPluginBeforeRemove',
      'filename' => 'modEvent/4158d3eba3517097f8420130d696463d.vehicle',
    ),
    193 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '86f4afd5de245ee280bafda816d973fc',
      'native_key' => 'OnPluginFormPrerender',
      'filename' => 'modEvent/575e7a2acc14d6e36308fa158a243c4b.vehicle',
    ),
    194 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '6663439b7f74f1be7b4ba4faf6287bd2',
      'native_key' => 'OnPluginFormRender',
      'filename' => 'modEvent/d145e9a4bcf8d1a80070f8f2b9171494.vehicle',
    ),
    195 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f294ab0b58cac1d07e0b136f1b8fb348',
      'native_key' => 'OnBeforePluginFormSave',
      'filename' => 'modEvent/6ee99f695a053b62ebe38dff7b2d78e4.vehicle',
    ),
    196 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e9e8596a3d868fb8b08a93c39aa10ec3',
      'native_key' => 'OnPluginFormSave',
      'filename' => 'modEvent/ae935a95c4bca6ed0d60ae06e3048eea.vehicle',
    ),
    197 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b6a43822f59b838ced105e4c8115b093',
      'native_key' => 'OnBeforePluginFormDelete',
      'filename' => 'modEvent/f5c421fd95786c5f3c4f629083861673.vehicle',
    ),
    198 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '909ea920e4cfab3501012f27cc868ebf',
      'native_key' => 'OnPluginFormDelete',
      'filename' => 'modEvent/42f80254f85e3c7baf88a94254173c64.vehicle',
    ),
    199 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '69ed4268bfd28b341882ba227ca9f09d',
      'native_key' => 'OnPropertySetSave',
      'filename' => 'modEvent/ed88f1702aa05f04cf478f1b53d3ad7f.vehicle',
    ),
    200 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'df3f4288f5e0500730fce6b94a2072f8',
      'native_key' => 'OnPropertySetBeforeSave',
      'filename' => 'modEvent/71733168735b089cb468668407b4cea4.vehicle',
    ),
    201 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5ae47016a689665e3294e30a801a0b0b',
      'native_key' => 'OnPropertySetRemove',
      'filename' => 'modEvent/f9ff1d8c73a22f19ac8413dc4b0993b0.vehicle',
    ),
    202 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e4a94f2c16fdac9c63fe00d43f9fc6f5',
      'native_key' => 'OnPropertySetBeforeRemove',
      'filename' => 'modEvent/dce6bed279232850f9247af3d4c138e1.vehicle',
    ),
    203 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f4e2dddd4021b6e73ff955f5e1d32cac',
      'native_key' => 'OnMediaSourceBeforeFormDelete',
      'filename' => 'modEvent/99b4407f64bd2df5a3fda9be9079b8c0.vehicle',
    ),
    204 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '15a7b1a21bb1efd428021cb56a35f63e',
      'native_key' => 'OnMediaSourceBeforeFormSave',
      'filename' => 'modEvent/f485ee5f961d9380ed7552d1b5984e55.vehicle',
    ),
    205 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '8ebff60a8561f019ff349af69b535a7a',
      'native_key' => 'OnMediaSourceGetProperties',
      'filename' => 'modEvent/e87097f8be101d5552cdfdeb8858a9bb.vehicle',
    ),
    206 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'cb0144c2dcc502947cefe84d2cc22e89',
      'native_key' => 'OnMediaSourceFormDelete',
      'filename' => 'modEvent/a056e605202e2898933164f853946bef.vehicle',
    ),
    207 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2436b16cacad0ee6a317c2fa38ed9da9',
      'native_key' => 'OnMediaSourceFormSave',
      'filename' => 'modEvent/bf7b6237abfe9163f048c56d43405127.vehicle',
    ),
    208 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c6ccea769a86cd8c810830c2a8c0ff38',
      'native_key' => 'OnMediaSourceDuplicate',
      'filename' => 'modEvent/d90360f9c0bf82bce9b3676504fec4a1.vehicle',
    ),
    209 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ed8fd427465851ac5dccde3a39d706b1',
      'native_key' => 'OnPackageInstall',
      'filename' => 'modEvent/93b36ecc6db9ca8403dd693c848deae0.vehicle',
    ),
    210 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5c389f8e1da74ea3ae57822df92863a6',
      'native_key' => 'OnPackageUninstall',
      'filename' => 'modEvent/432f6543e2e671a44c88f4dec6032998.vehicle',
    ),
    211 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '8d4485a8219885d8cee6cb7a50a1b3b9',
      'native_key' => 'OnPackageRemove',
      'filename' => 'modEvent/5d83bb0fb8308f6b006a03fede15e2d4.vehicle',
    ),
    212 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fc0e15db9c7fce07286653073c36472c',
      'native_key' => 'access_category_enabled',
      'filename' => 'modSystemSetting/33a3439322751110e18f5590aa1f99fd.vehicle',
    ),
    213 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f5c7bf5f108dc37c1108192467888369',
      'native_key' => 'access_context_enabled',
      'filename' => 'modSystemSetting/723bff64b837e028884362be39cc684c.vehicle',
    ),
    214 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c7cc4428f4cf9d5289b0739fa8129f82',
      'native_key' => 'access_resource_group_enabled',
      'filename' => 'modSystemSetting/caf2dbba123346046e2e69cc775dbff5.vehicle',
    ),
    215 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'dc3b8a570050ea6048787e4584bfab10',
      'native_key' => 'allow_forward_across_contexts',
      'filename' => 'modSystemSetting/19c595b83626c7fb2413371b0ed2ed2d.vehicle',
    ),
    216 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1d62dbb7f08910b7f761471f3198e9f5',
      'native_key' => 'allow_manager_login_forgot_password',
      'filename' => 'modSystemSetting/ced4bf598b9556fc38305e4906e1b882.vehicle',
    ),
    217 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e1be04a0e93fa8ce1cd076e8c5fa763d',
      'native_key' => 'allow_multiple_emails',
      'filename' => 'modSystemSetting/bd4640f44041f8debb985414e579cb17.vehicle',
    ),
    218 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a8c055fb62b5c452df6c675182a435aa',
      'native_key' => 'allow_tags_in_post',
      'filename' => 'modSystemSetting/9d038a86ff0ffce1a9e1903a5b748b74.vehicle',
    ),
    219 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4bc26732abc97e78ec6dce3c51b04976',
      'native_key' => 'archive_with',
      'filename' => 'modSystemSetting/ca793cb4fda611d312d8b8d523bab284.vehicle',
    ),
    220 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '08cc97bd773cecce3885fc8938d26cad',
      'native_key' => 'auto_menuindex',
      'filename' => 'modSystemSetting/3f60f35e17ed6dd59437f98acf540ec8.vehicle',
    ),
    221 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '66d76787f633becfc0a5f1aa7e4b1583',
      'native_key' => 'auto_check_pkg_updates',
      'filename' => 'modSystemSetting/57ab971ad49336314ba526ba79f15360.vehicle',
    ),
    222 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ec330cf175ff8d42b4621685b5edcc10',
      'native_key' => 'auto_check_pkg_updates_cache_expire',
      'filename' => 'modSystemSetting/670c208051e5eb7a1e50d84bdaed7a6c.vehicle',
    ),
    223 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fa69488c3f0b930c77d7bc6c30fb9198',
      'native_key' => 'automatic_alias',
      'filename' => 'modSystemSetting/761ee9fddff8a31102df725395d7987e.vehicle',
    ),
    224 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8e12d292915585343ce08edc05fb2134',
      'native_key' => 'automatic_template_assignment',
      'filename' => 'modSystemSetting/2bae2d864a5de7ab36b27fc8fdbc0a29.vehicle',
    ),
    225 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f9a6ac396f291fd708538a5dd1ed930f',
      'native_key' => 'base_help_url',
      'filename' => 'modSystemSetting/8dd8df94be6c700b81984f726f564e40.vehicle',
    ),
    226 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6b7e40948d32e0579425554a35735408',
      'native_key' => 'blocked_minutes',
      'filename' => 'modSystemSetting/6506e30d377c51df9c262ceca2390030.vehicle',
    ),
    227 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '287a631fcaa65f1f63de89c598f2ed0c',
      'native_key' => 'cache_action_map',
      'filename' => 'modSystemSetting/08c72dc8b0efd527770f616b665ac25a.vehicle',
    ),
    228 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7b9724950851479a408f8d8aa9493776',
      'native_key' => 'cache_alias_map',
      'filename' => 'modSystemSetting/acc3a60a89670c99725cb1cbdaaa1284.vehicle',
    ),
    229 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '98ac73b7eca0d50c8b7124d9812f0f32',
      'native_key' => 'use_context_resource_table',
      'filename' => 'modSystemSetting/975690dc76f5d3b08025060c4fce7204.vehicle',
    ),
    230 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '11eaff2e43c5467ceccc5258003d9499',
      'native_key' => 'cache_context_settings',
      'filename' => 'modSystemSetting/7a0b7bdc767c181db0575a4cd30304ec.vehicle',
    ),
    231 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a9f47effc21eb12be4fc1a2287aaed69',
      'native_key' => 'cache_db',
      'filename' => 'modSystemSetting/2c596fb3e7dc5bba615802813c69502f.vehicle',
    ),
    232 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b7be0c38fa08cb7f7d24e5af8f180fdf',
      'native_key' => 'cache_db_expires',
      'filename' => 'modSystemSetting/fbb6db0ddfff34f87fd766e8d164af8f.vehicle',
    ),
    233 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '957a6f9d70c7137e2849ee796d1b3b9f',
      'native_key' => 'cache_db_session',
      'filename' => 'modSystemSetting/e3d93a9b4c035e14d7149e760bd95014.vehicle',
    ),
    234 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '491a1c8064fe51dd610a91a7194a9ca5',
      'native_key' => 'cache_db_session_lifetime',
      'filename' => 'modSystemSetting/ae8c2f5c344f0f5fa16b3786a10ad077.vehicle',
    ),
    235 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'abf642a465ee8e361bed42e031f43f0d',
      'native_key' => 'cache_default',
      'filename' => 'modSystemSetting/98fc68fbc94a81a7cdd8796c3ba30904.vehicle',
    ),
    236 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '24e56abdbe4364b399b8984191a5f986',
      'native_key' => 'cache_expires',
      'filename' => 'modSystemSetting/914e4b129d686bc67fd41d77ea492a6e.vehicle',
    ),
    237 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4c32087117501d78bef37592a324f6b6',
      'native_key' => 'cache_format',
      'filename' => 'modSystemSetting/23974238d1db67a8df7f347742c92c89.vehicle',
    ),
    238 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd7408d8e065e735b8149ea466e1d16ef',
      'native_key' => 'cache_handler',
      'filename' => 'modSystemSetting/a0e04f2564b1c5a33b2460271f202e52.vehicle',
    ),
    239 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fb9cf1d61fabdf7da6c44250dee32a20',
      'native_key' => 'cache_lang_js',
      'filename' => 'modSystemSetting/eed35439b895bdb39b1b15cc2cd4ea09.vehicle',
    ),
    240 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f833b9fc8aedb3116677ad0169621a34',
      'native_key' => 'cache_lexicon_topics',
      'filename' => 'modSystemSetting/310afc81d70e899b23abc690c89c2d1c.vehicle',
    ),
    241 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4f52918e0b5069438ec9df91c88313d7',
      'native_key' => 'cache_noncore_lexicon_topics',
      'filename' => 'modSystemSetting/c1d3d43524af8feb6e64dc311f1264a1.vehicle',
    ),
    242 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c2ec71260d599dad074a68aee56b0fe0',
      'native_key' => 'cache_resource',
      'filename' => 'modSystemSetting/66f22841fc407b3c0154f59bf39c90eb.vehicle',
    ),
    243 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6e343cf502761cf91383792289cc513a',
      'native_key' => 'cache_resource_expires',
      'filename' => 'modSystemSetting/ae2605c37a7886a7a24a88e37b41893b.vehicle',
    ),
    244 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b30f88cc67d8c1fda8a1bd2214812005',
      'native_key' => 'cache_resource_clear_partial',
      'filename' => 'modSystemSetting/81d5891fc3657633fe1633bd68c3bcaa.vehicle',
    ),
    245 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '76d2129ffa31690f7d0a2cefa6dc1eb3',
      'native_key' => 'cache_scripts',
      'filename' => 'modSystemSetting/04fbfd3b46ee012d93404da6503b513b.vehicle',
    ),
    246 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '965df65b467435c547dce55d63963230',
      'native_key' => 'clear_cache_refresh_trees',
      'filename' => 'modSystemSetting/d788d0a490195c76cf9cd1745816e43d.vehicle',
    ),
    247 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ee1c3598b8cb58c87d2a17c5184558bb',
      'native_key' => 'compress_css',
      'filename' => 'modSystemSetting/062082e2c29e0ac8bfde29bae551234c.vehicle',
    ),
    248 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3edf5361eeb76abc2972bb3cac515589',
      'native_key' => 'compress_js',
      'filename' => 'modSystemSetting/5d8ad76a3d91ce8cc16fef13ba12a2e2.vehicle',
    ),
    249 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'da5385147b07a9c80c69f9f8cd13890a',
      'native_key' => 'compress_js_max_files',
      'filename' => 'modSystemSetting/190a15f450f1923e8a4caad0f38e15c2.vehicle',
    ),
    250 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6e5c8625d3e9d27b76383055a6992800',
      'native_key' => 'confirm_navigation',
      'filename' => 'modSystemSetting/1aa8888e9c249f44f3439f191f134ec6.vehicle',
    ),
    251 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '94ac54f7ebd24e172bd33f62c838e4cb',
      'native_key' => 'container_suffix',
      'filename' => 'modSystemSetting/066f8c2a1ceffd76fe0f0da516d2455b.vehicle',
    ),
    252 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e77750b547c3633b79e0803221730672',
      'native_key' => 'context_tree_sort',
      'filename' => 'modSystemSetting/528bf29a2ef5ba4c7a5dc035cfb4c134.vehicle',
    ),
    253 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8b0a04cf0d9aeb4a60f0f2db922c3488',
      'native_key' => 'context_tree_sortby',
      'filename' => 'modSystemSetting/1ce9499fa534139e4882162b76050e74.vehicle',
    ),
    254 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '355d4bde5e8e5a0846750df0261d5295',
      'native_key' => 'context_tree_sortdir',
      'filename' => 'modSystemSetting/aca126e817a609b1b6a417a2bb913f40.vehicle',
    ),
    255 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7cd92684b18d6f7ea40a8c47e308977a',
      'native_key' => 'cultureKey',
      'filename' => 'modSystemSetting/0111bdbde71966d31d46d0dbbf81f892.vehicle',
    ),
    256 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '16e1575ff72cc581f718ac4a3bc1bdb1',
      'native_key' => 'date_timezone',
      'filename' => 'modSystemSetting/ff92c8fc85e247394ef0df89397e4b5a.vehicle',
    ),
    257 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a50bb77fbbafbd8c48fd5a0c6a73b7c4',
      'native_key' => 'debug',
      'filename' => 'modSystemSetting/3a7144e2c6a373a815e7c3a34932dc25.vehicle',
    ),
    258 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '57d00d1bbc7a270262db76d45db56bff',
      'native_key' => 'default_duplicate_publish_option',
      'filename' => 'modSystemSetting/83bb5e3e5fac4b824398bbb2614df879.vehicle',
    ),
    259 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '767dd26cb6762b3802f2879a50b96389',
      'native_key' => 'default_media_source',
      'filename' => 'modSystemSetting/cbd1eec2040aa9b96c4482b14b8ee12b.vehicle',
    ),
    260 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'be847839fb835ce99747544eec720e89',
      'native_key' => 'default_media_source_type',
      'filename' => 'modSystemSetting/ad9745b245331884cf979ea8219f8bc6.vehicle',
    ),
    261 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b48b995724b663596ca7c6d4d8aba943',
      'native_key' => 'default_per_page',
      'filename' => 'modSystemSetting/f240034a2c11a2d50ede90d39f386596.vehicle',
    ),
    262 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd874bf7307a3ed1565a8dced462955ca',
      'native_key' => 'default_context',
      'filename' => 'modSystemSetting/6f2a32dbce4d93e9bae7e998c54e027b.vehicle',
    ),
    263 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fdc6803d4deacff3f585eec5b5b60449',
      'native_key' => 'default_template',
      'filename' => 'modSystemSetting/a720e57e3927d1393c4282ec88107475.vehicle',
    ),
    264 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b174a60597242c5160c6d9d2d52f90a3',
      'native_key' => 'default_content_type',
      'filename' => 'modSystemSetting/93ad27042e3c344e7cf171b648c33725.vehicle',
    ),
    265 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '022e2fd402e701c501fc2e8192ef2a7a',
      'native_key' => 'editor_css_path',
      'filename' => 'modSystemSetting/99d1d804e6d3a2b3d344cd9d8c7b5c86.vehicle',
    ),
    266 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '219eb8db6d16e5e94be105c834c59db0',
      'native_key' => 'editor_css_selectors',
      'filename' => 'modSystemSetting/37cd0341c4d579a6b949aef0e725003d.vehicle',
    ),
    267 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1f8bf689c26c5d294152ee6c5cb0d654',
      'native_key' => 'emailsender',
      'filename' => 'modSystemSetting/f0e694ec151b284c23507f65ccd125c0.vehicle',
    ),
    268 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '94337ac6c694b033b781c99d9df3d1e5',
      'native_key' => 'emailsubject',
      'filename' => 'modSystemSetting/275c87976430253128af1f4db8878299.vehicle',
    ),
    269 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '300e1853729a5b3754a319b567d1d437',
      'native_key' => 'enable_dragdrop',
      'filename' => 'modSystemSetting/61b0e4ca94ac4768824081e8a99a36f0.vehicle',
    ),
    270 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2d8b0ea1284b34d30930e3aa533ef2eb',
      'native_key' => 'error_page',
      'filename' => 'modSystemSetting/0be7c83dbc76514c3cf8419121a203ea.vehicle',
    ),
    271 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '290bc370ad3b2a51e396001056859f58',
      'native_key' => 'failed_login_attempts',
      'filename' => 'modSystemSetting/0aa396519a1c7f7a311dbe3933f981fa.vehicle',
    ),
    272 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7885f71de55a4a2c0116906299bd9816',
      'native_key' => 'fe_editor_lang',
      'filename' => 'modSystemSetting/c3696e7845c69ccbb164b926e1d2fbbc.vehicle',
    ),
    273 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6e24476b8bb2d54924b6f207bd51b8ec',
      'native_key' => 'feed_modx_news',
      'filename' => 'modSystemSetting/eb8ed5c858d539c606e56168feb8bf23.vehicle',
    ),
    274 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2b378af4ae5f86024945a0be335e675b',
      'native_key' => 'feed_modx_news_enabled',
      'filename' => 'modSystemSetting/cd6f4adead93a652de3e6885da1d3363.vehicle',
    ),
    275 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9fed3b4330519549d8692beed4255a5d',
      'native_key' => 'feed_modx_security',
      'filename' => 'modSystemSetting/f2a059bd25bfa63f7e90e9a6ca6f2241.vehicle',
    ),
    276 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '799435e651c96a74643dde295b5add3e',
      'native_key' => 'feed_modx_security_enabled',
      'filename' => 'modSystemSetting/b54f49a34a0d4ae40e4028530e266e87.vehicle',
    ),
    277 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd4c5bc3fd92897df084c26a2c37f1bc2',
      'native_key' => 'filemanager_path',
      'filename' => 'modSystemSetting/899aef2497e042b9c63ea1056f37f8df.vehicle',
    ),
    278 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e4f531fcb865f2253288306cfa9ff209',
      'native_key' => 'filemanager_path_relative',
      'filename' => 'modSystemSetting/ed856fded4febf04bb810b731db827bc.vehicle',
    ),
    279 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '001b7e435cf21951cece8df45dd30d94',
      'native_key' => 'filemanager_url',
      'filename' => 'modSystemSetting/7d64941085696d0a85fd09d090042885.vehicle',
    ),
    280 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd39ab66b9c60ffe51f55e6eef2d32bbb',
      'native_key' => 'filemanager_url_relative',
      'filename' => 'modSystemSetting/5c44d0e7086dfefa394604dd54f10fe6.vehicle',
    ),
    281 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'cfb10877dd94334d8c4ccd937978b461',
      'native_key' => 'forgot_login_email',
      'filename' => 'modSystemSetting/c1d947e0f51c7df39437a86348d1e959.vehicle',
    ),
    282 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c82de372f43e00a1f7901312fe314b14',
      'native_key' => 'form_customization_use_all_groups',
      'filename' => 'modSystemSetting/1410fcc2fedc814a8d6232d9afa7f8b4.vehicle',
    ),
    283 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e907a79bf55ea9e10effbc311935456b',
      'native_key' => 'forward_merge_excludes',
      'filename' => 'modSystemSetting/f14a9faf913b93f610ed53c4b7f037d0.vehicle',
    ),
    284 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9b5a15ac283fab591f1a779f34559392',
      'native_key' => 'friendly_alias_lowercase_only',
      'filename' => 'modSystemSetting/6529522e6c26dc415749aa30456eb933.vehicle',
    ),
    285 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '254d75d5629346fb143d8b795fdab10f',
      'native_key' => 'friendly_alias_max_length',
      'filename' => 'modSystemSetting/9c52051841240cc993f584c736006b27.vehicle',
    ),
    286 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd15acd788a635f6d7a7af3bb0c25d1f9',
      'native_key' => 'friendly_alias_realtime',
      'filename' => 'modSystemSetting/50160a55d12f6a368f9302eadfb95322.vehicle',
    ),
    287 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '50d5b099c3948df8ca37408395312eea',
      'native_key' => 'friendly_alias_restrict_chars',
      'filename' => 'modSystemSetting/2a85fb5748e5d7927f7ead2b758070f5.vehicle',
    ),
    288 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7f375a368527d7e37ac518c6a935e2cf',
      'native_key' => 'friendly_alias_restrict_chars_pattern',
      'filename' => 'modSystemSetting/d1cd3ff70a694bb2c230bc25c49224bf.vehicle',
    ),
    289 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e92e1f797c29830874c01b4c63666e81',
      'native_key' => 'friendly_alias_strip_element_tags',
      'filename' => 'modSystemSetting/58dddcc2b044f655a2f18064a86040c4.vehicle',
    ),
    290 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5e032ed182fd5c3773b485c5a983339c',
      'native_key' => 'friendly_alias_translit',
      'filename' => 'modSystemSetting/ea52bfd76ffb36db8642d3572167d748.vehicle',
    ),
    291 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4610d601ab8afac5b06cad9894f16ea5',
      'native_key' => 'friendly_alias_translit_class',
      'filename' => 'modSystemSetting/bafc77e4df87b338cd1ffab2b9291753.vehicle',
    ),
    292 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '57755e3faf9defc056deea7291f3444a',
      'native_key' => 'friendly_alias_translit_class_path',
      'filename' => 'modSystemSetting/d0b5ae05b14b8e794602982ef7131bf5.vehicle',
    ),
    293 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7edbb8b7873bac75545c5eb744537b6b',
      'native_key' => 'friendly_alias_trim_chars',
      'filename' => 'modSystemSetting/82e15d88eec0cd63269d7f7522637bf7.vehicle',
    ),
    294 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'deb7bd8c34cd82ed2de0a6773ccfc0c6',
      'native_key' => 'friendly_alias_word_delimiter',
      'filename' => 'modSystemSetting/9ee6acc5017062d1101c2645c19456eb.vehicle',
    ),
    295 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '54696e5ad35a95ee46e9a832cf9b3c54',
      'native_key' => 'friendly_alias_word_delimiters',
      'filename' => 'modSystemSetting/67e3ff82d5d580cc65486c90f936824d.vehicle',
    ),
    296 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd47c5befde9486841b3c50d52931ec05',
      'native_key' => 'friendly_urls',
      'filename' => 'modSystemSetting/5e6aa91185ade970421ee7c79bb69a9d.vehicle',
    ),
    297 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4e92ca12d490a46d3e9295b78cf96dce',
      'native_key' => 'friendly_urls_strict',
      'filename' => 'modSystemSetting/c0f354ca52d9b7b472aff2323bc458b5.vehicle',
    ),
    298 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9d78726c751921df9309b999392e68f1',
      'native_key' => 'use_frozen_parent_uris',
      'filename' => 'modSystemSetting/a5a62f72d610af343361fb53f63c5b95.vehicle',
    ),
    299 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9c320f9115b35eaba71d5520fd678b03',
      'native_key' => 'global_duplicate_uri_check',
      'filename' => 'modSystemSetting/e3f1fa109721dc96ae46b54c27ba6dad.vehicle',
    ),
    300 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '725e348012d1963498d618b83d7cd40b',
      'native_key' => 'hidemenu_default',
      'filename' => 'modSystemSetting/34d62271c592c94fc02cfe5ea4b6f3a6.vehicle',
    ),
    301 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '425025ee16e4c366dd676a73f0f6f76a',
      'native_key' => 'inline_help',
      'filename' => 'modSystemSetting/946155bb194d7e29cce962688fe10c8d.vehicle',
    ),
    302 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b783766cc795a9b09786d0edbf54f20b',
      'native_key' => 'locale',
      'filename' => 'modSystemSetting/d84dbf4c2a73c9ea26eb738d90f09572.vehicle',
    ),
    303 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a165ea697499c6053439c50da2f86095',
      'native_key' => 'log_level',
      'filename' => 'modSystemSetting/7ba62647cd0447a84b85ecacc8c6bf92.vehicle',
    ),
    304 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '83cae04a6fff42f24d29f3ec8613543f',
      'native_key' => 'log_target',
      'filename' => 'modSystemSetting/3013483dd769844dcf76da3b9d169d57.vehicle',
    ),
    305 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6efd4fa9bce4100d0571a75b9e96ab7d',
      'native_key' => 'log_deprecated',
      'filename' => 'modSystemSetting/00da464fdb9f708edf98f643571bc71e.vehicle',
    ),
    306 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e8613391be68eccdf90a8595acbc7f3d',
      'native_key' => 'link_tag_scheme',
      'filename' => 'modSystemSetting/17689e24aa4df9e8b6d810b9dac47f7e.vehicle',
    ),
    307 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b10bd07ba3168f18e0e5bb03b8695575',
      'native_key' => 'lock_ttl',
      'filename' => 'modSystemSetting/341bdf8e9b333a5e580e71f31c8ed3b3.vehicle',
    ),
    308 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '50561a07b44348a1e2b3595ac873c049',
      'native_key' => 'mail_charset',
      'filename' => 'modSystemSetting/1c69ebf88ff85862aa16b422f7651ad9.vehicle',
    ),
    309 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1a30b87330c8766a359cdc2381fbe227',
      'native_key' => 'mail_encoding',
      'filename' => 'modSystemSetting/3190fad4c6bf152566e52e777d4fae2a.vehicle',
    ),
    310 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6e859d9718b4783959eef3a192bf3b4b',
      'native_key' => 'mail_use_smtp',
      'filename' => 'modSystemSetting/5e83ee369d6fc303f8b721b7f1ceb823.vehicle',
    ),
    311 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8ff2b3f5d13e0f4c49b05106c69cc081',
      'native_key' => 'mail_smtp_auth',
      'filename' => 'modSystemSetting/039acf22ca2daf68f49add0cb709074b.vehicle',
    ),
    312 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fbbd48cff2fc295d91e7056206fd03c9',
      'native_key' => 'mail_smtp_helo',
      'filename' => 'modSystemSetting/4b9828115220c884d4b5c70ffcfb9a63.vehicle',
    ),
    313 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a23b3960943a181a11f8acf1464d14e4',
      'native_key' => 'mail_smtp_hosts',
      'filename' => 'modSystemSetting/bc750cd04276d9e28c1fd76c9cbe4c16.vehicle',
    ),
    314 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '75e85314f896b21bb9ce0b4a0138fee1',
      'native_key' => 'mail_smtp_keepalive',
      'filename' => 'modSystemSetting/757bedef1e3a6a128f1ca8201f21f340.vehicle',
    ),
    315 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '36e3e47a81ede628946c0c1e7705c593',
      'native_key' => 'mail_smtp_pass',
      'filename' => 'modSystemSetting/f1d3a9ca6088f2dc2ac63e5d8034f0c4.vehicle',
    ),
    316 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '33eda1b4ef92edbb944db34997bb69ac',
      'native_key' => 'mail_smtp_port',
      'filename' => 'modSystemSetting/2a4ff277c503dbfd717acd5c9804faf5.vehicle',
    ),
    317 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9d8e0f6a16baf639561ad8585e7395b6',
      'native_key' => 'mail_smtp_prefix',
      'filename' => 'modSystemSetting/7e3b95b988e34672a26b193d1a80d6aa.vehicle',
    ),
    318 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3f74ddfea4b0c71197585055104b4db0',
      'native_key' => 'mail_smtp_single_to',
      'filename' => 'modSystemSetting/8c5c2e761259c77f5988a93067d0d7e4.vehicle',
    ),
    319 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4e9f8439ed4b7980a5895e34c0f6dc2e',
      'native_key' => 'mail_smtp_timeout',
      'filename' => 'modSystemSetting/d13a862ffaba11a08929c9dc627077db.vehicle',
    ),
    320 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '091095fcf9a165d3c6265f3a5f9281a0',
      'native_key' => 'mail_smtp_user',
      'filename' => 'modSystemSetting/3e64924dd297ff3e68e813ebef6ccde4.vehicle',
    ),
    321 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '10ab09a3d249579d1e80540fdc64eb9c',
      'native_key' => 'manager_date_format',
      'filename' => 'modSystemSetting/0431787bc13fa813880331a399a27955.vehicle',
    ),
    322 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '40f456c389000c9594d36a492ed2529b',
      'native_key' => 'manager_favicon_url',
      'filename' => 'modSystemSetting/199edecc0b02fe88f3f8e252bd662a7a.vehicle',
    ),
    323 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7b1cf77842c145e00023cc4677171f05',
      'native_key' => 'manager_js_cache_file_locking',
      'filename' => 'modSystemSetting/83c54048e724800e1c6843ad54b9ccf3.vehicle',
    ),
    324 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '683dbc6b87ebeffc07bfba82d153a63c',
      'native_key' => 'manager_js_cache_max_age',
      'filename' => 'modSystemSetting/c9c534e899632387820f8161c2b042af.vehicle',
    ),
    325 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7d0c32079fb83de91d471fc4c8d57c63',
      'native_key' => 'manager_js_document_root',
      'filename' => 'modSystemSetting/484451641036fb17d71d335110c6349e.vehicle',
    ),
    326 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '559079b111e0475fc6d8678ddcee9552',
      'native_key' => 'manager_js_zlib_output_compression',
      'filename' => 'modSystemSetting/7338356ade9c37a4ce03e406e3b50ab5.vehicle',
    ),
    327 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '685247362e5f4be4296477b723a070ff',
      'native_key' => 'manager_time_format',
      'filename' => 'modSystemSetting/474fa9a595e6f62a38411577dfedc7c8.vehicle',
    ),
    328 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '706050d547ccfc57c6d82ae2e466d503',
      'native_key' => 'manager_direction',
      'filename' => 'modSystemSetting/8ff87bf1d2571b48f7bae390d37d8bbe.vehicle',
    ),
    329 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '904dcbe5280f7eefd9d600e83ef8b3dc',
      'native_key' => 'manager_lang_attribute',
      'filename' => 'modSystemSetting/cdc94e60584d5e32f1e17ea331ab1e2a.vehicle',
    ),
    330 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '66fe359b6bf54ee467c9dba0c7ca1ae0',
      'native_key' => 'manager_language',
      'filename' => 'modSystemSetting/a32e9bc15cebf3e081baf12f5ea20a45.vehicle',
    ),
    331 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c2d36177acb4bf7c72ea8e4028e2378e',
      'native_key' => 'manager_login_url_alternate',
      'filename' => 'modSystemSetting/7e1d4bd9a7db60d79ecd5e9d308d7024.vehicle',
    ),
    332 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a0aa4ac286ec8cc13f69c1167a85527d',
      'native_key' => 'manager_theme',
      'filename' => 'modSystemSetting/1e16edd30e4e6b29d1c260b27a61d9be.vehicle',
    ),
    333 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6f7dc30a4042e54d0feff48d77a30dc9',
      'native_key' => 'manager_week_start',
      'filename' => 'modSystemSetting/7745b71643e5cdf4f2e1da9438033484.vehicle',
    ),
    334 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'cc86e06bb513e4926e605f86e8428a70',
      'native_key' => 'modx_browser_tree_hide_files',
      'filename' => 'modSystemSetting/c341cc51f5cc9d0c45220a2ff314d843.vehicle',
    ),
    335 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1cedc5163d6c20872860d4f161c7e5f8',
      'native_key' => 'modx_browser_tree_hide_tooltips',
      'filename' => 'modSystemSetting/2218a6234f4569ea9fd084fb874a53de.vehicle',
    ),
    336 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f032c88aef6e98a72649a0172c047db4',
      'native_key' => 'modx_browser_default_sort',
      'filename' => 'modSystemSetting/0afa01b58a29c907d0eda85e854e02c0.vehicle',
    ),
    337 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'becaec76c55afe1ea96dc18d4ae44817',
      'native_key' => 'modx_browser_default_viewmode',
      'filename' => 'modSystemSetting/d30b76fdb4c89a7dcac3df37c4fcffcc.vehicle',
    ),
    338 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2b876ef85fa54f7cbda00c545a8e512e',
      'native_key' => 'modx_charset',
      'filename' => 'modSystemSetting/28473a4c1a8e21957ed1eece73cce159.vehicle',
    ),
    339 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c59dce8daafc19d4269ba36127f381d2',
      'native_key' => 'principal_targets',
      'filename' => 'modSystemSetting/11bec99f68475e1e167bab27af90ccd4.vehicle',
    ),
    340 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2df529dcac1665219266d4e54f4b484e',
      'native_key' => 'proxy_auth_type',
      'filename' => 'modSystemSetting/8b221f18df497e55336a692188bb3d14.vehicle',
    ),
    341 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '993426a04b8566f88242c5a60059484c',
      'native_key' => 'proxy_host',
      'filename' => 'modSystemSetting/2bb298f66e87ab437ebd83fbd642b0ed.vehicle',
    ),
    342 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'feb4953ed53c278481161c8c55ee7aa7',
      'native_key' => 'proxy_password',
      'filename' => 'modSystemSetting/d2017737359847780e45a1a620b0bcb1.vehicle',
    ),
    343 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '22a0623b025379cc1613607d9e62184f',
      'native_key' => 'proxy_port',
      'filename' => 'modSystemSetting/a173e619709c06adecfccddab00266be.vehicle',
    ),
    344 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c024c567beb21d14c108d32497072922',
      'native_key' => 'proxy_username',
      'filename' => 'modSystemSetting/58671d8e5ff9c732744b49698c8a570c.vehicle',
    ),
    345 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8442a8d46ea53fffe43e1413a44441fe',
      'native_key' => 'password_generated_length',
      'filename' => 'modSystemSetting/233ffbe410e7fbfd08fe1cb976cb1410.vehicle',
    ),
    346 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '58cc796110e0139edfdf64f698f9202f',
      'native_key' => 'password_min_length',
      'filename' => 'modSystemSetting/02ae951572cf5ea399f526d976ca946a.vehicle',
    ),
    347 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9e8deb716360b919d0e0f8286e37e4c0',
      'native_key' => 'phpthumb_allow_src_above_docroot',
      'filename' => 'modSystemSetting/2f50e2705f69f9224c183dffd47763ba.vehicle',
    ),
    348 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e999125d17114d1572b92dd9a0f6c9e1',
      'native_key' => 'phpthumb_cache_maxage',
      'filename' => 'modSystemSetting/62312b0ebf2a3a596a119a8478853c60.vehicle',
    ),
    349 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '92af7d23db8a75e38f51c502082a4a28',
      'native_key' => 'phpthumb_cache_maxsize',
      'filename' => 'modSystemSetting/8a9489ab50a8d996812769e896f2f435.vehicle',
    ),
    350 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '247bc89a5e462612f04ded250ae75d0e',
      'native_key' => 'phpthumb_cache_maxfiles',
      'filename' => 'modSystemSetting/62a9b15911f5f752127ee1049c161f16.vehicle',
    ),
    351 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7a04c3242f16249c8254dc88e3386456',
      'native_key' => 'phpthumb_cache_source_enabled',
      'filename' => 'modSystemSetting/9437a84ee1886ecd2568d0c6881900e8.vehicle',
    ),
    352 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ba4158e22cdf94d23525e556f98d381c',
      'native_key' => 'phpthumb_document_root',
      'filename' => 'modSystemSetting/0f4efa0bfe16564206488a3b24bacb8f.vehicle',
    ),
    353 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '81fc4f653a71109eefd1d4e561b305a5',
      'native_key' => 'phpthumb_error_bgcolor',
      'filename' => 'modSystemSetting/62fa5204bac2722a1fa835f0a6c15acb.vehicle',
    ),
    354 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5aa075bc66bf810e3d7d4693de2e64dd',
      'native_key' => 'phpthumb_error_textcolor',
      'filename' => 'modSystemSetting/0d1f1c64a604052e6e7c6cf6636c6186.vehicle',
    ),
    355 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ede3f6904e1ce5caf2e7954e7dbce491',
      'native_key' => 'phpthumb_error_fontsize',
      'filename' => 'modSystemSetting/3648cc369a2d29f8c653de13e5474885.vehicle',
    ),
    356 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e05aa116b07a4dc85fa7be4f78f7cde0',
      'native_key' => 'phpthumb_far',
      'filename' => 'modSystemSetting/81f2beb53c3199619cb0b201147ba986.vehicle',
    ),
    357 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e711d1617981cacb4f219bb9b2878348',
      'native_key' => 'phpthumb_imagemagick_path',
      'filename' => 'modSystemSetting/0fc12b410ca0c0055d4a26b92a852772.vehicle',
    ),
    358 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '354fed39a4d281a224328bd5123b5e33',
      'native_key' => 'phpthumb_nohotlink_enabled',
      'filename' => 'modSystemSetting/dfdbf881ff11195b742a11f2d1013cfd.vehicle',
    ),
    359 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'dd7fbd9404feeff50f4cf7df0cd053f9',
      'native_key' => 'phpthumb_nohotlink_erase_image',
      'filename' => 'modSystemSetting/cbbfe73ca50c633c01980210a5157dac.vehicle',
    ),
    360 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '64a90adbc6c2e1ac10d639e6993dfbca',
      'native_key' => 'phpthumb_nohotlink_valid_domains',
      'filename' => 'modSystemSetting/85323546dd89297b832417194ce906f7.vehicle',
    ),
    361 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '17d87925bc43e002673430b63d82bee9',
      'native_key' => 'phpthumb_nohotlink_text_message',
      'filename' => 'modSystemSetting/79a7b4d7e44cbafbef315eea910a9dea.vehicle',
    ),
    362 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e7ef4b5fced570d7f22309e0bb14f5e1',
      'native_key' => 'phpthumb_nooffsitelink_enabled',
      'filename' => 'modSystemSetting/f6c07e0f51ec9093fc49ebd7701de23b.vehicle',
    ),
    363 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '15dd7b4263a117e6c7fee1f470c2b7bf',
      'native_key' => 'phpthumb_nooffsitelink_erase_image',
      'filename' => 'modSystemSetting/60b611bfc4aecf5f0b4705e16cdab540.vehicle',
    ),
    364 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9978529256f3a37212381688823fb6a7',
      'native_key' => 'phpthumb_nooffsitelink_require_refer',
      'filename' => 'modSystemSetting/4964eb6f9aa49267aa4690ec8d5e143c.vehicle',
    ),
    365 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e5ed4bfcca637f7f31598377aca9eb82',
      'native_key' => 'phpthumb_nooffsitelink_text_message',
      'filename' => 'modSystemSetting/1f938c228afad41bc6246ebe37cf7350.vehicle',
    ),
    366 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3f89a0dd134568b841a774da1082639f',
      'native_key' => 'phpthumb_nooffsitelink_valid_domains',
      'filename' => 'modSystemSetting/679f9fea8627751826a15309c867d78a.vehicle',
    ),
    367 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6b6f6e05777fb4a1fa83235b67035df7',
      'native_key' => 'phpthumb_nooffsitelink_watermark_src',
      'filename' => 'modSystemSetting/cb6126cc6b3fb70ebc16d8073f59dc48.vehicle',
    ),
    368 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7cb0bd1da5dd668d851cacf5d0e92bd2',
      'native_key' => 'phpthumb_zoomcrop',
      'filename' => 'modSystemSetting/ccd7c6e28589b6f4d08afc37553a4905.vehicle',
    ),
    369 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '05ceee43eeaa1bfc0b9cafa6a2822375',
      'native_key' => 'publish_default',
      'filename' => 'modSystemSetting/3e3544879fd022f289c1155c47b99e88.vehicle',
    ),
    370 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '16c94609e57866faa1d34d87ac3fd0b7',
      'native_key' => 'rb_base_dir',
      'filename' => 'modSystemSetting/780bbead2e2b5f900375100c320113e5.vehicle',
    ),
    371 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '61dd590c5073a9f1d2c71c72d488999d',
      'native_key' => 'rb_base_url',
      'filename' => 'modSystemSetting/f956ccb36a7f132c041a64a639427a37.vehicle',
    ),
    372 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c52cd178ce72369b4f5248b632a433e7',
      'native_key' => 'request_controller',
      'filename' => 'modSystemSetting/0cd8325a093279c9a9464a3ada11e59c.vehicle',
    ),
    373 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1df12b4d96ca4b9c9ecba957c22d2b6c',
      'native_key' => 'request_method_strict',
      'filename' => 'modSystemSetting/4278a2980ac8716b7ccfd4237319cc9e.vehicle',
    ),
    374 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '42d618301de56a80fcaf894331d526e6',
      'native_key' => 'request_param_alias',
      'filename' => 'modSystemSetting/3c8a55392c31d2568f136a5c5f6bb6b7.vehicle',
    ),
    375 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '26ce1c1407e087052cf38912edb215bf',
      'native_key' => 'request_param_id',
      'filename' => 'modSystemSetting/bb170ea5f19686674858927dc587a041.vehicle',
    ),
    376 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8ef9139ccb63c4eb11ad2485e3d5857e',
      'native_key' => 'resolve_hostnames',
      'filename' => 'modSystemSetting/5464e8d0758bcdd0612d843d81120203.vehicle',
    ),
    377 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6be706349103eb3d2cb3435946505522',
      'native_key' => 'resource_tree_node_name',
      'filename' => 'modSystemSetting/4918f9e618551ca52ebaa1bfd7bb9ba9.vehicle',
    ),
    378 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5d6a6f9e65a78a7114500e9bd9e0c67a',
      'native_key' => 'resource_tree_node_name_fallback',
      'filename' => 'modSystemSetting/b7f8ff51564ec1f44f0f09e109ea235e.vehicle',
    ),
    379 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3794069978c53e7bb9bcea4aa66333e9',
      'native_key' => 'resource_tree_node_tooltip',
      'filename' => 'modSystemSetting/f128bacfe11f526523d1ea3676532b76.vehicle',
    ),
    380 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '59c15e75e43d558166f9c47d29bfb750',
      'native_key' => 'richtext_default',
      'filename' => 'modSystemSetting/bfedb6c3330e1f42e23acb4aa56499e3.vehicle',
    ),
    381 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'cbb5919810a210cf22ea7300b0a03863',
      'native_key' => 'search_default',
      'filename' => 'modSystemSetting/a1bce6c80310e3ad1f10c9c7eb9ba63e.vehicle',
    ),
    382 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '00b0056d072c22d3e3768a23c18c6a81',
      'native_key' => 'server_offset_time',
      'filename' => 'modSystemSetting/9dc9edeccaac3c889b55e080237a5508.vehicle',
    ),
    383 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c0a23fe81ce6e49f20883e7f19f33368',
      'native_key' => 'server_protocol',
      'filename' => 'modSystemSetting/dcd9007f6fec4e789625baff727d7192.vehicle',
    ),
    384 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e6adf545bfa55e4feb13905ec0ce5608',
      'native_key' => 'session_cookie_domain',
      'filename' => 'modSystemSetting/21fec987c68ee1ed537013dcbb617137.vehicle',
    ),
    385 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'caafc02de802fb0c09297a46fff43138',
      'native_key' => 'default_username',
      'filename' => 'modSystemSetting/69d644ca15d305330ae5630c66494ab4.vehicle',
    ),
    386 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '40442530d8644f55fd26bc6542a9f674',
      'native_key' => 'anonymous_sessions',
      'filename' => 'modSystemSetting/ba68d86b4f83fea731057f16bdab8b59.vehicle',
    ),
    387 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f3bc1affad6bb196027a5b2ee114a702',
      'native_key' => 'session_cookie_lifetime',
      'filename' => 'modSystemSetting/48235ecd9313ec0fe15bc6de469908bf.vehicle',
    ),
    388 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ecd54a1bb5c08d7163cf47147871c092',
      'native_key' => 'session_cookie_path',
      'filename' => 'modSystemSetting/9a73e9ec3cb55ea368deb91b54ac1c41.vehicle',
    ),
    389 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4c44f9351ccdaf472495e50c7a1885da',
      'native_key' => 'session_cookie_secure',
      'filename' => 'modSystemSetting/2be4adc8642d4b3487b886282cd95787.vehicle',
    ),
    390 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c334153185d70e42c780099e8bfbfe76',
      'native_key' => 'session_cookie_httponly',
      'filename' => 'modSystemSetting/c135c64f1f504223617ad2380de2736e.vehicle',
    ),
    391 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e3ca29f42a4b28ad8a211394fffb79c3',
      'native_key' => 'session_gc_maxlifetime',
      'filename' => 'modSystemSetting/039aff195c758e31d7e3b5613e2f8321.vehicle',
    ),
    392 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2d0b31132e10506ed8ee5fafa8122534',
      'native_key' => 'session_handler_class',
      'filename' => 'modSystemSetting/2383f60058073258c055e2dced2284d7.vehicle',
    ),
    393 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f77012700b7b50400a6040962815eeb7',
      'native_key' => 'session_name',
      'filename' => 'modSystemSetting/8eb07df281ca8219fcb77f56d08064cf.vehicle',
    ),
    394 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ea53761ef98d5dbe4ac9850e1c269bcb',
      'native_key' => 'set_header',
      'filename' => 'modSystemSetting/a26b73e00404bfe2cb4ff25971f748a3.vehicle',
    ),
    395 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '570e3db50ccea3639bfb6473000e2ce4',
      'native_key' => 'send_poweredby_header',
      'filename' => 'modSystemSetting/b9515ad4bb7a8c47a2905b9294e99d32.vehicle',
    ),
    396 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2e451897d527fb2a2153fe4ee7d4b9ea',
      'native_key' => 'show_tv_categories_header',
      'filename' => 'modSystemSetting/d3bfc8c7acc5a120e46d59e0bc57977b.vehicle',
    ),
    397 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '45ca63565cd8210e579042ea1f7ff70f',
      'native_key' => 'signupemail_message',
      'filename' => 'modSystemSetting/e29c8a49baaa9d5b4c8b2e129f21abb5.vehicle',
    ),
    398 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e1cd37ea3326c84a6fbd3184477d8a31',
      'native_key' => 'site_name',
      'filename' => 'modSystemSetting/37398cbfe7d001132d00f4cf7867e41d.vehicle',
    ),
    399 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '54b1d15a9d08a3a79d8278bcf67ecc39',
      'native_key' => 'site_start',
      'filename' => 'modSystemSetting/9fefb9f4c69da11cb5a3bb6ef0242548.vehicle',
    ),
    400 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a2e3fab903c833b1cb636f30dab97de4',
      'native_key' => 'site_status',
      'filename' => 'modSystemSetting/a9325c7c01211bf454fedfd4a0ca309c.vehicle',
    ),
    401 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '23eb789f10c9e5258135ecb663bcf58d',
      'native_key' => 'site_unavailable_message',
      'filename' => 'modSystemSetting/9787f1ba69ab7e61387c7119e1d70565.vehicle',
    ),
    402 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '81974b1175d3ece12dfdb97bcc3b3354',
      'native_key' => 'site_unavailable_page',
      'filename' => 'modSystemSetting/bf359e7be80bf1587bd61fab0fcf9744.vehicle',
    ),
    403 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e4bcaabc3ac22e3d9d9f4bfe5e87012c',
      'native_key' => 'static_elements_automate_templates',
      'filename' => 'modSystemSetting/2fb3abfaa7b7f41281dd0d486f46fb7b.vehicle',
    ),
    404 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fca07f96c4619a8b80d39904d71e3ddf',
      'native_key' => 'static_elements_automate_tvs',
      'filename' => 'modSystemSetting/1bbd4977899b7fccb8f823f2733937eb.vehicle',
    ),
    405 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e7d175512faad230cfcdd883da3ac49c',
      'native_key' => 'static_elements_automate_chunks',
      'filename' => 'modSystemSetting/5830c2b7c81d088c0dec6e36218d40d6.vehicle',
    ),
    406 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'df783c9ad5a4d301e16457b1815ecd21',
      'native_key' => 'static_elements_automate_snippets',
      'filename' => 'modSystemSetting/f6979e772510406f20c31f6e1f3158a1.vehicle',
    ),
    407 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'efe668ffa988308593d340e16e5978e2',
      'native_key' => 'static_elements_automate_plugins',
      'filename' => 'modSystemSetting/6fd12d86f818a91ed8a2fdaf7af5e4bd.vehicle',
    ),
    408 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3aa13abc6eb9575ce46813192a3ea9cc',
      'native_key' => 'static_elements_default_mediasource',
      'filename' => 'modSystemSetting/21b98a0cbbc1024c65329b5e85aabaa2.vehicle',
    ),
    409 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '75309b6b185a7d225db637ff012a760e',
      'native_key' => 'static_elements_default_category',
      'filename' => 'modSystemSetting/af590006e8c54ebbec1329bc15850086.vehicle',
    ),
    410 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a77c07e9e030c3feee7fd01e628c5a5f',
      'native_key' => 'static_elements_basepath',
      'filename' => 'modSystemSetting/a7d8c00a0920a0dbd988c383b718799c.vehicle',
    ),
    411 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ab1e4dd6b9e859c83887536e6e9b67d6',
      'native_key' => 'strip_image_paths',
      'filename' => 'modSystemSetting/8225aa49d7459c3dc7a16f8e1c02d821.vehicle',
    ),
    412 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b9961a562e1ac71f3dca8a5184c07b78',
      'native_key' => 'symlink_merge_fields',
      'filename' => 'modSystemSetting/0affbaabcebf11ead9ae3370aab372e5.vehicle',
    ),
    413 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4bd03afd466bfad1c386de6f83c93cd1',
      'native_key' => 'syncsite_default',
      'filename' => 'modSystemSetting/6466d7bd6be2f5cd5b9b2c60eb3c293a.vehicle',
    ),
    414 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '031ffe9c884da720f3703874dbf3d6cb',
      'native_key' => 'topmenu_show_descriptions',
      'filename' => 'modSystemSetting/903e20e5c6e598fe6c603e6155f106e7.vehicle',
    ),
    415 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2cbd63a58b9ac9a08cd035b5fe0199a1',
      'native_key' => 'tree_default_sort',
      'filename' => 'modSystemSetting/76e7c6392d66ba7944aac138adec0e98.vehicle',
    ),
    416 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'eeceb275e930a0dc68e11fcda57a2a90',
      'native_key' => 'tree_root_id',
      'filename' => 'modSystemSetting/e3c9aac3a2a4ad763b9150a429d7969f.vehicle',
    ),
    417 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'dd14b6749a9d1ac30ddc86fe2e746e16',
      'native_key' => 'tvs_below_content',
      'filename' => 'modSystemSetting/977ba9fc183e8cce6515706c45450fff.vehicle',
    ),
    418 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '109c97a513cee09207cd0c50a6d5de9e',
      'native_key' => 'udperms_allowroot',
      'filename' => 'modSystemSetting/0e361097665e10678190c06aced946c6.vehicle',
    ),
    419 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0de7fe919651e6bf4b8c6a9c2afaada7',
      'native_key' => 'unauthorized_page',
      'filename' => 'modSystemSetting/f04fc8e3237f42a6225a4a62a1e64b09.vehicle',
    ),
    420 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '68bd4ffa9571f203ec979f19eaf685fa',
      'native_key' => 'upload_files',
      'filename' => 'modSystemSetting/016ed4ba099ca06e67f900878099093d.vehicle',
    ),
    421 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '351897b9d9ef0a558d8f342cb8c0e99d',
      'native_key' => 'upload_flash',
      'filename' => 'modSystemSetting/f3244427421b937be2f742c08e2db1b2.vehicle',
    ),
    422 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '09270b15f2678b5e75215c49a605ad40',
      'native_key' => 'upload_images',
      'filename' => 'modSystemSetting/3d2ff79daae5b58ee7238691ab18b3b6.vehicle',
    ),
    423 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '63468e97fd76aeea740c7ce3778e5697',
      'native_key' => 'upload_maxsize',
      'filename' => 'modSystemSetting/5c6a9ef297003dde578fd97bd83d1b6b.vehicle',
    ),
    424 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6bf65f6fcc9233403188b8f5be4a0d24',
      'native_key' => 'upload_media',
      'filename' => 'modSystemSetting/0dd2a62cc041bcc053b10a3ba0f4a872.vehicle',
    ),
    425 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '212878d75b90a7ae3c94e01284d58eca',
      'native_key' => 'use_alias_path',
      'filename' => 'modSystemSetting/7f3bba8e8cb8e1d7ff01ae5e9cfec992.vehicle',
    ),
    426 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a8b3702789e098429049584dead5b5b2',
      'native_key' => 'use_browser',
      'filename' => 'modSystemSetting/72650ec5190b7ee0308d7767121781db.vehicle',
    ),
    427 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a0b080ff5791f76a807c12d9d1bd01fc',
      'native_key' => 'use_editor',
      'filename' => 'modSystemSetting/a5b8cc87a1c2ed271c9bd63ab43484fd.vehicle',
    ),
    428 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5d6fd048390c5c367a29b3d2097d935d',
      'native_key' => 'use_multibyte',
      'filename' => 'modSystemSetting/bba9956088013095efa31d50c6a76b67.vehicle',
    ),
    429 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2d9edb824f3a7be0316196bd6817e6f4',
      'native_key' => 'use_weblink_target',
      'filename' => 'modSystemSetting/277828783cbd7489a7e19a761d225d69.vehicle',
    ),
    430 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '476355486bd99af4c3b6f77f0fbba95a',
      'native_key' => 'webpwdreminder_message',
      'filename' => 'modSystemSetting/ee189a564c22a9e26ba7d23da473ca7a.vehicle',
    ),
    431 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b768858dde2308d4807322643a5762ef',
      'native_key' => 'websignupemail_message',
      'filename' => 'modSystemSetting/9985b47794db6c015a4829ba5fea5744.vehicle',
    ),
    432 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '15ca6e2d81de450157ffa513898c0cc9',
      'native_key' => 'welcome_screen',
      'filename' => 'modSystemSetting/7628e0b342b8af4b79c6016ac4a158f6.vehicle',
    ),
    433 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6afc8adedcd7207095b22e84a928a65e',
      'native_key' => 'welcome_screen_url',
      'filename' => 'modSystemSetting/bece2741d039a2fc153def3d942ac9aa.vehicle',
    ),
    434 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1cc86ef38637fa8240c35fa312c1fbde',
      'native_key' => 'welcome_action',
      'filename' => 'modSystemSetting/2001d5c41f08c5a0094b2149d37789aa.vehicle',
    ),
    435 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '027f3d59340b3d16872fe44aeffbb591',
      'native_key' => 'welcome_namespace',
      'filename' => 'modSystemSetting/e8b60f35dedba811854cac2ed8d0cc72.vehicle',
    ),
    436 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8b7c91e643b0c3d5c4371b706d4a3e2f',
      'native_key' => 'which_editor',
      'filename' => 'modSystemSetting/42efa7a1a7af834da15ebc1e03205942.vehicle',
    ),
    437 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0793762f4af0f455f516f186ce3a4dc8',
      'native_key' => 'which_element_editor',
      'filename' => 'modSystemSetting/5b53b011019605efe49a24f533eb968e.vehicle',
    ),
    438 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'bf24be3aa964c7dd6666ddbc5f19b266',
      'native_key' => 'xhtml_urls',
      'filename' => 'modSystemSetting/5f3d66625fd568365dbfa26bf121cf28.vehicle',
    ),
    439 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4290021955f3501856f463bd1c1c8f9b',
      'native_key' => 'enable_gravatar',
      'filename' => 'modSystemSetting/abd6d7c477ddd7ecb5986cf6a58640cc.vehicle',
    ),
    440 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0812a30e8c8b4ec9c326dadd1fb4d937',
      'native_key' => 'mgr_tree_icon_context',
      'filename' => 'modSystemSetting/5bb162f437b8fd5af82776e56a6c58b8.vehicle',
    ),
    441 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ce17f78da1eed15d2e0e7d606769f8c5',
      'native_key' => 'mgr_source_icon',
      'filename' => 'modSystemSetting/4317c57bea76527da1c953209a4fab4c.vehicle',
    ),
    442 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2f7bcb85d56f34878cd79599be4bd75c',
      'native_key' => 'main_nav_parent',
      'filename' => 'modSystemSetting/7c157908c87025c2f053ca025436218b.vehicle',
    ),
    443 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9609979adebbaf557e7e4d0a4528eb43',
      'native_key' => 'user_nav_parent',
      'filename' => 'modSystemSetting/7e67bdf7b5755e3e7b90d4cb8a48aad1.vehicle',
    ),
    444 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '90f1a8f1adb068a1bb26ae7cfe2c2c7d',
      'native_key' => 'auto_isfolder',
      'filename' => 'modSystemSetting/7123b570a4f6b6cf9b02eb2ef455f251.vehicle',
    ),
    445 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'efdb5a75fcb2d58ac2628293510e088c',
      'native_key' => 'manager_use_fullname',
      'filename' => 'modSystemSetting/28df8d8b62fd8ed8ff2209563c96f644.vehicle',
    ),
    446 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e15e651fa9aa4c4963acb8ddac2e7ea0',
      'native_key' => 'parser_recurse_uncacheable',
      'filename' => 'modSystemSetting/1f288a70f6779e904ff2603ad9fc31e6.vehicle',
    ),
    447 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0b47a652c6a7a966a12210b2f70ed597',
      'native_key' => 'preserve_menuindex',
      'filename' => 'modSystemSetting/71fbb935fc438c1bc91c11b45967a0cb.vehicle',
    ),
    448 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b927275489d2c381ea26560a36878885',
      'native_key' => 'allow_tv_eval',
      'filename' => 'modSystemSetting/43b34dc48895d90302aba0f161324d41.vehicle',
    ),
    449 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b9e02d4797ab97b478f893457ab3a6f6',
      'native_key' => 'log_snippet_not_found',
      'filename' => 'modSystemSetting/3dc9f6c2f9423ed89f17f177c8e53029.vehicle',
    ),
    450 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f2bea1c6086df5a8f9672bc7bdd744cc',
      'native_key' => 'error_log_filename',
      'filename' => 'modSystemSetting/ee0272e40a02ec2cc696e385c2f4804a.vehicle',
    ),
    451 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '29d4637d9a0ffd0d904e4e6012d0a487',
      'native_key' => 'error_log_filepath',
      'filename' => 'modSystemSetting/425fcfaf4a845b216a50fdb7568140ad.vehicle',
    ),
    452 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContextSetting',
      'guid' => '2e8036195ef48860a800904350299db1',
      'native_key' => 
      array (
        0 => 'mgr',
        1 => 'allow_tags_in_post',
      ),
      'filename' => 'modContextSetting/e156698c1e3256ab2dc8eff6010cc056.vehicle',
    ),
    453 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContextSetting',
      'guid' => 'd136db0e69ffd23ab4df6ceb8f2c7306',
      'native_key' => 
      array (
        0 => 'mgr',
        1 => 'modRequest.class',
      ),
      'filename' => 'modContextSetting/2665e5427e9da918f47826a877fb16bd.vehicle',
    ),
    454 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modUserGroup',
      'guid' => '13ca8ae48f3fc1f677a27a006ac7bba9',
      'native_key' => 1,
      'filename' => 'modUserGroup/ba75e8a380d0e14b792a2b6f0b61cda1.vehicle',
    ),
    455 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDashboard',
      'guid' => '90a0805c876b9268438c1bd8cb2d8247',
      'native_key' => 1,
      'filename' => 'modDashboard/3235e9924f62562b54557c2402fd3f05.vehicle',
    ),
    456 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMediaSource',
      'guid' => '561b8f852b85673c757c9d3dd0fb8bdd',
      'native_key' => 1,
      'filename' => 'modMediaSource/c92f45efab9f16b2fb7423bc8c589706.vehicle',
    ),
    457 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDashboardWidget',
      'guid' => '8d700f4f69575315bd0220265950588c',
      'native_key' => NULL,
      'filename' => 'modDashboardWidget/209d7bf0febe97510ed092aad1f83821.vehicle',
    ),
    458 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDashboardWidget',
      'guid' => '5d1cefaa18b41ebc89567cb427b3712c',
      'native_key' => NULL,
      'filename' => 'modDashboardWidget/6aae84e5160b55e48efc654f0f673653.vehicle',
    ),
    459 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDashboardWidget',
      'guid' => 'c6ca555831441aee6d80301f8d39dc36',
      'native_key' => NULL,
      'filename' => 'modDashboardWidget/c2819f0c6213e8f120d512be8e38f95b.vehicle',
    ),
    460 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDashboardWidget',
      'guid' => '49856d3fc439d89b9b3874219355d533',
      'native_key' => NULL,
      'filename' => 'modDashboardWidget/635be3784206d02c3ec721de8ba9ffc8.vehicle',
    ),
    461 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDashboardWidget',
      'guid' => '76c6a8288fc6f44555df91015b48dda3',
      'native_key' => NULL,
      'filename' => 'modDashboardWidget/fafd22fa272cedd225ab66a9d11546d5.vehicle',
    ),
    462 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modUserGroupRole',
      'guid' => '0d62dc8fd75e6c4f93967beca43405fc',
      'native_key' => 1,
      'filename' => 'modUserGroupRole/5f808f0afe1dadcc6dcbcb42d35f9eb5.vehicle',
    ),
    463 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modUserGroupRole',
      'guid' => '88d090a00bc705633fe1139a47567b8d',
      'native_key' => 2,
      'filename' => 'modUserGroupRole/f801e1767ceb660f394de6da5c164f84.vehicle',
    ),
    464 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplateGroup',
      'guid' => '3855e2de134b42377cd0796f72ee074c',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplateGroup/0a9e012aaa339a5ce2852ae04d4d57bc.vehicle',
    ),
    465 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplateGroup',
      'guid' => '1a97ab45086ccd6e1f98b34f6dd97b30',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplateGroup/54d7f7763e4326a053f58864549489ad.vehicle',
    ),
    466 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplateGroup',
      'guid' => '067298736c1b15cd23e95b1541911a19',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplateGroup/03c767328251a3f8d2eef17d69857347.vehicle',
    ),
    467 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplateGroup',
      'guid' => '48a26445fd835ab9bbb3f43fce7935d5',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplateGroup/1fc37714831f4c823c4466044c5f864e.vehicle',
    ),
    468 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplateGroup',
      'guid' => 'eeb9811fa2c5c44eeed973a86e261e9b',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplateGroup/5de6994110ae8c321c9af26e569b32ef.vehicle',
    ),
    469 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplateGroup',
      'guid' => '207eeb743926a432c76f797a5bff1811',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplateGroup/a8eb33e3da4b0e3515156592d7f3b8e6.vehicle',
    ),
    470 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => '1a0700d6cbbd1d5c652046df8c24a61f',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/1506bc4e5bbe3001dd5969aee82961b3.vehicle',
    ),
    471 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => 'adbeda86636b1f7cd65de471af507554',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/e2a09049a8c4ef4fb1a24ac6570ce89d.vehicle',
    ),
    472 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => '581a4b5351b18df4d7f03ad01f85820f',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/8979f2dd974803afbf0b9217eee545df.vehicle',
    ),
    473 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => 'f1950e3df504f006eed9370b1802450e',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/3a0f1230946ac3f3785fe345521afdf3.vehicle',
    ),
    474 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => '7644d39bc7f13835dff99774031d3149',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/ff4b867dbba42a14eec573db65bb0235.vehicle',
    ),
    475 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => 'bf412e30440921eef3167c2148dbf0bb',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/0b142f3f2bd66e4aca7714727321f46a.vehicle',
    ),
    476 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => 'b4df6923096032f88f0d7ba44b5de727',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/b608ed9c6a46eda4e146e430ea530de1.vehicle',
    ),
    477 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '61a586e24dd7bee24b4fe1a3b2a6ec5b',
      'native_key' => 1,
      'filename' => 'modAccessPolicy/f05c6218152e0e1b284eecdfb3ea09cb.vehicle',
    ),
    478 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '66a1116c6c5d7feeddf85b017c8decae',
      'native_key' => 2,
      'filename' => 'modAccessPolicy/b402a7e55a1ff3649a48cc7d5ce3ad83.vehicle',
    ),
    479 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => 'e334a5b1f0ece1cc56239b278c75c38d',
      'native_key' => 3,
      'filename' => 'modAccessPolicy/3feff7b1ee1af89a9bec09cf66670d32.vehicle',
    ),
    480 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '18f715a7ca10d6fd2623b03f520a0d49',
      'native_key' => 4,
      'filename' => 'modAccessPolicy/c1688fb4b117ddd3f3640f690d3dd23c.vehicle',
    ),
    481 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => 'b264c86232033d2718ec6fdaba3096c9',
      'native_key' => 5,
      'filename' => 'modAccessPolicy/227656242a7e4409ffa66da746296862.vehicle',
    ),
    482 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '9b2a503d94294a9feb46ef61da7768e7',
      'native_key' => 6,
      'filename' => 'modAccessPolicy/4ca29eb55fdfe62b1ff6d51359aa4ee4.vehicle',
    ),
    483 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '9bb0a677af91ca376a1586dfd0783d35',
      'native_key' => 7,
      'filename' => 'modAccessPolicy/ae8bf890cc43ed353f36d807c88af6a9.vehicle',
    ),
    484 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => 'cb2928f55f9d4803205f187bb5092778',
      'native_key' => 8,
      'filename' => 'modAccessPolicy/39e8566b328fc128031918df35165db2.vehicle',
    ),
    485 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '22cec9f0a889919c832a244966b8bda1',
      'native_key' => 9,
      'filename' => 'modAccessPolicy/fe2bc52d3a69fa0eff7c98045ac4fdf5.vehicle',
    ),
    486 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => 'feb73db648caf33a5590b3a7a4859494',
      'native_key' => 10,
      'filename' => 'modAccessPolicy/4e6a6116dfa99c8793d70eea9f84add9.vehicle',
    ),
    487 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '25ddc370ea88664f3cd518c94f198b91',
      'native_key' => 11,
      'filename' => 'modAccessPolicy/882b6554d2691c2ecaf0aaa8071dc754.vehicle',
    ),
    488 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '70f3288ee3489bdcce6032144e002ce1',
      'native_key' => 12,
      'filename' => 'modAccessPolicy/892fdbe402c76ff9b992f228b629e6ef.vehicle',
    ),
    489 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContext',
      'guid' => '102df033ce3c0dfa075fc416738d5c42',
      'native_key' => 'web',
      'filename' => 'modContext/dc8e4f6646dcc1be0c29e45337773426.vehicle',
    ),
    490 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContext',
      'guid' => 'c6671cabeab3e2fff3df46413672676b',
      'native_key' => 'mgr',
      'filename' => 'modContext/4f8c6e47f98e3bac2fde790d47b73660.vehicle',
    ),
    491 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => '1c07aa867256c38d8311a83488256027',
      'native_key' => '1c07aa867256c38d8311a83488256027',
      'filename' => 'xPDOFileVehicle/288de0f0095a6975c18cfeb67de50493.vehicle',
    ),
    492 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => '50bde6941032ddd128d51f0ede378c74',
      'native_key' => '50bde6941032ddd128d51f0ede378c74',
      'filename' => 'xPDOFileVehicle/bdbefc98169e9096b6585ce0378c88c0.vehicle',
    ),
    493 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => '39bc08da4bf3cff85a74fc61ff9ef0e0',
      'native_key' => '39bc08da4bf3cff85a74fc61ff9ef0e0',
      'filename' => 'xPDOFileVehicle/3664069a8a2581cf2919412f571da6ff.vehicle',
    ),
    494 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => 'f9ad7405625da1e3fb0c014a81c13088',
      'native_key' => 'f9ad7405625da1e3fb0c014a81c13088',
      'filename' => 'xPDOFileVehicle/e40773cf4543b928a030668d8a35f70c.vehicle',
    ),
  ),
);