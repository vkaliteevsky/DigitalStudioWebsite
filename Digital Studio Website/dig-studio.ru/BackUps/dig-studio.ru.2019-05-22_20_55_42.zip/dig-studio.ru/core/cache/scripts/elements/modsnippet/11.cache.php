<?php  return '
require_once MODX_BASE_PATH.\'/assets/php/lib.php\';
return genWorkTile($link, $src, $name, $group);
return;
';