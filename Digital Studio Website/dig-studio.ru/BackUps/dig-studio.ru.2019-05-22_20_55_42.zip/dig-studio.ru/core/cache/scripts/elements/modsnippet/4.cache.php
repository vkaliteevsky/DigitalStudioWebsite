<?php  return '$modx->regClientCSS(MODX_ASSETS_URL."css/style.css");
$modx->regClientCSS(\'https://fonts.googleapis.com/icon?family=Material+Icons\');
return;
';