<?php  return array (
  'ace' => 
  array (
    'name' => 'ace',
    'path' => '/var/www/u0667852/data/www/dig-studio.ru/core/components/ace/',
    'assets_path' => '',
  ),
  'core' => 
  array (
    'name' => 'core',
    'path' => '/var/www/u0667852/data/www/dig-studio.ru/manager/',
    'assets_path' => '/var/www/u0667852/data/www/dig-studio.ru/manager/assets/',
  ),
  'modswiftmailer' => 
  array (
    'name' => 'modswiftmailer',
    'path' => '/var/www/u0667852/data/www/dig-studio.ru/core/model/modx/mail/swiftmailer/',
    'assets_path' => '',
  ),
  'seopro' => 
  array (
    'name' => 'seopro',
    'path' => '/var/www/u0667852/data/www/dig-studio.ru/core/components/seopro/',
    'assets_path' => '/var/www/u0667852/data/www/dig-studio.ru/assets/components/seopro/',
  ),
);