<?php
return array (
  'timestamp' => '2019-03-15 00:49:22',
  'level' => 'INFO',
  'msg' => 'Refresh successful!',
  'def' => '',
  'file' => '/connectors/index.php',
  'line' => '',
);
