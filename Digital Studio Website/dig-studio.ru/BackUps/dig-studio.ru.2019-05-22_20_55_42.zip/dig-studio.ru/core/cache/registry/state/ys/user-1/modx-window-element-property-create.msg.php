<?php
return array (
  'width' => 600,
  'height' => 462,
  'x' => 660,
  'y' => 229,
);
