<?php
return array (
  'timestamp' => '2019-03-20 14:06:42',
  'level' => 'INFO',
  'msg' => 'Processing automatic publishing dates',
  'def' => '',
  'file' => '/connectors/index.php',
  'line' => '',
);
