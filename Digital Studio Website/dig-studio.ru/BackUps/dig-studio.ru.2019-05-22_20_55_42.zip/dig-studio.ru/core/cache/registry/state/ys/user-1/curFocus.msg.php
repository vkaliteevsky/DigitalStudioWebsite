<?php
return 'modx-resource-published';
