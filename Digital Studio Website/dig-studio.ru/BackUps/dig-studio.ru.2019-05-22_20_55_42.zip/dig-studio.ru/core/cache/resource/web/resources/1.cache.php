<?php  return array (
  'resourceClass' => 'modDocument',
  'resource' => 
  array (
    'id' => 1,
    'type' => 'document',
    'contentType' => 'text/html',
    'pagetitle' => 'Создание и продвижение сайтов в Санкт-Петербурге',
    'longtitle' => 'Создание и продвижение сайтов в Санкт-Петербурге',
    'description' => 'Разработка креативных сайтов от профессиональной веб-студии. Создание адаптивного дизайна. Интернет-реклама и SEO-оптимизация. Разработка мобильных приложений.',
    'alias' => 'index',
    'alias_visible' => 1,
    'link_attributes' => '',
    'published' => 1,
    'pub_date' => 0,
    'unpub_date' => 0,
    'parent' => 0,
    'isfolder' => 0,
    'introtext' => '',
    'content' => '',
    'richtext' => 1,
    'template' => 2,
    'menuindex' => 0,
    'searchable' => 1,
    'cacheable' => 1,
    'createdby' => 1,
    'createdon' => 1552132725,
    'editedby' => 1,
    'editedon' => 1552597635,
    'deleted' => 0,
    'deletedon' => 0,
    'deletedby' => 0,
    'publishedon' => 0,
    'publishedby' => 0,
    'menutitle' => 'Главная',
    'donthit' => 0,
    'privateweb' => 0,
    'privatemgr' => 0,
    'content_dispo' => 0,
    'hidemenu' => 0,
    'class_key' => 'modDocument',
    'context_key' => 'web',
    'content_type' => 1,
    'uri' => 'index',
    'uri_override' => 0,
    'hide_children_in_tree' => 0,
    'show_in_tree' => 1,
    'properties' => NULL,
    'PhoneNumber' => 
    array (
      0 => 'PhoneNumber',
      1 => '+7 (812) 448-08-92',
      2 => 'default',
      3 => NULL,
      4 => 'text',
    ),
    '_content' => '<!DOCTYPE html>
<html>
<head>
    <title>Digital Studio - Создание и продвижение сайтов в Санкт-Петербурге</title>
    <base href="[[!++site_url]]" />
    <link rel="shortcut icon" href="/favicon.ico" type="image/x-icon">
    <meta name="robots" content="all" />
    <meta name="description" content="Разработка креативных сайтов от профессиональной веб-студии. Создание адаптивного дизайна. Интернет-реклама и SEO-оптимизация. Разработка мобильных приложений." />
    <meta name="keywords" content="заказать сайт,веб-студии спб,разработать сайт" />
    <meta charset="utf-8">
    <meta name="yandex-verification" content="f2b30d0ade77a2f3" />
    <!-- Yandex.Metrika counter -->
    <script type="text/javascript" >
       (function(m,e,t,r,i,k,a){m[i]=m[i]||function(){(m[i].a=m[i].a||[]).push(arguments)};
       m[i].l=1*new Date();k=e.createElement(t),a=e.getElementsByTagName(t)[0],k.async=1,k.src=r,a.parentNode.insertBefore(k,a)})
       (window, document, "script", "https://mc.yandex.ru/metrika/tag.js", "ym");
    
       ym(52772032, "init", {
            clickmap:true,
            trackLinks:true,
            accurateTrackBounce:true,
            webvisor:true
       });
    </script>
    <noscript><div><img src="https://mc.yandex.ru/watch/52772032" style="position:absolute; left:-9999px;" alt="" /></div></noscript>
<!-- /Yandex.Metrika counter -->
<!-- Global site tag (gtag.js) - Google Analytics -->
    <script async src="https://www.googletagmanager.com/gtag/js?id=UA-136491796-1"></script>
    <script>
      window.dataLayer = window.dataLayer || [];
      function gtag(){dataLayer.push(arguments);}
      gtag(\'js\', new Date());
      gtag(\'config\', \'UA-136491796-1\');
    </script>
<!-- /Google Counter -->
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js" integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy" crossorigin="anonymous"></script>
    <script>
        function callModal() {
            alert("Modal Called");
            $(\'#modal-success\').modal(\'show\');
        }
    </script>
    <!--
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    -->
    
</head>
<body>
<div class="modal fade" id="form1" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title text-center">Оставить заявку</h4>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form id="actualForm">
                    <div class="form-group">
                        <input class="form-control" type="text" id="inputName" aria-describedby="nameHelp" placeholder="Ваше имя" />
                    </div>
                    <div class="form-group">
                        <input type="tel" class="form-control" id="inputPhone" aria-describedby="phoneHelp" placeholder="+7 (921) 123-45-67" />
                        <div style="color: red; font-size: 0.9em; padding-left: 5px;">
                            <span id="errorPhoneIncorrectId" style="display: none;">* Введен некорректный номер телефона</span>
                            <span id="errorPhoneEmptyId" style="display: none;">* Не введен номер телефона</span>
                        </div>
                    </div>

                    <div class="form-group">
                        <input type="email" class="form-control" id="inputEmail" aria-describedby="emailHelp" placeholder="Email" />
                        <div class="invalid-feedback">
                            Введите корректный Email
                        </div>
                    </div>
                    <div class="form-group">
                        <input class="form-control" type="text" id="inputComment" aria-describedby="commentHelp" placeholder="Комментарий" />
                    </div>
                    <div class="form-check">
                        <input type="checkbox" class="form-check-input" id="licenceCheck" checked required>
                        <label class="form-check-label" for="exampleCheck1" id="licence-check-id">
                            Я согласен на передачу и обработку моих персональных данных в соответствии с
                            "<a href="/assets/legal/PC.pdf" target="_blank" rel="nofollow">Политикой конфиденциальности</a>"
                        </label>
                    </div>
                    <div class="form-group text-center mt-3">
                        <button type="button" class="btn btn-primary btn-md" id="ajaxSubmit" onclick="submitForm();">Отправить</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<div id="modal-success" class="modal fade">
    <div class="modal-dialog modal-confirm modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <div class="icon-box text-center">
                    <i class="material-icons">&#xE876;</i>
                </div>
                <button type="button" class="close" data-dismiss="modal">&times;</button>
            </div>
            <div class="modal-body text-center">
                <h5>Сообщение успешно отправлено!</h5>
                <p class="pt-2 pb-0 mb-0">Наши специалисты свяжутся с Вами в ближайшее время.</p>
                <button type="button" class="btn btn-success mb-0 mt-4" data-dismiss="modal"><span>Ok</span></button>
            </div>
        </div>
    </div>
</div>
<header class="header">
    <div class="container">
        <nav class="navbar navbar-expand-lg navbar-light" id="myNavbar">
            <a class="navbar-brand" href="/">
                <img class="img-logo" src="/assets/img/logos/logo-main.png" alt="Разработка и продвижение веб-сайтов" title="Разработка и продвижение сайтов в Санкт-Петербурге">
            </a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav ml-auto">
                    <li class="nav-item active">
                        <a class="nav-link mr-2" href="https://dig-studio.ru/" title="Главная">Главная</a>
                    </li>
                    <li class="nav-item ">
                        <a class="nav-link mr-2" href="portfolio" title="Портфолио">Портфолио</a>
                    </li>
                    
                    <li class="nav-item dropdown">
                        <!-- <a class="nav-link" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"> -->
                        <a class="nav-link" href="#" id="navbarDropdown">
                          Услуги
                        </a>
                        <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                          <a class="dropdown-item" href="/services/landing">Лендинг</a>
                          <a class="dropdown-item" href="/services/vizitka">Сайт-визитка</a>
                          <a class="dropdown-item" href="/services/web-design">Разработка веб-дизайна</a>
                        </div>
                    </li>
                    <li class="nav-item ">
                        <a class="nav-link mr-2" href="about" title="О компании">О нас</a>
                    </li>
                    <li class="nav-item ">
                        <a class="nav-link mr-2" href="contacts" title="Контакты">Контакты</a>
                    </li>
                </ul>
            </div>
            <div class="phone-button ml-0 ml-md-3 text-center text-sm-right">
                <a href="tel:+78124480892" onclick="ym(52772032, \'reachGoal\', \'phoneCallId\');"><button class="btn btn-primary btn-md" type="button">+7 (812) 448-08-92</button></a>
            </div>
        </nav>
    </div>
</header>
<img class="d-none d-lg-block" src="/assets/img/icons/scroll-up.png" id="btnUp" alt="Вверх" title="Вверх">
<div id="carouselIndicators" class="carousel slide" data-ride="carousel">
  <ol class="carousel-indicators">
    <li data-target="#carouselIndicators" data-slide-to="0" class="active"></li>
    <li data-target="#carouselIndicators" data-slide-to="1"></li>
    <li data-target="#carouselIndicators" data-slide-to="2"></li>
  </ol>
  <div class="carousel-inner">
    <div class="carousel-item active">
        <div class="jumbo-fill-img" style="background-image: url(\'/assets/img/jumbo/carousel-01.png\');"></div>
        <div class="carousel-caption d-none d-md-block">
            <h3>Разработка и продвижение сайтов</h3>
            <p class="pt-2">Мы создаем креативные сайты,<br />которые решают Ваши бизнес-задачи</p>
            <button type="button" class="btn btn-warning btn-lg" data-toggle="modal" data-target="#form1">Заказать</button>
        </div>
        <div class="carousel-caption d-block d-md-none">
            <h4>Разработка и продвижение сайтов</h4>
            <p class="pt-2" style="font-size:0.9em;">Мы создаем креативные сайты,<br />которые решают Ваши бизнес-задачи</p>
            <button type="button" class="btn btn-warning btn-md" data-toggle="modal" data-target="#form1">Заказать</button>
        </div>
    <!-- <img class="d-block w-100 jumbo-img img-fluid" src="/assets/img/jumbo/carousel-min-01.png" alt="First slide"> -->
    </div>
    <div class="carousel-item">
        <div class="jumbo-fill-img" style="background-image: url(\'/assets/img/jumbo/carousel-02.png\');"></div>
        <div class="carousel-caption d-none d-md-block">
            <h3>Интернет-реклама и SEO</h3>
            <p class="pt-2">Эффективное продвижение в Google и Яндекс</p>
            <button type="button" class="btn btn-warning btn-lg" data-toggle="modal" data-target="#form1">Заказать</button>
        </div>
        <div class="carousel-caption d-block d-md-none">
            <h4>Интернет-реклама и SEO</h4>
            <p class="pt-2" style="font-size:0.9">Эффективное продвижение в Google и Яндекс</p>
            <button type="button" class="btn btn-warning btn-md" data-toggle="modal" data-target="#form1">Заказать</button>
        </div>
    </div>
        <!-- <img class="d-block w-100 jumbo-img img-fluid" src="/assets/img/jumbo/carousel-min-02.png" alt="Second slide"> -->
    
    <div class="carousel-item">
        <div class="jumbo-fill-img" style="background-image: url(\'/assets/img/jumbo/carousel-03.png\');"></div>
        <div class="carousel-caption d-none d-md-block">
            <h3>Разработка мобильных приложений</h3>
            <p class="pt-2">Приложения под мобильные устройства <br />на платформах Android и IOS</p>
            <button type="button" class="btn btn-warning btn-lg" data-toggle="modal" data-target="#form1">Заказать</button>
        </div>
        <div class="carousel-caption d-block d-md-none">
            <h4>Разработка мобильных приложений</h4>
            <p class="pt-2" style="font-size:0.9em;">Приложения под мобильные устройства <br />на платформах Android и IOS</p>
            <button type="button" class="btn btn-warning btn-md" data-toggle="modal" data-target="#form1">Заказать</button>
        </div>
        <!-- <img class="d-block w-100 jumbo-img img-fluid" src="/assets/img/jumbo/carousel-min-03.png" alt="Third slide"> -->
    </div>
  </div>
  <a class="carousel-control-prev" href="#carouselIndicators" role="button" data-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="sr-only">Previous</span>
  </a>
  <a class="carousel-control-next" href="#carouselIndicators" role="button" data-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="sr-only">Next</span>
  </a>
</div>
<div class="container-fluid">
    <div class="row mt-4 mb-4">
        
    </div>
</div>
<div class="container-fluid mt-4">
    <div class="row">
        <div class="col">
            <h1 style="text-align: center;">
                Мы создаем креативные сайты для Вашего бизнеса
            </h1>
        </div>
    </div>
</div>
<div class="container-fluid">
    <div class="row mt-4 mb-4">
        
    </div>
</div>
<div class="container mt-4">
    <div class="row web-products">
        <div class="col-lg-4 col-md-6 col-sm-12 d-flex align-items-stretch">
            <!-- <div class="card mb-4 mt-4 card-container" onclick="showModalIfDesktopOrTablet();"> -->
                <div class="card mb-4 mt-4 card-container" onclick="window.location = \'services/landing\';">
                    <!-- <img class="card-img-top" src="/assets/img/web-products/landing.png"> -->
                    <div class="img-container">
                        <div class="card-img-top card-image-top" style="background-image: url(\'/assets/img/web-products/landing.png\');">
                            <h2 class="product-heading pl-3">Лендинг</h2>
                        </div>
                    </div>
                    <div class="card-body">
                        <p class="card-text">Основная задача <b>лендинга</b> – эффективная <b>продажа</b> определенного товара или услуги. Каждый товар уникален, поэтому мы создаем лендинги с учетом специфических особенностей Вашей компании.</p>
                    </div>
                    <ul class="list-group list-group-flush">
                        <li class="list-group-item price-heading-list"><span class="price-zone">&asymp; 40 000 ₽</span></span></li>
                    </ul>
                </div>
        </div>
        
        <div class="col-lg-4 col-md-6 col-sm-12 d-flex align-items-stretch">
            <div class="card mb-4 mt-4 card-container" onclick="window.location = \'services/vizitka\';">
                <div class="img-container">
                    <div class="card-img-top card-image-top" style="background-image: url(\'/assets/img/web-products/vizitka.png\');">
                        <h2 class="product-heading pl-3">Сайт-визитка</h2>
                    </div>
                </div>
                <div class="card-body">
                    <p class="card-text">Ключевой целью создания <b>сайта-визитки</b> является краткое представление компании или частного лица в интернете.
                    Основная задача - информирование и <b>формирование имиджа</b>.</p>
                </div>
                <ul class="list-group list-group-flush">
                    <li class="list-group-item price-heading-list"><span class="price-zone">&asymp; 40 000 ₽</span></li>
                </ul>
            </div>
        </div>
        <div class="col-lg-4 col-md-6 col-sm-12 d-flex align-items-stretch">
            <div class="card mb-4 mt-4 card-container" onclick="showModalIfDesktopOrTablet();">
                <div class="img-container">
                    <div class="card-img-top card-image-top" style="background-image: url(\'/assets/img/web-products/corporate.png\');">
                        <h2 class="product-heading pl-3">Корпоративный сайт</h2>
                    </div>
                </div>
                <div class="card-body">
                    <p class="card-text"><b>Корпоративный сайт</b> - это публичный информационный ресурс, формирующий <b>репутацию и имидж</b> Вашего бизнеса.
                    Через создание профессионального сайта <b>повышается узнаваемость и стоимость Вашего бренда</b>.</p>
                </div>
                <ul class="list-group list-group-flush">
                    <li class="list-group-item price-heading"><span class="price-zone">&asymp; 130 000 ₽</span></li>
                </ul>
            </div>
        </div>

        <div class="col-lg-4 col-md-6 col-sm-12 d-flex align-items-stretch">
            <div class="card mb-4 mt-4 card-container" onclick="showModalIfDesktopOrTablet();">
                <!-- <img class="card-img-top" src="/assets/img/web-products/landing.png"> -->
                <div class="img-container">
                    <div class="card-img-top card-image-top" style="background-image: url(\'/assets/img/web-products/blog.png\');">
                        <h2 class="product-heading pl-3">Личный блог</h2>
                    </div>
                </div>
                <div class="card-body">
                    <p class="card-text"><b>Личный блог</b> – это веб-ресурс, материалы на котором выкладываются на регулярной основе.
                    Сайт адаптируется под <b>SEO-оптимизацию</b>, в связи с чем он будет <b>продвигаться в поисквых системах</b> практически без Ваших усилий.</p>
                </div>
                <ul class="list-group list-group-flush">
                    <li class="list-group-item price-heading"><span class="price-zone">&asymp; 25 000 ₽</span></li>
                </ul>
            </div>
        </div>
        
        <div class="col-lg-4 col-md-6 col-sm-12 d-flex align-items-stretch">
            <div class="card mb-4 mt-4 card-container" onclick="showModalIfDesktopOrTablet();">
                <div class="img-container">
                    <div class="card-img-top card-image-top" style="background-image: url(\'/assets/img/web-products/shop.png\');">
                        <h2 class="product-heading pl-3">Интернет-магазин</h2>
                    </div>
                </div>
                <div class="card-body">
                    <p class="card-text"><b>Интернет-магазин</b> - это сложный программный комплекс, включающий в себя <b>интеграцию</b> с бухгалтерией, 
                    подключение интернет-эквайринга, системы мониторинга и многое другое. Создание интернет-магазина позволит Вам <b>увеличить продажи</b> и полностью <b>автоматизировать</b> процесс онлайн-торговли.</p>
                </div>
                <ul class="list-group list-group-flush">
                    <li class="list-group-item price-heading"><span class="price-zone">&asymp; 250 000 ₽</span></li>
                </ul>
            </div>
        </div>
        
        <div class="col-lg-4 col-md-6 col-sm-12 d-flex align-items-stretch">
            <div class="card mb-4 mt-4 card-container" onclick="showModalIfDesktopOrTablet();">
                <div class="img-container">
                    <div class="card-img-top card-image-top" style="background-image: url(\'/assets/img/web-products/portal.png\');">
                        <h2 class="product-heading pl-3">Web-портал</h2>
                    </div>
                </div>
                <div class="card-body">
                    <p class="card-text"><b>Web-портал</b> - это комплексная система, включающая в себя <b>личный кабинет</b>, панели администратора, системы <b>приема и учета платежей</b> и др.
                    Реализовывается взаимодействие с <b>мобильными приложениями</b>, удаленными базами данных и сторонними сервисами.</p>
                </div>
                <ul class="list-group list-group-flush">
                    <li class="list-group-item price-heading"><span class="price-zone">по договоренности</span></li>
                </ul>
            </div>
        </div>
    </div>
</div>

<div class="container">
    <div class="container-fluid mt-4">
    <div class="row">
        <div class="col">
            <h3 style="text-align: center;">
                Заполните бриф и узнайте точную стоимость Вашего проекта!
            </h3>
        </div>
    </div>
</div>
</div>
<div class="row">
    <div class="col text-center mt-3">
        <button type="button" class="btn btn-primary btn-lg" data-toggle="modal" data-target="#form1">Узнать точную стоимость</button>
    </div>
</div>
<div class="container-fluid">
    <div class="row mt-4 mb-4">
        
    </div>
</div>

<div class="container-fluid portfolio greyrow" id="our-works">
        <div class="container-fluid">
    <div class="row mt-4 mb-4">
        
    </div>
</div>
        <div class="container-fluid mt-4">
    <div class="row">
        <div class="col">
            <h3 style="text-align: center;">
                Примеры наших работ
            </h3>
        </div>
    </div>
</div>
    <div class="container">
        <div class="row">   
            <div class="col-lg-4 col-md-6 col-sm-12">
    <div class="portfolio-tile mt-4">
        <a href="https://dostom.ru/" target="_blank" rel="nofollow">
            <div class="card" style="width: 100%;" title="Доступная стоматология">
                <div class="background-img">
                    <div class="portfolio-img" style="background-image: url(\'/assets/img/portfolio/dostom.jpg\');">
                    </div>
                </div>
                <div class="card-body">
                    <p class="card-text">Медицинские центры</p>
                    <h5 class="card-title">Доступная стоматология</h5>
                </div>
            </div>
        </a>
    </div>
</div>
            <div class="col-lg-4 col-md-6 col-sm-12">
    <div class="portfolio-tile mt-4">
        <a href="http://makaronniki.ru/" target="_blank" rel="nofollow">
            <div class="card" style="width: 100%;" title="Ресторан Макаронники">
                <div class="background-img">
                    <div class="portfolio-img" style="background-image: url(\'/assets/img/portfolio/makaronniki.jpg\');">
                    </div>
                </div>
                <div class="card-body">
                    <p class="card-text">Рестораны, кафе</p>
                    <h5 class="card-title">Ресторан Макаронники</h5>
                </div>
            </div>
        </a>
    </div>
</div>
            <div class="col-lg-4 col-md-6 col-sm-12">
    <div class="portfolio-tile mt-4">
        <a href="http://spb.b-frant.ru/" target="_blank" rel="nofollow">
            <div class="card" style="width: 100%;" title="Франт">
                <div class="background-img">
                    <div class="portfolio-img" style="background-image: url(\'/assets/img/portfolio/frant.jpg\');">
                    </div>
                </div>
                <div class="card-body">
                    <p class="card-text">Салоны красоты, барбершопы</p>
                    <h5 class="card-title">Франт</h5>
                </div>
            </div>
        </a>
    </div>
</div>
            <div class="col-lg-4 col-md-6 col-sm-12">
    <div class="portfolio-tile mt-4">
        <a href="https://hlebnitca.ru/" target="_blank" rel="nofollow">
            <div class="card" style="width: 100%;" title="Хлебница">
                <div class="background-img">
                    <div class="portfolio-img" style="background-image: url(\'/assets/img/portfolio/hlebnica.jpg\');">
                    </div>
                </div>
                <div class="card-body">
                    <p class="card-text">Пекарни</p>
                    <h5 class="card-title">Хлебница</h5>
                </div>
            </div>
        </a>
    </div>
</div>
            <div class="col-lg-4 col-md-6 col-sm-12">
    <div class="portfolio-tile mt-4">
        <a href="https://www.legran-rest.ru/" target="_blank" rel="nofollow">
            <div class="card" style="width: 100%;" title="Legran">
                <div class="background-img">
                    <div class="portfolio-img" style="background-image: url(\'/assets/img/portfolio/legran.jpg\');">
                    </div>
                </div>
                <div class="card-body">
                    <p class="card-text">Рестораны, кафе</p>
                    <h5 class="card-title">Legran</h5>
                </div>
            </div>
        </a>
    </div>
</div>
            <div class="col-lg-4 col-md-6 col-sm-12">
    <div class="portfolio-tile mt-4">
        <a href="https://nerud-servis.ru/" target="_blank" rel="nofollow">
            <div class="card" style="width: 100%;" title="Nerud Service">
                <div class="background-img">
                    <div class="portfolio-img" style="background-image: url(\'/assets/img/portfolio/nerud.jpg\');">
                    </div>
                </div>
                <div class="card-body">
                    <p class="card-text">B2B-компании</p>
                    <h5 class="card-title">Nerud Service</h5>
                </div>
            </div>
        </a>
    </div>
</div>
        </div>
    </div>
    <div class="container-fluid">
    <div class="row mt-4 mb-4">
        
    </div>
</div>
</div>
<div class="row text-center mt-4 mb-4">
    <div class="col mt-4">
        <a href="portfolio"><button type="button" class="btn btn-primary btn-lg">Смотреть все работы</button></a>
    </div>
</div>
<div class="container-fluid">
    <div class="row mt-4 mb-4">
        
    </div>
</div>
<div class="container-fluid mt-4">
    <div class="row">
        <div class="col">
            <h3 style="text-align: center;">
                Почему клиенты выбирают нас?
            </h3>
        </div>
    </div>
</div>
<div class="container benefits">
    <div class="row mt-4 mb-4">
        <div class="col-12 d-block d-md-none">
            <h4 class="mt-3 text-center">Фокусируемся на потребностях заказчика</h4>
        </div>
        <div class="col-md-6  pt-1 pb-1">
            <img src="/assets/img/benefits/focus-on-requirements.jpg">
        </div>
        <div class="col-md-6">
            <h4 class="mt-3 d-none d-md-block">Фокусируемся на потребностях заказчика</h4>
            <p>Мы понимаем, что сайт является не столько целью, сколько инструментом достижения бизнес-задач заказчика.
            Именно поэтому во всей своей работе мы ориентируемся на потребности клиента и специфику его бизнеса.</p>
        </div>
    </div>
    <div class="container-fluid">
    <div class="row mt-4 mb-4">
        
    </div>
</div>
    <div class="row mt-4 mb-4">
        <div class="col-12 d-block d-md-none">
            <h4 class="mt-3 text-center">Используем системный подход к разработке креативного дизайна</h4>
        </div>
        <div class="col-md-6 order-md-1 order-3">
            <h4 class="mt-3 d-none d-md-block">Используем системный подход к разработке креативного дизайна</h4>
            <p>
                Поскольку "красота дизайна" в глазах разных людей является величиной относительной, мы разработали системный подход к созданию стильных дизайнерских решений, 
                который в точности соответствует бизнес-потребностям заказчиков.
                Мы аргументируем "каждый штрих" нашей работы, что обеспечивает надежный и измеримый процесс разработки дизайна и, в результате, 
                приводит к крайне высокой удовлетворенности заказчиков нашими креативными решениями.
            </p>  
        </div>
        <div class="col-md-6  pt-1 pb-1 order-md-3 order-1">
            <img src="/assets/img/benefits/web-design.png">
        </div>
    </div>
    <div class="container-fluid">
    <div class="row mt-4 mb-4">
        
    </div>
</div>
    <div class="row mt-4 mb-4">
        <div class="col-12 d-block d-md-none">
            <h4 class="mt-3 text-center">Создаем адаптивные сайты</h4>
        </div>
        <div class="col-md-6 pt-1 pb-1">
            <img src="/assets/img/benefits/adaptive-design.png">
        </div>
        <div class="col-md-6">
            <h4 class="mt-3 d-none d-md-block">Создаем адаптивные сайты</h4>
            <p>Дизайн и программный код сайтов и приложений реализовывается таким образом, чтобы безупречно выглядеть на всех устройствах - от небольших смартфонов до широкоформатных мониторов.</p>  
        </div>
    </div>
    <div class="container-fluid">
    <div class="row mt-4 mb-4">
        
    </div>
</div>
    <div class="row mt-4 mb-4">
        <div class="col-12 d-block d-md-none">
            <h4 class="mt-3 text-center">Строго соблюдаем поставленные сроки</h4>
        </div>
        <div class="col-md-6 order-md-1 order-3">
            <h4 class="mt-3 d-none d-md-block">Строго соблюдаем поставленные сроки</h4>
            <p>
                Мы выполняем поставленные задачи точно в оговоренные сроки. 
                Благодаря мастерству и профессионализму нашей команды, реализовываем проекты, в среднем, в 1.5 раза быстрее рынка.
            </p>  
        </div>
        <div class="col-md-6 pt-1 pb-1 order-md-3 order-1">
            <img src="/assets/img/benefits/timing.png" style="padding: 30px;">
        </div>
    </div>
    <div class="container-fluid">
    <div class="row mt-4 mb-4">
        
    </div>
</div>
</div>

<div class="container-fluid">
    <div class="container-fluid mt-4">
    <div class="row">
        <div class="col">
            <h3 style="text-align: center;">
                Оставьте заявку и наши специалисты ответят на все Ваши вопросы!
            </h3>
        </div>
    </div>
</div>
    <div class="row">
    <div class="col text-center mt-3">
        <button type="button" class="btn btn-primary btn-lg" data-toggle="modal" data-target="#form1">Оставить заявку</button>
    </div>
</div>
    <div class="container-fluid">
    <div class="row mt-4 mb-4">
        
    </div>
</div>
</div>
<div class="footer-background">
    <footer class="container">
        <div class="row row-with-logo">
            <div class="col-md-3 col-sm-12 text-center mt-4">
                <a href="/">
                    <img class="logo-img" src="/assets/img/logos/logo-main-white.png" alt="Создание и продвижение сайтов" title="Создание и продвижение сайтов в Санкт-Петербурге">
                </a>
            </div>
            <div class="col-md-3 col-sm-12 text-center mt-0 mt-md-4">
                <p>СПб, 16-я линия В.О., д. 75</p>
            </div>
            <div class="col-md-3 col-sm-12 text-center mt-0 mt-md-4">
                <a href="tel:+78124480892" onclick="ym(52772032, \'reachGoal\', \'phoneCallId\');"><p>+7 (812) 448-08-92</p></a>
            </div>
            <div class="col-md-3 col-sm-12 text-center mt-0 mt-md-4">
                <a href="mailto:info@dig-studio.ru"><p>info@dig-studio.ru</p></a>
            </div>
        </div>
        <hr>
        <div class="row">
            <div class="col mt-3 pb-2">
                <p style="text-align: center;">Создание сайтов и их продвижение в Санкт-Петербурге. Разработка мобильных приложений.<br>&copy; «Digital Studio» 2016-2019.</p>
            </div>
        </div>
    </footer>
</div>

<!--<script src="https://cdnjs.cloudflare.com/ajax/libs/1000hz-bootstrap-validator/0.11.9/validator.min.js"></script>-->
<script>
    function showModal() {
        $("#form1").modal(\'show\');
    }
    function showModalIfDesktopOrTablet() {
        var w = $(document).width();
        if (w >= 768) {
            showModal();
        }
    }
    $("#btnUp").on(\'click\', function() {
        jQuery(\'html,body\').animate({scrollTop:0},700);
    });
    function scrollTop() {
        
        
    }
    function validateForm() {
        var isChecked = $(\'#licenceCheck\').prop(\'checked\');
        if (!isChecked) {
            $(\'#licence-check-id\').attr(\'style\',  \'color: red\');
        } else {
            $(\'#licence-check-id\').removeAttr(\'style\');
        }
        var phone = document.getElementById(\'inputPhone\').value;
        var isPhoneOk = (phone.length >= 7);
        if (!isPhoneOk) {
            $(\'#form1 #inputPhone\').attr(\'style\', \'border: 1px solid red;\');
            if (phone.length == 0) {
                $(\'#form1 #errorPhoneIncorrectId\').attr(\'style\', \'display: none;\');
                $(\'#form1 #errorPhoneEmptyId\').attr(\'style\', \'display: inline;\');
            } else {
                $(\'#form1 #errorPhoneEmptyId\').attr(\'style\', \'display: none;\');
                $(\'#form1 #errorPhoneIncorrectId\').attr(\'style\', \'display: inline;\');
            }
        } else {
            $(\'#form1 #errorPhoneIncorrectId\').attr(\'style\', \'display: none;\');
            $(\'#form1 #errorPhoneEmptyId\').attr(\'style\', \'display: none;\');
            $(\'#form1 #inputPhone\').removeAttr(\'style\');
        }
        return isChecked && isPhoneOk;
    }
    function submitForm() {
        var inputEmail = document.getElementById("inputEmail").value;
        var inputPhone = document.getElementById("inputPhone").value;
        var inputName = document.getElementById("inputName").value;
        var inputComment = document.getElementById("inputComment").value;
        var isValid = validateForm();
        if (!isValid) {
            return;
        }
        $.ajax({
            type: \'POST\',
            url: \'https://dig-studio.ru/assets/php/mailer.php/\',
            data: { 
                \'inputEmail\': inputEmail, 
                \'inputPhone\': inputPhone,
                \'inputName\': inputName,
                \'inputComment\': inputComment
            },
            success: function(msg){
                //alert("Server Response:\\n" + msg);
                if (msg.localeCompare("200")==0) {
                    $("#modal-success").modal(\'show\');
                }
            }
        });
        ym(52772032, \'reachGoal\', \'sendFormId\');
        $("#form1").modal(\'hide\');
    }
</script>
</body>
</html>',
    '_isForward' => false,
    '_sjscripts' => 
    array (
      0 => '<link rel="stylesheet" href="/assets/css/style.css" type="text/css" />',
      1 => '<link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons" type="text/css" />',
    ),
    '_loadedjscripts' => 
    array (
      '/assets/css/style.css' => true,
      'https://fonts.googleapis.com/icon?family=Material+Icons' => true,
    ),
  ),
  'contentType' => 
  array (
    'id' => 1,
    'name' => 'HTML',
    'description' => 'HTML content',
    'mime_type' => 'text/html',
    'file_extensions' => '',
    'headers' => NULL,
    'binary' => 0,
  ),
  'policyCache' => 
  array (
  ),
  'elementCache' => 
  array (
    '[[*longtitle]]' => 'Создание и продвижение сайтов в Санкт-Петербурге',
    '[[*description]]' => 'Разработка креативных сайтов от профессиональной веб-студии. Создание адаптивного дизайна. Интернет-реклама и SEO-оптимизация. Разработка мобильных приложений.',
    '[[LinkExternals]]' => '',
    '[[$HEAD]]' => '<!DOCTYPE html>
<html>
<head>
    <title>Digital Studio - Создание и продвижение сайтов в Санкт-Петербурге</title>
    <base href="[[!++site_url]]" />
    <link rel="shortcut icon" href="/favicon.ico" type="image/x-icon">
    <meta name="robots" content="all" />
    <meta name="description" content="Разработка креативных сайтов от профессиональной веб-студии. Создание адаптивного дизайна. Интернет-реклама и SEO-оптимизация. Разработка мобильных приложений." />
    <meta name="keywords" content="заказать сайт,веб-студии спб,разработать сайт" />
    <meta charset="utf-8">
    <meta name="yandex-verification" content="f2b30d0ade77a2f3" />
    <!-- Yandex.Metrika counter -->
    <script type="text/javascript" >
       (function(m,e,t,r,i,k,a){m[i]=m[i]||function(){(m[i].a=m[i].a||[]).push(arguments)};
       m[i].l=1*new Date();k=e.createElement(t),a=e.getElementsByTagName(t)[0],k.async=1,k.src=r,a.parentNode.insertBefore(k,a)})
       (window, document, "script", "https://mc.yandex.ru/metrika/tag.js", "ym");
    
       ym(52772032, "init", {
            clickmap:true,
            trackLinks:true,
            accurateTrackBounce:true,
            webvisor:true
       });
    </script>
    <noscript><div><img src="https://mc.yandex.ru/watch/52772032" style="position:absolute; left:-9999px;" alt="" /></div></noscript>
<!-- /Yandex.Metrika counter -->
<!-- Global site tag (gtag.js) - Google Analytics -->
    <script async src="https://www.googletagmanager.com/gtag/js?id=UA-136491796-1"></script>
    <script>
      window.dataLayer = window.dataLayer || [];
      function gtag(){dataLayer.push(arguments);}
      gtag(\'js\', new Date());
      gtag(\'config\', \'UA-136491796-1\');
    </script>
<!-- /Google Counter -->
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js" integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy" crossorigin="anonymous"></script>
    <script>
        function callModal() {
            alert("Modal Called");
            $(\'#modal-success\').modal(\'show\');
        }
    </script>
    <!--
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    -->
    
</head>
<body>',
    '[[$ModalForm1]]' => '<div class="modal fade" id="form1" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title text-center">Оставить заявку</h4>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form id="actualForm">
                    <div class="form-group">
                        <input class="form-control" type="text" id="inputName" aria-describedby="nameHelp" placeholder="Ваше имя" />
                    </div>
                    <div class="form-group">
                        <input type="tel" class="form-control" id="inputPhone" aria-describedby="phoneHelp" placeholder="+7 (921) 123-45-67" />
                        <div style="color: red; font-size: 0.9em; padding-left: 5px;">
                            <span id="errorPhoneIncorrectId" style="display: none;">* Введен некорректный номер телефона</span>
                            <span id="errorPhoneEmptyId" style="display: none;">* Не введен номер телефона</span>
                        </div>
                    </div>

                    <div class="form-group">
                        <input type="email" class="form-control" id="inputEmail" aria-describedby="emailHelp" placeholder="Email" />
                        <div class="invalid-feedback">
                            Введите корректный Email
                        </div>
                    </div>
                    <div class="form-group">
                        <input class="form-control" type="text" id="inputComment" aria-describedby="commentHelp" placeholder="Комментарий" />
                    </div>
                    <div class="form-check">
                        <input type="checkbox" class="form-check-input" id="licenceCheck" checked required>
                        <label class="form-check-label" for="exampleCheck1" id="licence-check-id">
                            Я согласен на передачу и обработку моих персональных данных в соответствии с
                            "<a href="/assets/legal/PC.pdf" target="_blank" rel="nofollow">Политикой конфиденциальности</a>"
                        </label>
                    </div>
                    <div class="form-group text-center mt-3">
                        <button type="button" class="btn btn-primary btn-md" id="ajaxSubmit" onclick="submitForm();">Отправить</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>',
    '[[$ModalSuccess]]' => '<div id="modal-success" class="modal fade">
    <div class="modal-dialog modal-confirm modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <div class="icon-box text-center">
                    <i class="material-icons">&#xE876;</i>
                </div>
                <button type="button" class="close" data-dismiss="modal">&times;</button>
            </div>
            <div class="modal-body text-center">
                <h5>Сообщение успешно отправлено!</h5>
                <p class="pt-2 pb-0 mb-0">Наши специалисты свяжутся с Вами в ближайшее время.</p>
                <button type="button" class="btn btn-success mb-0 mt-4" data-dismiss="modal"><span>Ok</span></button>
            </div>
        </div>
    </div>
</div>',
    '[[IsPageActive? &pageTitle=`Главная`]]' => 'active',
    '[[IsPageActive? &pageTitle=`Портфолио`]]' => '',
    '[[IsPageActive? &pageTitle=`О компании`]]' => '',
    '[[IsPageActive? &pageTitle=`Контакты`]]' => '',
    '[[*PhoneNumber]]' => '+7 (812) 448-08-92',
    '[[$HEADER]]' => '<header class="header">
    <div class="container">
        <nav class="navbar navbar-expand-lg navbar-light" id="myNavbar">
            <a class="navbar-brand" href="/">
                <img class="img-logo" src="/assets/img/logos/logo-main.png" alt="Разработка и продвижение веб-сайтов" title="Разработка и продвижение сайтов в Санкт-Петербурге">
            </a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav ml-auto">
                    <li class="nav-item active">
                        <a class="nav-link mr-2" href="https://dig-studio.ru/" title="Главная">Главная</a>
                    </li>
                    <li class="nav-item ">
                        <a class="nav-link mr-2" href="portfolio" title="Портфолио">Портфолио</a>
                    </li>
                    
                    <li class="nav-item dropdown">
                        <!-- <a class="nav-link" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"> -->
                        <a class="nav-link" href="#" id="navbarDropdown">
                          Услуги
                        </a>
                        <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                          <a class="dropdown-item" href="/services/landing">Лендинг</a>
                          <a class="dropdown-item" href="/services/vizitka">Сайт-визитка</a>
                          <a class="dropdown-item" href="/services/web-design">Разработка веб-дизайна</a>
                        </div>
                    </li>
                    <li class="nav-item ">
                        <a class="nav-link mr-2" href="about" title="О компании">О нас</a>
                    </li>
                    <li class="nav-item ">
                        <a class="nav-link mr-2" href="contacts" title="Контакты">Контакты</a>
                    </li>
                </ul>
            </div>
            <div class="phone-button ml-0 ml-md-3 text-center text-sm-right">
                <a href="tel:+78124480892" onclick="ym(52772032, \'reachGoal\', \'phoneCallId\');"><button class="btn btn-primary btn-md" type="button">+7 (812) 448-08-92</button></a>
            </div>
        </nav>
    </div>
</header>',
    '[[$CarouselJumbo]]' => '<div id="carouselIndicators" class="carousel slide" data-ride="carousel">
  <ol class="carousel-indicators">
    <li data-target="#carouselIndicators" data-slide-to="0" class="active"></li>
    <li data-target="#carouselIndicators" data-slide-to="1"></li>
    <li data-target="#carouselIndicators" data-slide-to="2"></li>
  </ol>
  <div class="carousel-inner">
    <div class="carousel-item active">
        <div class="jumbo-fill-img" style="background-image: url(\'/assets/img/jumbo/carousel-01.png\');"></div>
        <div class="carousel-caption d-none d-md-block">
            <h3>Разработка и продвижение сайтов</h3>
            <p class="pt-2">Мы создаем креативные сайты,<br />которые решают Ваши бизнес-задачи</p>
            <button type="button" class="btn btn-warning btn-lg" data-toggle="modal" data-target="#form1">Заказать</button>
        </div>
        <div class="carousel-caption d-block d-md-none">
            <h4>Разработка и продвижение сайтов</h4>
            <p class="pt-2" style="font-size:0.9em;">Мы создаем креативные сайты,<br />которые решают Ваши бизнес-задачи</p>
            <button type="button" class="btn btn-warning btn-md" data-toggle="modal" data-target="#form1">Заказать</button>
        </div>
    <!-- <img class="d-block w-100 jumbo-img img-fluid" src="/assets/img/jumbo/carousel-min-01.png" alt="First slide"> -->
    </div>
    <div class="carousel-item">
        <div class="jumbo-fill-img" style="background-image: url(\'/assets/img/jumbo/carousel-02.png\');"></div>
        <div class="carousel-caption d-none d-md-block">
            <h3>Интернет-реклама и SEO</h3>
            <p class="pt-2">Эффективное продвижение в Google и Яндекс</p>
            <button type="button" class="btn btn-warning btn-lg" data-toggle="modal" data-target="#form1">Заказать</button>
        </div>
        <div class="carousel-caption d-block d-md-none">
            <h4>Интернет-реклама и SEO</h4>
            <p class="pt-2" style="font-size:0.9">Эффективное продвижение в Google и Яндекс</p>
            <button type="button" class="btn btn-warning btn-md" data-toggle="modal" data-target="#form1">Заказать</button>
        </div>
    </div>
        <!-- <img class="d-block w-100 jumbo-img img-fluid" src="/assets/img/jumbo/carousel-min-02.png" alt="Second slide"> -->
    
    <div class="carousel-item">
        <div class="jumbo-fill-img" style="background-image: url(\'/assets/img/jumbo/carousel-03.png\');"></div>
        <div class="carousel-caption d-none d-md-block">
            <h3>Разработка мобильных приложений</h3>
            <p class="pt-2">Приложения под мобильные устройства <br />на платформах Android и IOS</p>
            <button type="button" class="btn btn-warning btn-lg" data-toggle="modal" data-target="#form1">Заказать</button>
        </div>
        <div class="carousel-caption d-block d-md-none">
            <h4>Разработка мобильных приложений</h4>
            <p class="pt-2" style="font-size:0.9em;">Приложения под мобильные устройства <br />на платформах Android и IOS</p>
            <button type="button" class="btn btn-warning btn-md" data-toggle="modal" data-target="#form1">Заказать</button>
        </div>
        <!-- <img class="d-block w-100 jumbo-img img-fluid" src="/assets/img/jumbo/carousel-min-03.png" alt="Third slide"> -->
    </div>
  </div>
  <a class="carousel-control-prev" href="#carouselIndicators" role="button" data-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="sr-only">Previous</span>
  </a>
  <a class="carousel-control-next" href="#carouselIndicators" role="button" data-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="sr-only">Next</span>
  </a>
</div>',
    '[[$SpaceLine]]' => '<div class="container-fluid">
    <div class="row mt-4 mb-4">
        
    </div>
</div>',
    '[[$Zagolovok? &headingText=`Мы создаем креативные сайты для Вашего бизнеса` &level=1]]' => '<div class="container-fluid mt-4">
    <div class="row">
        <div class="col">
            <h1 style="text-align: center;">
                Мы создаем креативные сайты для Вашего бизнеса
            </h1>
        </div>
    </div>
</div>',
    '[[~10]]' => 'services/landing',
    '[[~11]]' => 'services/vizitka',
    '[[$WebProducts]]' => '<div class="container mt-4">
    <div class="row web-products">
        <div class="col-lg-4 col-md-6 col-sm-12 d-flex align-items-stretch">
            <!-- <div class="card mb-4 mt-4 card-container" onclick="showModalIfDesktopOrTablet();"> -->
                <div class="card mb-4 mt-4 card-container" onclick="window.location = \'services/landing\';">
                    <!-- <img class="card-img-top" src="/assets/img/web-products/landing.png"> -->
                    <div class="img-container">
                        <div class="card-img-top card-image-top" style="background-image: url(\'/assets/img/web-products/landing.png\');">
                            <h2 class="product-heading pl-3">Лендинг</h2>
                        </div>
                    </div>
                    <div class="card-body">
                        <p class="card-text">Основная задача <b>лендинга</b> – эффективная <b>продажа</b> определенного товара или услуги. Каждый товар уникален, поэтому мы создаем лендинги с учетом специфических особенностей Вашей компании.</p>
                    </div>
                    <ul class="list-group list-group-flush">
                        <li class="list-group-item price-heading-list"><span class="price-zone">&asymp; 40 000 ₽</span></span></li>
                    </ul>
                </div>
        </div>
        
        <div class="col-lg-4 col-md-6 col-sm-12 d-flex align-items-stretch">
            <div class="card mb-4 mt-4 card-container" onclick="window.location = \'services/vizitka\';">
                <div class="img-container">
                    <div class="card-img-top card-image-top" style="background-image: url(\'/assets/img/web-products/vizitka.png\');">
                        <h2 class="product-heading pl-3">Сайт-визитка</h2>
                    </div>
                </div>
                <div class="card-body">
                    <p class="card-text">Ключевой целью создания <b>сайта-визитки</b> является краткое представление компании или частного лица в интернете.
                    Основная задача - информирование и <b>формирование имиджа</b>.</p>
                </div>
                <ul class="list-group list-group-flush">
                    <li class="list-group-item price-heading-list"><span class="price-zone">&asymp; 40 000 ₽</span></li>
                </ul>
            </div>
        </div>
        <div class="col-lg-4 col-md-6 col-sm-12 d-flex align-items-stretch">
            <div class="card mb-4 mt-4 card-container" onclick="showModalIfDesktopOrTablet();">
                <div class="img-container">
                    <div class="card-img-top card-image-top" style="background-image: url(\'/assets/img/web-products/corporate.png\');">
                        <h2 class="product-heading pl-3">Корпоративный сайт</h2>
                    </div>
                </div>
                <div class="card-body">
                    <p class="card-text"><b>Корпоративный сайт</b> - это публичный информационный ресурс, формирующий <b>репутацию и имидж</b> Вашего бизнеса.
                    Через создание профессионального сайта <b>повышается узнаваемость и стоимость Вашего бренда</b>.</p>
                </div>
                <ul class="list-group list-group-flush">
                    <li class="list-group-item price-heading"><span class="price-zone">&asymp; 130 000 ₽</span></li>
                </ul>
            </div>
        </div>

        <div class="col-lg-4 col-md-6 col-sm-12 d-flex align-items-stretch">
            <div class="card mb-4 mt-4 card-container" onclick="showModalIfDesktopOrTablet();">
                <!-- <img class="card-img-top" src="/assets/img/web-products/landing.png"> -->
                <div class="img-container">
                    <div class="card-img-top card-image-top" style="background-image: url(\'/assets/img/web-products/blog.png\');">
                        <h2 class="product-heading pl-3">Личный блог</h2>
                    </div>
                </div>
                <div class="card-body">
                    <p class="card-text"><b>Личный блог</b> – это веб-ресурс, материалы на котором выкладываются на регулярной основе.
                    Сайт адаптируется под <b>SEO-оптимизацию</b>, в связи с чем он будет <b>продвигаться в поисквых системах</b> практически без Ваших усилий.</p>
                </div>
                <ul class="list-group list-group-flush">
                    <li class="list-group-item price-heading"><span class="price-zone">&asymp; 25 000 ₽</span></li>
                </ul>
            </div>
        </div>
        
        <div class="col-lg-4 col-md-6 col-sm-12 d-flex align-items-stretch">
            <div class="card mb-4 mt-4 card-container" onclick="showModalIfDesktopOrTablet();">
                <div class="img-container">
                    <div class="card-img-top card-image-top" style="background-image: url(\'/assets/img/web-products/shop.png\');">
                        <h2 class="product-heading pl-3">Интернет-магазин</h2>
                    </div>
                </div>
                <div class="card-body">
                    <p class="card-text"><b>Интернет-магазин</b> - это сложный программный комплекс, включающий в себя <b>интеграцию</b> с бухгалтерией, 
                    подключение интернет-эквайринга, системы мониторинга и многое другое. Создание интернет-магазина позволит Вам <b>увеличить продажи</b> и полностью <b>автоматизировать</b> процесс онлайн-торговли.</p>
                </div>
                <ul class="list-group list-group-flush">
                    <li class="list-group-item price-heading"><span class="price-zone">&asymp; 250 000 ₽</span></li>
                </ul>
            </div>
        </div>
        
        <div class="col-lg-4 col-md-6 col-sm-12 d-flex align-items-stretch">
            <div class="card mb-4 mt-4 card-container" onclick="showModalIfDesktopOrTablet();">
                <div class="img-container">
                    <div class="card-img-top card-image-top" style="background-image: url(\'/assets/img/web-products/portal.png\');">
                        <h2 class="product-heading pl-3">Web-портал</h2>
                    </div>
                </div>
                <div class="card-body">
                    <p class="card-text"><b>Web-портал</b> - это комплексная система, включающая в себя <b>личный кабинет</b>, панели администратора, системы <b>приема и учета платежей</b> и др.
                    Реализовывается взаимодействие с <b>мобильными приложениями</b>, удаленными базами данных и сторонними сервисами.</p>
                </div>
                <ul class="list-group list-group-flush">
                    <li class="list-group-item price-heading"><span class="price-zone">по договоренности</span></li>
                </ul>
            </div>
        </div>
    </div>
</div>
',
    '[[$Zagolovok? &headingText=`Заполните бриф и узнайте точную стоимость Вашего проекта!`]]' => '<div class="container-fluid mt-4">
    <div class="row">
        <div class="col">
            <h3 style="text-align: center;">
                Заполните бриф и узнайте точную стоимость Вашего проекта!
            </h3>
        </div>
    </div>
</div>',
    '[[$ButtonCenter? &link=`#form1` &text=`Узнать точную стоимость`]]' => '<div class="row">
    <div class="col text-center mt-3">
        <button type="button" class="btn btn-primary btn-lg" data-toggle="modal" data-target="#form1">Узнать точную стоимость</button>
    </div>
</div>',
    '[[$Zagolovok? &headingText=`Примеры наших работ`]]' => '<div class="container-fluid mt-4">
    <div class="row">
        <div class="col">
            <h3 style="text-align: center;">
                Примеры наших работ
            </h3>
        </div>
    </div>
</div>',
    '[[$WorkImage? &linkToSite=`https://dostom.ru/` &srcToImage=`/assets/img/portfolio/dostom.jpg` &name=`Доступная стоматология` &group=`Медицинские центры`]]' => '<div class="col-lg-4 col-md-6 col-sm-12">
    <div class="portfolio-tile mt-4">
        <a href="https://dostom.ru/" target="_blank" rel="nofollow">
            <div class="card" style="width: 100%;" title="Доступная стоматология">
                <div class="background-img">
                    <div class="portfolio-img" style="background-image: url(\'/assets/img/portfolio/dostom.jpg\');">
                    </div>
                </div>
                <div class="card-body">
                    <p class="card-text">Медицинские центры</p>
                    <h5 class="card-title">Доступная стоматология</h5>
                </div>
            </div>
        </a>
    </div>
</div>',
    '[[$WorkImage? &linkToSite=`http://makaronniki.ru/` &srcToImage=`/assets/img/portfolio/makaronniki.jpg` &name=`Ресторан Макаронники` &group=`Рестораны, кафе`]]' => '<div class="col-lg-4 col-md-6 col-sm-12">
    <div class="portfolio-tile mt-4">
        <a href="http://makaronniki.ru/" target="_blank" rel="nofollow">
            <div class="card" style="width: 100%;" title="Ресторан Макаронники">
                <div class="background-img">
                    <div class="portfolio-img" style="background-image: url(\'/assets/img/portfolio/makaronniki.jpg\');">
                    </div>
                </div>
                <div class="card-body">
                    <p class="card-text">Рестораны, кафе</p>
                    <h5 class="card-title">Ресторан Макаронники</h5>
                </div>
            </div>
        </a>
    </div>
</div>',
    '[[$WorkImage? &linkToSite=`http://spb.b-frant.ru/` &srcToImage=`/assets/img/portfolio/frant.jpg` &name=`Франт` &group=`Салоны красоты, барбершопы`]]' => '<div class="col-lg-4 col-md-6 col-sm-12">
    <div class="portfolio-tile mt-4">
        <a href="http://spb.b-frant.ru/" target="_blank" rel="nofollow">
            <div class="card" style="width: 100%;" title="Франт">
                <div class="background-img">
                    <div class="portfolio-img" style="background-image: url(\'/assets/img/portfolio/frant.jpg\');">
                    </div>
                </div>
                <div class="card-body">
                    <p class="card-text">Салоны красоты, барбершопы</p>
                    <h5 class="card-title">Франт</h5>
                </div>
            </div>
        </a>
    </div>
</div>',
    '[[$WorkImage? &linkToSite=`https://hlebnitca.ru/` &srcToImage=`/assets/img/portfolio/hlebnica.jpg` &name=`Хлебница` &group=`Пекарни`]]' => '<div class="col-lg-4 col-md-6 col-sm-12">
    <div class="portfolio-tile mt-4">
        <a href="https://hlebnitca.ru/" target="_blank" rel="nofollow">
            <div class="card" style="width: 100%;" title="Хлебница">
                <div class="background-img">
                    <div class="portfolio-img" style="background-image: url(\'/assets/img/portfolio/hlebnica.jpg\');">
                    </div>
                </div>
                <div class="card-body">
                    <p class="card-text">Пекарни</p>
                    <h5 class="card-title">Хлебница</h5>
                </div>
            </div>
        </a>
    </div>
</div>',
    '[[$WorkImage? &linkToSite=`https://www.legran-rest.ru/` &srcToImage=`/assets/img/portfolio/legran.jpg` &name=`Legran` &group=`Рестораны, кафе`]]' => '<div class="col-lg-4 col-md-6 col-sm-12">
    <div class="portfolio-tile mt-4">
        <a href="https://www.legran-rest.ru/" target="_blank" rel="nofollow">
            <div class="card" style="width: 100%;" title="Legran">
                <div class="background-img">
                    <div class="portfolio-img" style="background-image: url(\'/assets/img/portfolio/legran.jpg\');">
                    </div>
                </div>
                <div class="card-body">
                    <p class="card-text">Рестораны, кафе</p>
                    <h5 class="card-title">Legran</h5>
                </div>
            </div>
        </a>
    </div>
</div>',
    '[[$WorkImage? &linkToSite=`https://nerud-servis.ru/` &srcToImage=`/assets/img/portfolio/nerud.jpg` &name=`Nerud Service` &group=`B2B-компании`]]' => '<div class="col-lg-4 col-md-6 col-sm-12">
    <div class="portfolio-tile mt-4">
        <a href="https://nerud-servis.ru/" target="_blank" rel="nofollow">
            <div class="card" style="width: 100%;" title="Nerud Service">
                <div class="background-img">
                    <div class="portfolio-img" style="background-image: url(\'/assets/img/portfolio/nerud.jpg\');">
                    </div>
                </div>
                <div class="card-body">
                    <p class="card-text">B2B-компании</p>
                    <h5 class="card-title">Nerud Service</h5>
                </div>
            </div>
        </a>
    </div>
</div>',
    '[[~3]]' => 'portfolio',
    '[[$Zagolovok? &headingText=`Почему клиенты выбирают нас?`]]' => '<div class="container-fluid mt-4">
    <div class="row">
        <div class="col">
            <h3 style="text-align: center;">
                Почему клиенты выбирают нас?
            </h3>
        </div>
    </div>
</div>',
    '[[$OurBenefits]]' => '<div class="container-fluid">
    <div class="row mt-4 mb-4">
        
    </div>
</div>
<div class="container-fluid mt-4">
    <div class="row">
        <div class="col">
            <h3 style="text-align: center;">
                Почему клиенты выбирают нас?
            </h3>
        </div>
    </div>
</div>
<div class="container benefits">
    <div class="row mt-4 mb-4">
        <div class="col-12 d-block d-md-none">
            <h4 class="mt-3 text-center">Фокусируемся на потребностях заказчика</h4>
        </div>
        <div class="col-md-6  pt-1 pb-1">
            <img src="/assets/img/benefits/focus-on-requirements.jpg">
        </div>
        <div class="col-md-6">
            <h4 class="mt-3 d-none d-md-block">Фокусируемся на потребностях заказчика</h4>
            <p>Мы понимаем, что сайт является не столько целью, сколько инструментом достижения бизнес-задач заказчика.
            Именно поэтому во всей своей работе мы ориентируемся на потребности клиента и специфику его бизнеса.</p>
        </div>
    </div>
    <div class="container-fluid">
    <div class="row mt-4 mb-4">
        
    </div>
</div>
    <div class="row mt-4 mb-4">
        <div class="col-12 d-block d-md-none">
            <h4 class="mt-3 text-center">Используем системный подход к разработке креативного дизайна</h4>
        </div>
        <div class="col-md-6 order-md-1 order-3">
            <h4 class="mt-3 d-none d-md-block">Используем системный подход к разработке креативного дизайна</h4>
            <p>
                Поскольку "красота дизайна" в глазах разных людей является величиной относительной, мы разработали системный подход к созданию стильных дизайнерских решений, 
                который в точности соответствует бизнес-потребностям заказчиков.
                Мы аргументируем "каждый штрих" нашей работы, что обеспечивает надежный и измеримый процесс разработки дизайна и, в результате, 
                приводит к крайне высокой удовлетворенности заказчиков нашими креативными решениями.
            </p>  
        </div>
        <div class="col-md-6  pt-1 pb-1 order-md-3 order-1">
            <img src="/assets/img/benefits/web-design.png">
        </div>
    </div>
    <div class="container-fluid">
    <div class="row mt-4 mb-4">
        
    </div>
</div>
    <div class="row mt-4 mb-4">
        <div class="col-12 d-block d-md-none">
            <h4 class="mt-3 text-center">Создаем адаптивные сайты</h4>
        </div>
        <div class="col-md-6 pt-1 pb-1">
            <img src="/assets/img/benefits/adaptive-design.png">
        </div>
        <div class="col-md-6">
            <h4 class="mt-3 d-none d-md-block">Создаем адаптивные сайты</h4>
            <p>Дизайн и программный код сайтов и приложений реализовывается таким образом, чтобы безупречно выглядеть на всех устройствах - от небольших смартфонов до широкоформатных мониторов.</p>  
        </div>
    </div>
    <div class="container-fluid">
    <div class="row mt-4 mb-4">
        
    </div>
</div>
    <div class="row mt-4 mb-4">
        <div class="col-12 d-block d-md-none">
            <h4 class="mt-3 text-center">Строго соблюдаем поставленные сроки</h4>
        </div>
        <div class="col-md-6 order-md-1 order-3">
            <h4 class="mt-3 d-none d-md-block">Строго соблюдаем поставленные сроки</h4>
            <p>
                Мы выполняем поставленные задачи точно в оговоренные сроки. 
                Благодаря мастерству и профессионализму нашей команды, реализовываем проекты, в среднем, в 1.5 раза быстрее рынка.
            </p>  
        </div>
        <div class="col-md-6 pt-1 pb-1 order-md-3 order-1">
            <img src="/assets/img/benefits/timing.png" style="padding: 30px;">
        </div>
    </div>
    <div class="container-fluid">
    <div class="row mt-4 mb-4">
        
    </div>
</div>
</div>',
    '[[$Zagolovok? &headingText=`Оставьте заявку и наши специалисты ответят на все Ваши вопросы!`]]' => '<div class="container-fluid mt-4">
    <div class="row">
        <div class="col">
            <h3 style="text-align: center;">
                Оставьте заявку и наши специалисты ответят на все Ваши вопросы!
            </h3>
        </div>
    </div>
</div>',
    '[[$ButtonCenter? &link=`#form1` &text=`Оставить заявку`]]' => '<div class="row">
    <div class="col text-center mt-3">
        <button type="button" class="btn btn-primary btn-lg" data-toggle="modal" data-target="#form1">Оставить заявку</button>
    </div>
</div>',
    '[[$FOOTER]]' => '<div class="footer-background">
    <footer class="container">
        <div class="row row-with-logo">
            <div class="col-md-3 col-sm-12 text-center mt-4">
                <a href="/">
                    <img class="logo-img" src="/assets/img/logos/logo-main-white.png" alt="Создание и продвижение сайтов" title="Создание и продвижение сайтов в Санкт-Петербурге">
                </a>
            </div>
            <div class="col-md-3 col-sm-12 text-center mt-0 mt-md-4">
                <p>СПб, 16-я линия В.О., д. 75</p>
            </div>
            <div class="col-md-3 col-sm-12 text-center mt-0 mt-md-4">
                <a href="tel:+78124480892" onclick="ym(52772032, \'reachGoal\', \'phoneCallId\');"><p>+7 (812) 448-08-92</p></a>
            </div>
            <div class="col-md-3 col-sm-12 text-center mt-0 mt-md-4">
                <a href="mailto:info@dig-studio.ru"><p>info@dig-studio.ru</p></a>
            </div>
        </div>
        <hr>
        <div class="row">
            <div class="col mt-3 pb-2">
                <p style="text-align: center;">Создание сайтов и их продвижение в Санкт-Петербурге. Разработка мобильных приложений.<br>&copy; «Digital Studio» 2016-2019.</p>
            </div>
        </div>
    </footer>
</div>
',
    '[[$FinalScripts]]' => '<!--<script src="https://cdnjs.cloudflare.com/ajax/libs/1000hz-bootstrap-validator/0.11.9/validator.min.js"></script>-->
<script>
    function showModal() {
        $("#form1").modal(\'show\');
    }
    function showModalIfDesktopOrTablet() {
        var w = $(document).width();
        if (w >= 768) {
            showModal();
        }
    }
    $("#btnUp").on(\'click\', function() {
        jQuery(\'html,body\').animate({scrollTop:0},700);
    });
    function scrollTop() {
        
        
    }
    function validateForm() {
        var isChecked = $(\'#licenceCheck\').prop(\'checked\');
        if (!isChecked) {
            $(\'#licence-check-id\').attr(\'style\',  \'color: red\');
        } else {
            $(\'#licence-check-id\').removeAttr(\'style\');
        }
        var phone = document.getElementById(\'inputPhone\').value;
        var isPhoneOk = (phone.length >= 7);
        if (!isPhoneOk) {
            $(\'#form1 #inputPhone\').attr(\'style\', \'border: 1px solid red;\');
            if (phone.length == 0) {
                $(\'#form1 #errorPhoneIncorrectId\').attr(\'style\', \'display: none;\');
                $(\'#form1 #errorPhoneEmptyId\').attr(\'style\', \'display: inline;\');
            } else {
                $(\'#form1 #errorPhoneEmptyId\').attr(\'style\', \'display: none;\');
                $(\'#form1 #errorPhoneIncorrectId\').attr(\'style\', \'display: inline;\');
            }
        } else {
            $(\'#form1 #errorPhoneIncorrectId\').attr(\'style\', \'display: none;\');
            $(\'#form1 #errorPhoneEmptyId\').attr(\'style\', \'display: none;\');
            $(\'#form1 #inputPhone\').removeAttr(\'style\');
        }
        return isChecked && isPhoneOk;
    }
    function submitForm() {
        var inputEmail = document.getElementById("inputEmail").value;
        var inputPhone = document.getElementById("inputPhone").value;
        var inputName = document.getElementById("inputName").value;
        var inputComment = document.getElementById("inputComment").value;
        var isValid = validateForm();
        if (!isValid) {
            return;
        }
        $.ajax({
            type: \'POST\',
            url: \'https://dig-studio.ru/assets/php/mailer.php/\',
            data: { 
                \'inputEmail\': inputEmail, 
                \'inputPhone\': inputPhone,
                \'inputName\': inputName,
                \'inputComment\': inputComment
            },
            success: function(msg){
                //alert("Server Response:\\n" + msg);
                if (msg.localeCompare("200")==0) {
                    $("#modal-success").modal(\'show\');
                }
            }
        });
        ym(52772032, \'reachGoal\', \'sendFormId\');
        $("#form1").modal(\'hide\');
    }
</script>',
    '[[$CloseHTML]]' => '</body>
</html>',
  ),
  'sourceCache' => 
  array (
    'modChunk' => 
    array (
      'HEAD' => 
      array (
        'fields' => 
        array (
          'id' => 1,
          'source' => 1,
          'property_preprocess' => false,
          'name' => 'HEAD',
          'description' => '',
          'editor_type' => 0,
          'category' => 0,
          'cache_type' => 0,
          'snippet' => '<!DOCTYPE html>
<html>
<head>
    <title>[[++site_name]] - [[*longtitle]]</title>
    <base href="[[!++site_url]]" />
    <link rel="shortcut icon" href="/favicon.ico" type="image/x-icon">
    <meta name="robots" content="all" />
    <meta name="description" content="[[*description]]" />
    <meta name="keywords" content="[[+seoPro.keywords]]" />
    <meta charset="utf-8">
    <meta name="yandex-verification" content="f2b30d0ade77a2f3" />
    <!-- Yandex.Metrika counter -->
    <script type="text/javascript" >
       (function(m,e,t,r,i,k,a){m[i]=m[i]||function(){(m[i].a=m[i].a||[]).push(arguments)};
       m[i].l=1*new Date();k=e.createElement(t),a=e.getElementsByTagName(t)[0],k.async=1,k.src=r,a.parentNode.insertBefore(k,a)})
       (window, document, "script", "https://mc.yandex.ru/metrika/tag.js", "ym");
    
       ym(52772032, "init", {
            clickmap:true,
            trackLinks:true,
            accurateTrackBounce:true,
            webvisor:true
       });
    </script>
    <noscript><div><img src="https://mc.yandex.ru/watch/52772032" style="position:absolute; left:-9999px;" alt="" /></div></noscript>
<!-- /Yandex.Metrika counter -->
<!-- Global site tag (gtag.js) - Google Analytics -->
    <script async src="https://www.googletagmanager.com/gtag/js?id=UA-136491796-1"></script>
    <script>
      window.dataLayer = window.dataLayer || [];
      function gtag(){dataLayer.push(arguments);}
      gtag(\'js\', new Date());
      gtag(\'config\', \'UA-136491796-1\');
    </script>
<!-- /Google Counter -->
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js" integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy" crossorigin="anonymous"></script>
    <script>
        function callModal() {
            alert("Modal Called");
            $(\'#modal-success\').modal(\'show\');
        }
    </script>
    <!--
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    -->
    [[LinkExternals]]
</head>
<body>',
          'locked' => false,
          'properties' => 
          array (
          ),
          'static' => false,
          'static_file' => '',
          'content' => '<!DOCTYPE html>
<html>
<head>
    <title>[[++site_name]] - [[*longtitle]]</title>
    <base href="[[!++site_url]]" />
    <link rel="shortcut icon" href="/favicon.ico" type="image/x-icon">
    <meta name="robots" content="all" />
    <meta name="description" content="[[*description]]" />
    <meta name="keywords" content="[[+seoPro.keywords]]" />
    <meta charset="utf-8">
    <meta name="yandex-verification" content="f2b30d0ade77a2f3" />
    <!-- Yandex.Metrika counter -->
    <script type="text/javascript" >
       (function(m,e,t,r,i,k,a){m[i]=m[i]||function(){(m[i].a=m[i].a||[]).push(arguments)};
       m[i].l=1*new Date();k=e.createElement(t),a=e.getElementsByTagName(t)[0],k.async=1,k.src=r,a.parentNode.insertBefore(k,a)})
       (window, document, "script", "https://mc.yandex.ru/metrika/tag.js", "ym");
    
       ym(52772032, "init", {
            clickmap:true,
            trackLinks:true,
            accurateTrackBounce:true,
            webvisor:true
       });
    </script>
    <noscript><div><img src="https://mc.yandex.ru/watch/52772032" style="position:absolute; left:-9999px;" alt="" /></div></noscript>
<!-- /Yandex.Metrika counter -->
<!-- Global site tag (gtag.js) - Google Analytics -->
    <script async src="https://www.googletagmanager.com/gtag/js?id=UA-136491796-1"></script>
    <script>
      window.dataLayer = window.dataLayer || [];
      function gtag(){dataLayer.push(arguments);}
      gtag(\'js\', new Date());
      gtag(\'config\', \'UA-136491796-1\');
    </script>
<!-- /Google Counter -->
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js" integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy" crossorigin="anonymous"></script>
    <script>
        function callModal() {
            alert("Modal Called");
            $(\'#modal-success\').modal(\'show\');
        }
    </script>
    <!--
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    -->
    [[LinkExternals]]
</head>
<body>',
        ),
        'policies' => 
        array (
        ),
        'source' => 
        array (
          'id' => 1,
          'name' => 'Filesystem',
          'description' => '',
          'class_key' => 'sources.modFileMediaSource',
          'properties' => 
          array (
          ),
          'is_stream' => true,
        ),
      ),
      'ModalForm1' => 
      array (
        'fields' => 
        array (
          'id' => 6,
          'source' => 1,
          'property_preprocess' => false,
          'name' => 'ModalForm1',
          'description' => '',
          'editor_type' => 0,
          'category' => 0,
          'cache_type' => 0,
          'snippet' => '<div class="modal fade" id="form1" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title text-center">Оставить заявку</h4>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form id="actualForm">
                    <div class="form-group">
                        <input class="form-control" type="text" id="inputName" aria-describedby="nameHelp" placeholder="Ваше имя" />
                    </div>
                    <div class="form-group">
                        <input type="tel" class="form-control" id="inputPhone" aria-describedby="phoneHelp" placeholder="+7 (921) 123-45-67" />
                        <div style="color: red; font-size: 0.9em; padding-left: 5px;">
                            <span id="errorPhoneIncorrectId" style="display: none;">* Введен некорректный номер телефона</span>
                            <span id="errorPhoneEmptyId" style="display: none;">* Не введен номер телефона</span>
                        </div>
                    </div>

                    <div class="form-group">
                        <input type="email" class="form-control" id="inputEmail" aria-describedby="emailHelp" placeholder="Email" />
                        <div class="invalid-feedback">
                            Введите корректный Email
                        </div>
                    </div>
                    <div class="form-group">
                        <input class="form-control" type="text" id="inputComment" aria-describedby="commentHelp" placeholder="Комментарий" />
                    </div>
                    <div class="form-check">
                        <input type="checkbox" class="form-check-input" id="licenceCheck" checked required>
                        <label class="form-check-label" for="exampleCheck1" id="licence-check-id">
                            Я согласен на передачу и обработку моих персональных данных в соответствии с
                            "<a href="/assets/legal/PC.pdf" target="_blank" rel="nofollow">Политикой конфиденциальности</a>"
                        </label>
                    </div>
                    <div class="form-group text-center mt-3">
                        <button type="button" class="btn btn-primary btn-md" id="ajaxSubmit" onclick="submitForm();">Отправить</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>',
          'locked' => false,
          'properties' => 
          array (
          ),
          'static' => false,
          'static_file' => '',
          'content' => '<div class="modal fade" id="form1" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title text-center">Оставить заявку</h4>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form id="actualForm">
                    <div class="form-group">
                        <input class="form-control" type="text" id="inputName" aria-describedby="nameHelp" placeholder="Ваше имя" />
                    </div>
                    <div class="form-group">
                        <input type="tel" class="form-control" id="inputPhone" aria-describedby="phoneHelp" placeholder="+7 (921) 123-45-67" />
                        <div style="color: red; font-size: 0.9em; padding-left: 5px;">
                            <span id="errorPhoneIncorrectId" style="display: none;">* Введен некорректный номер телефона</span>
                            <span id="errorPhoneEmptyId" style="display: none;">* Не введен номер телефона</span>
                        </div>
                    </div>

                    <div class="form-group">
                        <input type="email" class="form-control" id="inputEmail" aria-describedby="emailHelp" placeholder="Email" />
                        <div class="invalid-feedback">
                            Введите корректный Email
                        </div>
                    </div>
                    <div class="form-group">
                        <input class="form-control" type="text" id="inputComment" aria-describedby="commentHelp" placeholder="Комментарий" />
                    </div>
                    <div class="form-check">
                        <input type="checkbox" class="form-check-input" id="licenceCheck" checked required>
                        <label class="form-check-label" for="exampleCheck1" id="licence-check-id">
                            Я согласен на передачу и обработку моих персональных данных в соответствии с
                            "<a href="/assets/legal/PC.pdf" target="_blank" rel="nofollow">Политикой конфиденциальности</a>"
                        </label>
                    </div>
                    <div class="form-group text-center mt-3">
                        <button type="button" class="btn btn-primary btn-md" id="ajaxSubmit" onclick="submitForm();">Отправить</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>',
        ),
        'policies' => 
        array (
        ),
        'source' => 
        array (
          'id' => 1,
          'name' => 'Filesystem',
          'description' => '',
          'class_key' => 'sources.modFileMediaSource',
          'properties' => 
          array (
          ),
          'is_stream' => true,
        ),
      ),
      'ModalSuccess' => 
      array (
        'fields' => 
        array (
          'id' => 7,
          'source' => 1,
          'property_preprocess' => false,
          'name' => 'ModalSuccess',
          'description' => '',
          'editor_type' => 0,
          'category' => 0,
          'cache_type' => 0,
          'snippet' => '<div id="modal-success" class="modal fade">
    <div class="modal-dialog modal-confirm modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <div class="icon-box text-center">
                    <i class="material-icons">&#xE876;</i>
                </div>
                <button type="button" class="close" data-dismiss="modal">&times;</button>
            </div>
            <div class="modal-body text-center">
                <h5>Сообщение успешно отправлено!</h5>
                <p class="pt-2 pb-0 mb-0">Наши специалисты свяжутся с Вами в ближайшее время.</p>
                <button type="button" class="btn btn-success mb-0 mt-4" data-dismiss="modal"><span>Ok</span></button>
            </div>
        </div>
    </div>
</div>',
          'locked' => false,
          'properties' => 
          array (
          ),
          'static' => false,
          'static_file' => '',
          'content' => '<div id="modal-success" class="modal fade">
    <div class="modal-dialog modal-confirm modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <div class="icon-box text-center">
                    <i class="material-icons">&#xE876;</i>
                </div>
                <button type="button" class="close" data-dismiss="modal">&times;</button>
            </div>
            <div class="modal-body text-center">
                <h5>Сообщение успешно отправлено!</h5>
                <p class="pt-2 pb-0 mb-0">Наши специалисты свяжутся с Вами в ближайшее время.</p>
                <button type="button" class="btn btn-success mb-0 mt-4" data-dismiss="modal"><span>Ok</span></button>
            </div>
        </div>
    </div>
</div>',
        ),
        'policies' => 
        array (
        ),
        'source' => 
        array (
          'id' => 1,
          'name' => 'Filesystem',
          'description' => '',
          'class_key' => 'sources.modFileMediaSource',
          'properties' => 
          array (
          ),
          'is_stream' => true,
        ),
      ),
      'HEADER' => 
      array (
        'fields' => 
        array (
          'id' => 2,
          'source' => 1,
          'property_preprocess' => false,
          'name' => 'HEADER',
          'description' => '',
          'editor_type' => 0,
          'category' => 0,
          'cache_type' => 0,
          'snippet' => '<header class="header">
    <div class="container">
        <nav class="navbar navbar-expand-lg navbar-light" id="myNavbar">
            <a class="navbar-brand" href="/">
                <img class="img-logo" src="/assets/img/logos/logo-main.png" alt="Разработка и продвижение веб-сайтов" title="Разработка и продвижение сайтов в Санкт-Петербурге">
            </a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav ml-auto">
                    <li class="nav-item [[IsPageActive? &pageTitle=`Главная`]]">
                        <a class="nav-link mr-2" href="https://dig-studio.ru/" title="Главная">Главная</a>
                    </li>
                    <li class="nav-item [[IsPageActive? &pageTitle=`Портфолио`]]">
                        <a class="nav-link mr-2" href="portfolio" title="Портфолио">Портфолио</a>
                    </li>
                    
                    <li class="nav-item dropdown">
                        <!-- <a class="nav-link" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"> -->
                        <a class="nav-link" href="#" id="navbarDropdown">
                          Услуги
                        </a>
                        <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                          <a class="dropdown-item" href="/services/landing">Лендинг</a>
                          <a class="dropdown-item" href="/services/vizitka">Сайт-визитка</a>
                          <a class="dropdown-item" href="/services/web-design">Разработка веб-дизайна</a>
                        </div>
                    </li>
                    <li class="nav-item [[IsPageActive? &pageTitle=`О компании`]]">
                        <a class="nav-link mr-2" href="about" title="О компании">О нас</a>
                    </li>
                    <li class="nav-item [[IsPageActive? &pageTitle=`Контакты`]]">
                        <a class="nav-link mr-2" href="contacts" title="Контакты">Контакты</a>
                    </li>
                </ul>
            </div>
            <div class="phone-button ml-0 ml-md-3 text-center text-sm-right">
                <a href="tel:+78124480892" onclick="ym(52772032, \'reachGoal\', \'phoneCallId\');"><button class="btn btn-primary btn-md" type="button">[[*PhoneNumber]]</button></a>
            </div>
        </nav>
    </div>
</header>',
          'locked' => false,
          'properties' => 
          array (
          ),
          'static' => false,
          'static_file' => '',
          'content' => '<header class="header">
    <div class="container">
        <nav class="navbar navbar-expand-lg navbar-light" id="myNavbar">
            <a class="navbar-brand" href="/">
                <img class="img-logo" src="/assets/img/logos/logo-main.png" alt="Разработка и продвижение веб-сайтов" title="Разработка и продвижение сайтов в Санкт-Петербурге">
            </a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav ml-auto">
                    <li class="nav-item [[IsPageActive? &pageTitle=`Главная`]]">
                        <a class="nav-link mr-2" href="https://dig-studio.ru/" title="Главная">Главная</a>
                    </li>
                    <li class="nav-item [[IsPageActive? &pageTitle=`Портфолио`]]">
                        <a class="nav-link mr-2" href="portfolio" title="Портфолио">Портфолио</a>
                    </li>
                    
                    <li class="nav-item dropdown">
                        <!-- <a class="nav-link" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"> -->
                        <a class="nav-link" href="#" id="navbarDropdown">
                          Услуги
                        </a>
                        <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                          <a class="dropdown-item" href="/services/landing">Лендинг</a>
                          <a class="dropdown-item" href="/services/vizitka">Сайт-визитка</a>
                          <a class="dropdown-item" href="/services/web-design">Разработка веб-дизайна</a>
                        </div>
                    </li>
                    <li class="nav-item [[IsPageActive? &pageTitle=`О компании`]]">
                        <a class="nav-link mr-2" href="about" title="О компании">О нас</a>
                    </li>
                    <li class="nav-item [[IsPageActive? &pageTitle=`Контакты`]]">
                        <a class="nav-link mr-2" href="contacts" title="Контакты">Контакты</a>
                    </li>
                </ul>
            </div>
            <div class="phone-button ml-0 ml-md-3 text-center text-sm-right">
                <a href="tel:+78124480892" onclick="ym(52772032, \'reachGoal\', \'phoneCallId\');"><button class="btn btn-primary btn-md" type="button">[[*PhoneNumber]]</button></a>
            </div>
        </nav>
    </div>
</header>',
        ),
        'policies' => 
        array (
        ),
        'source' => 
        array (
          'id' => 1,
          'name' => 'Filesystem',
          'description' => '',
          'class_key' => 'sources.modFileMediaSource',
          'properties' => 
          array (
          ),
          'is_stream' => true,
        ),
      ),
      'CarouselJumbo' => 
      array (
        'fields' => 
        array (
          'id' => 8,
          'source' => 1,
          'property_preprocess' => false,
          'name' => 'CarouselJumbo',
          'description' => '',
          'editor_type' => 0,
          'category' => 0,
          'cache_type' => 0,
          'snippet' => '<div id="carouselIndicators" class="carousel slide" data-ride="carousel">
  <ol class="carousel-indicators">
    <li data-target="#carouselIndicators" data-slide-to="0" class="active"></li>
    <li data-target="#carouselIndicators" data-slide-to="1"></li>
    <li data-target="#carouselIndicators" data-slide-to="2"></li>
  </ol>
  <div class="carousel-inner">
    <div class="carousel-item active">
        <div class="jumbo-fill-img" style="background-image: url(\'/assets/img/jumbo/carousel-01.png\');"></div>
        <div class="carousel-caption d-none d-md-block">
            <h3>Разработка и продвижение сайтов</h3>
            <p class="pt-2">Мы создаем креативные сайты,<br />которые решают Ваши бизнес-задачи</p>
            <button type="button" class="btn btn-warning btn-lg" data-toggle="modal" data-target="#form1">Заказать</button>
        </div>
        <div class="carousel-caption d-block d-md-none">
            <h4>Разработка и продвижение сайтов</h4>
            <p class="pt-2" style="font-size:0.9em;">Мы создаем креативные сайты,<br />которые решают Ваши бизнес-задачи</p>
            <button type="button" class="btn btn-warning btn-md" data-toggle="modal" data-target="#form1">Заказать</button>
        </div>
    <!-- <img class="d-block w-100 jumbo-img img-fluid" src="/assets/img/jumbo/carousel-min-01.png" alt="First slide"> -->
    </div>
    <div class="carousel-item">
        <div class="jumbo-fill-img" style="background-image: url(\'/assets/img/jumbo/carousel-02.png\');"></div>
        <div class="carousel-caption d-none d-md-block">
            <h3>Интернет-реклама и SEO</h3>
            <p class="pt-2">Эффективное продвижение в Google и Яндекс</p>
            <button type="button" class="btn btn-warning btn-lg" data-toggle="modal" data-target="#form1">Заказать</button>
        </div>
        <div class="carousel-caption d-block d-md-none">
            <h4>Интернет-реклама и SEO</h4>
            <p class="pt-2" style="font-size:0.9">Эффективное продвижение в Google и Яндекс</p>
            <button type="button" class="btn btn-warning btn-md" data-toggle="modal" data-target="#form1">Заказать</button>
        </div>
    </div>
        <!-- <img class="d-block w-100 jumbo-img img-fluid" src="/assets/img/jumbo/carousel-min-02.png" alt="Second slide"> -->
    
    <div class="carousel-item">
        <div class="jumbo-fill-img" style="background-image: url(\'/assets/img/jumbo/carousel-03.png\');"></div>
        <div class="carousel-caption d-none d-md-block">
            <h3>Разработка мобильных приложений</h3>
            <p class="pt-2">Приложения под мобильные устройства <br />на платформах Android и IOS</p>
            <button type="button" class="btn btn-warning btn-lg" data-toggle="modal" data-target="#form1">Заказать</button>
        </div>
        <div class="carousel-caption d-block d-md-none">
            <h4>Разработка мобильных приложений</h4>
            <p class="pt-2" style="font-size:0.9em;">Приложения под мобильные устройства <br />на платформах Android и IOS</p>
            <button type="button" class="btn btn-warning btn-md" data-toggle="modal" data-target="#form1">Заказать</button>
        </div>
        <!-- <img class="d-block w-100 jumbo-img img-fluid" src="/assets/img/jumbo/carousel-min-03.png" alt="Third slide"> -->
    </div>
  </div>
  <a class="carousel-control-prev" href="#carouselIndicators" role="button" data-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="sr-only">Previous</span>
  </a>
  <a class="carousel-control-next" href="#carouselIndicators" role="button" data-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="sr-only">Next</span>
  </a>
</div>',
          'locked' => false,
          'properties' => 
          array (
          ),
          'static' => false,
          'static_file' => '',
          'content' => '<div id="carouselIndicators" class="carousel slide" data-ride="carousel">
  <ol class="carousel-indicators">
    <li data-target="#carouselIndicators" data-slide-to="0" class="active"></li>
    <li data-target="#carouselIndicators" data-slide-to="1"></li>
    <li data-target="#carouselIndicators" data-slide-to="2"></li>
  </ol>
  <div class="carousel-inner">
    <div class="carousel-item active">
        <div class="jumbo-fill-img" style="background-image: url(\'/assets/img/jumbo/carousel-01.png\');"></div>
        <div class="carousel-caption d-none d-md-block">
            <h3>Разработка и продвижение сайтов</h3>
            <p class="pt-2">Мы создаем креативные сайты,<br />которые решают Ваши бизнес-задачи</p>
            <button type="button" class="btn btn-warning btn-lg" data-toggle="modal" data-target="#form1">Заказать</button>
        </div>
        <div class="carousel-caption d-block d-md-none">
            <h4>Разработка и продвижение сайтов</h4>
            <p class="pt-2" style="font-size:0.9em;">Мы создаем креативные сайты,<br />которые решают Ваши бизнес-задачи</p>
            <button type="button" class="btn btn-warning btn-md" data-toggle="modal" data-target="#form1">Заказать</button>
        </div>
    <!-- <img class="d-block w-100 jumbo-img img-fluid" src="/assets/img/jumbo/carousel-min-01.png" alt="First slide"> -->
    </div>
    <div class="carousel-item">
        <div class="jumbo-fill-img" style="background-image: url(\'/assets/img/jumbo/carousel-02.png\');"></div>
        <div class="carousel-caption d-none d-md-block">
            <h3>Интернет-реклама и SEO</h3>
            <p class="pt-2">Эффективное продвижение в Google и Яндекс</p>
            <button type="button" class="btn btn-warning btn-lg" data-toggle="modal" data-target="#form1">Заказать</button>
        </div>
        <div class="carousel-caption d-block d-md-none">
            <h4>Интернет-реклама и SEO</h4>
            <p class="pt-2" style="font-size:0.9">Эффективное продвижение в Google и Яндекс</p>
            <button type="button" class="btn btn-warning btn-md" data-toggle="modal" data-target="#form1">Заказать</button>
        </div>
    </div>
        <!-- <img class="d-block w-100 jumbo-img img-fluid" src="/assets/img/jumbo/carousel-min-02.png" alt="Second slide"> -->
    
    <div class="carousel-item">
        <div class="jumbo-fill-img" style="background-image: url(\'/assets/img/jumbo/carousel-03.png\');"></div>
        <div class="carousel-caption d-none d-md-block">
            <h3>Разработка мобильных приложений</h3>
            <p class="pt-2">Приложения под мобильные устройства <br />на платформах Android и IOS</p>
            <button type="button" class="btn btn-warning btn-lg" data-toggle="modal" data-target="#form1">Заказать</button>
        </div>
        <div class="carousel-caption d-block d-md-none">
            <h4>Разработка мобильных приложений</h4>
            <p class="pt-2" style="font-size:0.9em;">Приложения под мобильные устройства <br />на платформах Android и IOS</p>
            <button type="button" class="btn btn-warning btn-md" data-toggle="modal" data-target="#form1">Заказать</button>
        </div>
        <!-- <img class="d-block w-100 jumbo-img img-fluid" src="/assets/img/jumbo/carousel-min-03.png" alt="Third slide"> -->
    </div>
  </div>
  <a class="carousel-control-prev" href="#carouselIndicators" role="button" data-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="sr-only">Previous</span>
  </a>
  <a class="carousel-control-next" href="#carouselIndicators" role="button" data-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="sr-only">Next</span>
  </a>
</div>',
        ),
        'policies' => 
        array (
        ),
        'source' => 
        array (
          'id' => 1,
          'name' => 'Filesystem',
          'description' => '',
          'class_key' => 'sources.modFileMediaSource',
          'properties' => 
          array (
          ),
          'is_stream' => true,
        ),
      ),
      'SpaceLine' => 
      array (
        'fields' => 
        array (
          'id' => 13,
          'source' => 1,
          'property_preprocess' => false,
          'name' => 'SpaceLine',
          'description' => '',
          'editor_type' => 0,
          'category' => 0,
          'cache_type' => 0,
          'snippet' => '<div class="container-fluid">
    <div class="row mt-4 mb-4">
        
    </div>
</div>',
          'locked' => false,
          'properties' => 
          array (
          ),
          'static' => false,
          'static_file' => '',
          'content' => '<div class="container-fluid">
    <div class="row mt-4 mb-4">
        
    </div>
</div>',
        ),
        'policies' => 
        array (
        ),
        'source' => 
        array (
          'id' => 1,
          'name' => 'Filesystem',
          'description' => '',
          'class_key' => 'sources.modFileMediaSource',
          'properties' => 
          array (
          ),
          'is_stream' => true,
        ),
      ),
      'Zagolovok' => 
      array (
        'fields' => 
        array (
          'id' => 12,
          'source' => 1,
          'property_preprocess' => false,
          'name' => 'Zagolovok',
          'description' => '',
          'editor_type' => 0,
          'category' => 0,
          'cache_type' => 0,
          'snippet' => '<div class="container-fluid mt-4">
    <div class="row">
        <div class="col">
            <h[[+level]] style="text-align: center;">
                [[+headingText]]
            </h[[+level]]>
        </div>
    </div>
</div>',
          'locked' => false,
          'properties' => 
          array (
            'headingText' => 
            array (
              'name' => 'headingText',
              'desc' => '',
              'type' => 'textfield',
              'options' => 
              array (
              ),
              'value' => '',
              'lexicon' => NULL,
              'area' => '',
              'desc_trans' => '',
              'area_trans' => '',
            ),
            'level' => 
            array (
              'name' => 'level',
              'desc' => '',
              'type' => 'numberfield',
              'options' => 
              array (
              ),
              'value' => '3',
              'lexicon' => NULL,
              'area' => '',
              'desc_trans' => '',
              'area_trans' => '',
            ),
          ),
          'static' => false,
          'static_file' => '',
          'content' => '<div class="container-fluid mt-4">
    <div class="row">
        <div class="col">
            <h[[+level]] style="text-align: center;">
                [[+headingText]]
            </h[[+level]]>
        </div>
    </div>
</div>',
        ),
        'policies' => 
        array (
        ),
        'source' => 
        array (
          'id' => 1,
          'name' => 'Filesystem',
          'description' => '',
          'class_key' => 'sources.modFileMediaSource',
          'properties' => 
          array (
          ),
          'is_stream' => true,
        ),
      ),
      'WebProducts' => 
      array (
        'fields' => 
        array (
          'id' => 10,
          'source' => 1,
          'property_preprocess' => false,
          'name' => 'WebProducts',
          'description' => '',
          'editor_type' => 0,
          'category' => 0,
          'cache_type' => 0,
          'snippet' => '<div class="container mt-4">
    <div class="row web-products">
        <div class="col-lg-4 col-md-6 col-sm-12 d-flex align-items-stretch">
            <!-- <div class="card mb-4 mt-4 card-container" onclick="showModalIfDesktopOrTablet();"> -->
                <div class="card mb-4 mt-4 card-container" onclick="window.location = \'[[~10]]\';">
                    <!-- <img class="card-img-top" src="/assets/img/web-products/landing.png"> -->
                    <div class="img-container">
                        <div class="card-img-top card-image-top" style="background-image: url(\'/assets/img/web-products/landing.png\');">
                            <h2 class="product-heading pl-3">Лендинг</h2>
                        </div>
                    </div>
                    <div class="card-body">
                        <p class="card-text">Основная задача <b>лендинга</b> – эффективная <b>продажа</b> определенного товара или услуги. Каждый товар уникален, поэтому мы создаем лендинги с учетом специфических особенностей Вашей компании.</p>
                    </div>
                    <ul class="list-group list-group-flush">
                        <li class="list-group-item price-heading-list"><span class="price-zone">&asymp; 40 000 ₽</span></span></li>
                    </ul>
                </div>
        </div>
        
        <div class="col-lg-4 col-md-6 col-sm-12 d-flex align-items-stretch">
            <div class="card mb-4 mt-4 card-container" onclick="window.location = \'[[~11]]\';">
                <div class="img-container">
                    <div class="card-img-top card-image-top" style="background-image: url(\'/assets/img/web-products/vizitka.png\');">
                        <h2 class="product-heading pl-3">Сайт-визитка</h2>
                    </div>
                </div>
                <div class="card-body">
                    <p class="card-text">Ключевой целью создания <b>сайта-визитки</b> является краткое представление компании или частного лица в интернете.
                    Основная задача - информирование и <b>формирование имиджа</b>.</p>
                </div>
                <ul class="list-group list-group-flush">
                    <li class="list-group-item price-heading-list"><span class="price-zone">&asymp; 40 000 ₽</span></li>
                </ul>
            </div>
        </div>
        <div class="col-lg-4 col-md-6 col-sm-12 d-flex align-items-stretch">
            <div class="card mb-4 mt-4 card-container" onclick="showModalIfDesktopOrTablet();">
                <div class="img-container">
                    <div class="card-img-top card-image-top" style="background-image: url(\'/assets/img/web-products/corporate.png\');">
                        <h2 class="product-heading pl-3">Корпоративный сайт</h2>
                    </div>
                </div>
                <div class="card-body">
                    <p class="card-text"><b>Корпоративный сайт</b> - это публичный информационный ресурс, формирующий <b>репутацию и имидж</b> Вашего бизнеса.
                    Через создание профессионального сайта <b>повышается узнаваемость и стоимость Вашего бренда</b>.</p>
                </div>
                <ul class="list-group list-group-flush">
                    <li class="list-group-item price-heading"><span class="price-zone">&asymp; 130 000 ₽</span></li>
                </ul>
            </div>
        </div>

        <div class="col-lg-4 col-md-6 col-sm-12 d-flex align-items-stretch">
            <div class="card mb-4 mt-4 card-container" onclick="showModalIfDesktopOrTablet();">
                <!-- <img class="card-img-top" src="/assets/img/web-products/landing.png"> -->
                <div class="img-container">
                    <div class="card-img-top card-image-top" style="background-image: url(\'/assets/img/web-products/blog.png\');">
                        <h2 class="product-heading pl-3">Личный блог</h2>
                    </div>
                </div>
                <div class="card-body">
                    <p class="card-text"><b>Личный блог</b> – это веб-ресурс, материалы на котором выкладываются на регулярной основе.
                    Сайт адаптируется под <b>SEO-оптимизацию</b>, в связи с чем он будет <b>продвигаться в поисквых системах</b> практически без Ваших усилий.</p>
                </div>
                <ul class="list-group list-group-flush">
                    <li class="list-group-item price-heading"><span class="price-zone">&asymp; 25 000 ₽</span></li>
                </ul>
            </div>
        </div>
        
        <div class="col-lg-4 col-md-6 col-sm-12 d-flex align-items-stretch">
            <div class="card mb-4 mt-4 card-container" onclick="showModalIfDesktopOrTablet();">
                <div class="img-container">
                    <div class="card-img-top card-image-top" style="background-image: url(\'/assets/img/web-products/shop.png\');">
                        <h2 class="product-heading pl-3">Интернет-магазин</h2>
                    </div>
                </div>
                <div class="card-body">
                    <p class="card-text"><b>Интернет-магазин</b> - это сложный программный комплекс, включающий в себя <b>интеграцию</b> с бухгалтерией, 
                    подключение интернет-эквайринга, системы мониторинга и многое другое. Создание интернет-магазина позволит Вам <b>увеличить продажи</b> и полностью <b>автоматизировать</b> процесс онлайн-торговли.</p>
                </div>
                <ul class="list-group list-group-flush">
                    <li class="list-group-item price-heading"><span class="price-zone">&asymp; 250 000 ₽</span></li>
                </ul>
            </div>
        </div>
        
        <div class="col-lg-4 col-md-6 col-sm-12 d-flex align-items-stretch">
            <div class="card mb-4 mt-4 card-container" onclick="showModalIfDesktopOrTablet();">
                <div class="img-container">
                    <div class="card-img-top card-image-top" style="background-image: url(\'/assets/img/web-products/portal.png\');">
                        <h2 class="product-heading pl-3">Web-портал</h2>
                    </div>
                </div>
                <div class="card-body">
                    <p class="card-text"><b>Web-портал</b> - это комплексная система, включающая в себя <b>личный кабинет</b>, панели администратора, системы <b>приема и учета платежей</b> и др.
                    Реализовывается взаимодействие с <b>мобильными приложениями</b>, удаленными базами данных и сторонними сервисами.</p>
                </div>
                <ul class="list-group list-group-flush">
                    <li class="list-group-item price-heading"><span class="price-zone">по договоренности</span></li>
                </ul>
            </div>
        </div>
    </div>
</div>
',
          'locked' => false,
          'properties' => 
          array (
          ),
          'static' => false,
          'static_file' => '',
          'content' => '<div class="container mt-4">
    <div class="row web-products">
        <div class="col-lg-4 col-md-6 col-sm-12 d-flex align-items-stretch">
            <!-- <div class="card mb-4 mt-4 card-container" onclick="showModalIfDesktopOrTablet();"> -->
                <div class="card mb-4 mt-4 card-container" onclick="window.location = \'[[~10]]\';">
                    <!-- <img class="card-img-top" src="/assets/img/web-products/landing.png"> -->
                    <div class="img-container">
                        <div class="card-img-top card-image-top" style="background-image: url(\'/assets/img/web-products/landing.png\');">
                            <h2 class="product-heading pl-3">Лендинг</h2>
                        </div>
                    </div>
                    <div class="card-body">
                        <p class="card-text">Основная задача <b>лендинга</b> – эффективная <b>продажа</b> определенного товара или услуги. Каждый товар уникален, поэтому мы создаем лендинги с учетом специфических особенностей Вашей компании.</p>
                    </div>
                    <ul class="list-group list-group-flush">
                        <li class="list-group-item price-heading-list"><span class="price-zone">&asymp; 40 000 ₽</span></span></li>
                    </ul>
                </div>
        </div>
        
        <div class="col-lg-4 col-md-6 col-sm-12 d-flex align-items-stretch">
            <div class="card mb-4 mt-4 card-container" onclick="window.location = \'[[~11]]\';">
                <div class="img-container">
                    <div class="card-img-top card-image-top" style="background-image: url(\'/assets/img/web-products/vizitka.png\');">
                        <h2 class="product-heading pl-3">Сайт-визитка</h2>
                    </div>
                </div>
                <div class="card-body">
                    <p class="card-text">Ключевой целью создания <b>сайта-визитки</b> является краткое представление компании или частного лица в интернете.
                    Основная задача - информирование и <b>формирование имиджа</b>.</p>
                </div>
                <ul class="list-group list-group-flush">
                    <li class="list-group-item price-heading-list"><span class="price-zone">&asymp; 40 000 ₽</span></li>
                </ul>
            </div>
        </div>
        <div class="col-lg-4 col-md-6 col-sm-12 d-flex align-items-stretch">
            <div class="card mb-4 mt-4 card-container" onclick="showModalIfDesktopOrTablet();">
                <div class="img-container">
                    <div class="card-img-top card-image-top" style="background-image: url(\'/assets/img/web-products/corporate.png\');">
                        <h2 class="product-heading pl-3">Корпоративный сайт</h2>
                    </div>
                </div>
                <div class="card-body">
                    <p class="card-text"><b>Корпоративный сайт</b> - это публичный информационный ресурс, формирующий <b>репутацию и имидж</b> Вашего бизнеса.
                    Через создание профессионального сайта <b>повышается узнаваемость и стоимость Вашего бренда</b>.</p>
                </div>
                <ul class="list-group list-group-flush">
                    <li class="list-group-item price-heading"><span class="price-zone">&asymp; 130 000 ₽</span></li>
                </ul>
            </div>
        </div>

        <div class="col-lg-4 col-md-6 col-sm-12 d-flex align-items-stretch">
            <div class="card mb-4 mt-4 card-container" onclick="showModalIfDesktopOrTablet();">
                <!-- <img class="card-img-top" src="/assets/img/web-products/landing.png"> -->
                <div class="img-container">
                    <div class="card-img-top card-image-top" style="background-image: url(\'/assets/img/web-products/blog.png\');">
                        <h2 class="product-heading pl-3">Личный блог</h2>
                    </div>
                </div>
                <div class="card-body">
                    <p class="card-text"><b>Личный блог</b> – это веб-ресурс, материалы на котором выкладываются на регулярной основе.
                    Сайт адаптируется под <b>SEO-оптимизацию</b>, в связи с чем он будет <b>продвигаться в поисквых системах</b> практически без Ваших усилий.</p>
                </div>
                <ul class="list-group list-group-flush">
                    <li class="list-group-item price-heading"><span class="price-zone">&asymp; 25 000 ₽</span></li>
                </ul>
            </div>
        </div>
        
        <div class="col-lg-4 col-md-6 col-sm-12 d-flex align-items-stretch">
            <div class="card mb-4 mt-4 card-container" onclick="showModalIfDesktopOrTablet();">
                <div class="img-container">
                    <div class="card-img-top card-image-top" style="background-image: url(\'/assets/img/web-products/shop.png\');">
                        <h2 class="product-heading pl-3">Интернет-магазин</h2>
                    </div>
                </div>
                <div class="card-body">
                    <p class="card-text"><b>Интернет-магазин</b> - это сложный программный комплекс, включающий в себя <b>интеграцию</b> с бухгалтерией, 
                    подключение интернет-эквайринга, системы мониторинга и многое другое. Создание интернет-магазина позволит Вам <b>увеличить продажи</b> и полностью <b>автоматизировать</b> процесс онлайн-торговли.</p>
                </div>
                <ul class="list-group list-group-flush">
                    <li class="list-group-item price-heading"><span class="price-zone">&asymp; 250 000 ₽</span></li>
                </ul>
            </div>
        </div>
        
        <div class="col-lg-4 col-md-6 col-sm-12 d-flex align-items-stretch">
            <div class="card mb-4 mt-4 card-container" onclick="showModalIfDesktopOrTablet();">
                <div class="img-container">
                    <div class="card-img-top card-image-top" style="background-image: url(\'/assets/img/web-products/portal.png\');">
                        <h2 class="product-heading pl-3">Web-портал</h2>
                    </div>
                </div>
                <div class="card-body">
                    <p class="card-text"><b>Web-портал</b> - это комплексная система, включающая в себя <b>личный кабинет</b>, панели администратора, системы <b>приема и учета платежей</b> и др.
                    Реализовывается взаимодействие с <b>мобильными приложениями</b>, удаленными базами данных и сторонними сервисами.</p>
                </div>
                <ul class="list-group list-group-flush">
                    <li class="list-group-item price-heading"><span class="price-zone">по договоренности</span></li>
                </ul>
            </div>
        </div>
    </div>
</div>
',
        ),
        'policies' => 
        array (
        ),
        'source' => 
        array (
          'id' => 1,
          'name' => 'Filesystem',
          'description' => '',
          'class_key' => 'sources.modFileMediaSource',
          'properties' => 
          array (
          ),
          'is_stream' => true,
        ),
      ),
      'ButtonCenter' => 
      array (
        'fields' => 
        array (
          'id' => 17,
          'source' => 1,
          'property_preprocess' => false,
          'name' => 'ButtonCenter',
          'description' => '',
          'editor_type' => 0,
          'category' => 0,
          'cache_type' => 0,
          'snippet' => '<div class="row">
    <div class="col text-center mt-3">
        <button type="button" class="btn btn-primary btn-lg" data-toggle="modal" data-target="[[+link]]">[[+text]]</button>
    </div>
</div>',
          'locked' => false,
          'properties' => 
          array (
            'link' => 
            array (
              'name' => 'link',
              'desc' => '',
              'type' => 'textfield',
              'options' => 
              array (
              ),
              'value' => '#',
              'lexicon' => NULL,
              'area' => '',
              'desc_trans' => '',
              'area_trans' => '',
            ),
            'text' => 
            array (
              'name' => 'text',
              'desc' => '',
              'type' => 'textfield',
              'options' => 
              array (
              ),
              'value' => '',
              'lexicon' => NULL,
              'area' => '',
              'desc_trans' => '',
              'area_trans' => '',
            ),
          ),
          'static' => false,
          'static_file' => '',
          'content' => '<div class="row">
    <div class="col text-center mt-3">
        <button type="button" class="btn btn-primary btn-lg" data-toggle="modal" data-target="[[+link]]">[[+text]]</button>
    </div>
</div>',
        ),
        'policies' => 
        array (
        ),
        'source' => 
        array (
          'id' => 1,
          'name' => 'Filesystem',
          'description' => '',
          'class_key' => 'sources.modFileMediaSource',
          'properties' => 
          array (
          ),
          'is_stream' => true,
        ),
      ),
      'WorkImage' => 
      array (
        'fields' => 
        array (
          'id' => 18,
          'source' => 1,
          'property_preprocess' => false,
          'name' => 'WorkImage',
          'description' => '',
          'editor_type' => 0,
          'category' => 0,
          'cache_type' => 0,
          'snippet' => '<div class="col-lg-4 col-md-6 col-sm-12">
    <div class="portfolio-tile mt-4">
        <a href="[[+linkToSite]]" target="_blank" rel="nofollow">
            <div class="card" style="width: 100%;" title="[[+name]]">
                <div class="background-img">
                    <div class="portfolio-img" style="background-image: url(\'[[+srcToImage]]\');">
                    </div>
                </div>
                <div class="card-body">
                    <p class="card-text">[[+group]]</p>
                    <h5 class="card-title">[[+name]]</h5>
                </div>
            </div>
        </a>
    </div>
</div>',
          'locked' => false,
          'properties' => 
          array (
            'linkToSite' => 
            array (
              'name' => 'linkToSite',
              'desc' => '',
              'type' => 'textfield',
              'options' => 
              array (
              ),
              'value' => '',
              'lexicon' => NULL,
              'area' => '',
              'desc_trans' => '',
              'area_trans' => '',
            ),
            'name' => 
            array (
              'name' => 'name',
              'desc' => '',
              'type' => 'textfield',
              'options' => 
              array (
              ),
              'value' => '',
              'lexicon' => NULL,
              'area' => '',
              'desc_trans' => '',
              'area_trans' => '',
            ),
            'srcToImage' => 
            array (
              'name' => 'srcToImage',
              'desc' => '',
              'type' => 'textfield',
              'options' => 
              array (
              ),
              'value' => '',
              'lexicon' => NULL,
              'area' => '',
              'desc_trans' => '',
              'area_trans' => '',
            ),
          ),
          'static' => false,
          'static_file' => '',
          'content' => '<div class="col-lg-4 col-md-6 col-sm-12">
    <div class="portfolio-tile mt-4">
        <a href="[[+linkToSite]]" target="_blank" rel="nofollow">
            <div class="card" style="width: 100%;" title="[[+name]]">
                <div class="background-img">
                    <div class="portfolio-img" style="background-image: url(\'[[+srcToImage]]\');">
                    </div>
                </div>
                <div class="card-body">
                    <p class="card-text">[[+group]]</p>
                    <h5 class="card-title">[[+name]]</h5>
                </div>
            </div>
        </a>
    </div>
</div>',
        ),
        'policies' => 
        array (
        ),
        'source' => 
        array (
          'id' => 1,
          'name' => 'Filesystem',
          'description' => '',
          'class_key' => 'sources.modFileMediaSource',
          'properties' => 
          array (
          ),
          'is_stream' => true,
        ),
      ),
      'OurBenefits' => 
      array (
        'fields' => 
        array (
          'id' => 11,
          'source' => 1,
          'property_preprocess' => false,
          'name' => 'OurBenefits',
          'description' => '',
          'editor_type' => 0,
          'category' => 0,
          'cache_type' => 0,
          'snippet' => '[[$SpaceLine]]
[[$Zagolovok? &headingText=`Почему клиенты выбирают нас?`]]
<div class="container benefits">
    <div class="row mt-4 mb-4">
        <div class="col-12 d-block d-md-none">
            <h4 class="mt-3 text-center">Фокусируемся на потребностях заказчика</h4>
        </div>
        <div class="col-md-6  pt-1 pb-1">
            <img src="/assets/img/benefits/focus-on-requirements.jpg">
        </div>
        <div class="col-md-6">
            <h4 class="mt-3 d-none d-md-block">Фокусируемся на потребностях заказчика</h4>
            <p>Мы понимаем, что сайт является не столько целью, сколько инструментом достижения бизнес-задач заказчика.
            Именно поэтому во всей своей работе мы ориентируемся на потребности клиента и специфику его бизнеса.</p>
        </div>
    </div>
    [[$SpaceLine]]
    <div class="row mt-4 mb-4">
        <div class="col-12 d-block d-md-none">
            <h4 class="mt-3 text-center">Используем системный подход к разработке креативного дизайна</h4>
        </div>
        <div class="col-md-6 order-md-1 order-3">
            <h4 class="mt-3 d-none d-md-block">Используем системный подход к разработке креативного дизайна</h4>
            <p>
                Поскольку "красота дизайна" в глазах разных людей является величиной относительной, мы разработали системный подход к созданию стильных дизайнерских решений, 
                который в точности соответствует бизнес-потребностям заказчиков.
                Мы аргументируем "каждый штрих" нашей работы, что обеспечивает надежный и измеримый процесс разработки дизайна и, в результате, 
                приводит к крайне высокой удовлетворенности заказчиков нашими креативными решениями.
            </p>  
        </div>
        <div class="col-md-6  pt-1 pb-1 order-md-3 order-1">
            <img src="/assets/img/benefits/web-design.png">
        </div>
    </div>
    [[$SpaceLine]]
    <div class="row mt-4 mb-4">
        <div class="col-12 d-block d-md-none">
            <h4 class="mt-3 text-center">Создаем адаптивные сайты</h4>
        </div>
        <div class="col-md-6 pt-1 pb-1">
            <img src="/assets/img/benefits/adaptive-design.png">
        </div>
        <div class="col-md-6">
            <h4 class="mt-3 d-none d-md-block">Создаем адаптивные сайты</h4>
            <p>Дизайн и программный код сайтов и приложений реализовывается таким образом, чтобы безупречно выглядеть на всех устройствах - от небольших смартфонов до широкоформатных мониторов.</p>  
        </div>
    </div>
    [[$SpaceLine]]
    <div class="row mt-4 mb-4">
        <div class="col-12 d-block d-md-none">
            <h4 class="mt-3 text-center">Строго соблюдаем поставленные сроки</h4>
        </div>
        <div class="col-md-6 order-md-1 order-3">
            <h4 class="mt-3 d-none d-md-block">Строго соблюдаем поставленные сроки</h4>
            <p>
                Мы выполняем поставленные задачи точно в оговоренные сроки. 
                Благодаря мастерству и профессионализму нашей команды, реализовываем проекты, в среднем, в 1.5 раза быстрее рынка.
            </p>  
        </div>
        <div class="col-md-6 pt-1 pb-1 order-md-3 order-1">
            <img src="/assets/img/benefits/timing.png" style="padding: 30px;">
        </div>
    </div>
    [[$SpaceLine]]
</div>',
          'locked' => false,
          'properties' => 
          array (
          ),
          'static' => false,
          'static_file' => '',
          'content' => '[[$SpaceLine]]
[[$Zagolovok? &headingText=`Почему клиенты выбирают нас?`]]
<div class="container benefits">
    <div class="row mt-4 mb-4">
        <div class="col-12 d-block d-md-none">
            <h4 class="mt-3 text-center">Фокусируемся на потребностях заказчика</h4>
        </div>
        <div class="col-md-6  pt-1 pb-1">
            <img src="/assets/img/benefits/focus-on-requirements.jpg">
        </div>
        <div class="col-md-6">
            <h4 class="mt-3 d-none d-md-block">Фокусируемся на потребностях заказчика</h4>
            <p>Мы понимаем, что сайт является не столько целью, сколько инструментом достижения бизнес-задач заказчика.
            Именно поэтому во всей своей работе мы ориентируемся на потребности клиента и специфику его бизнеса.</p>
        </div>
    </div>
    [[$SpaceLine]]
    <div class="row mt-4 mb-4">
        <div class="col-12 d-block d-md-none">
            <h4 class="mt-3 text-center">Используем системный подход к разработке креативного дизайна</h4>
        </div>
        <div class="col-md-6 order-md-1 order-3">
            <h4 class="mt-3 d-none d-md-block">Используем системный подход к разработке креативного дизайна</h4>
            <p>
                Поскольку "красота дизайна" в глазах разных людей является величиной относительной, мы разработали системный подход к созданию стильных дизайнерских решений, 
                который в точности соответствует бизнес-потребностям заказчиков.
                Мы аргументируем "каждый штрих" нашей работы, что обеспечивает надежный и измеримый процесс разработки дизайна и, в результате, 
                приводит к крайне высокой удовлетворенности заказчиков нашими креативными решениями.
            </p>  
        </div>
        <div class="col-md-6  pt-1 pb-1 order-md-3 order-1">
            <img src="/assets/img/benefits/web-design.png">
        </div>
    </div>
    [[$SpaceLine]]
    <div class="row mt-4 mb-4">
        <div class="col-12 d-block d-md-none">
            <h4 class="mt-3 text-center">Создаем адаптивные сайты</h4>
        </div>
        <div class="col-md-6 pt-1 pb-1">
            <img src="/assets/img/benefits/adaptive-design.png">
        </div>
        <div class="col-md-6">
            <h4 class="mt-3 d-none d-md-block">Создаем адаптивные сайты</h4>
            <p>Дизайн и программный код сайтов и приложений реализовывается таким образом, чтобы безупречно выглядеть на всех устройствах - от небольших смартфонов до широкоформатных мониторов.</p>  
        </div>
    </div>
    [[$SpaceLine]]
    <div class="row mt-4 mb-4">
        <div class="col-12 d-block d-md-none">
            <h4 class="mt-3 text-center">Строго соблюдаем поставленные сроки</h4>
        </div>
        <div class="col-md-6 order-md-1 order-3">
            <h4 class="mt-3 d-none d-md-block">Строго соблюдаем поставленные сроки</h4>
            <p>
                Мы выполняем поставленные задачи точно в оговоренные сроки. 
                Благодаря мастерству и профессионализму нашей команды, реализовываем проекты, в среднем, в 1.5 раза быстрее рынка.
            </p>  
        </div>
        <div class="col-md-6 pt-1 pb-1 order-md-3 order-1">
            <img src="/assets/img/benefits/timing.png" style="padding: 30px;">
        </div>
    </div>
    [[$SpaceLine]]
</div>',
        ),
        'policies' => 
        array (
        ),
        'source' => 
        array (
          'id' => 1,
          'name' => 'Filesystem',
          'description' => '',
          'class_key' => 'sources.modFileMediaSource',
          'properties' => 
          array (
          ),
          'is_stream' => true,
        ),
      ),
      'FOOTER' => 
      array (
        'fields' => 
        array (
          'id' => 3,
          'source' => 1,
          'property_preprocess' => false,
          'name' => 'FOOTER',
          'description' => '',
          'editor_type' => 0,
          'category' => 0,
          'cache_type' => 0,
          'snippet' => '<div class="footer-background">
    <footer class="container">
        <div class="row row-with-logo">
            <div class="col-md-3 col-sm-12 text-center mt-4">
                <a href="/">
                    <img class="logo-img" src="/assets/img/logos/logo-main-white.png" alt="Создание и продвижение сайтов" title="Создание и продвижение сайтов в Санкт-Петербурге">
                </a>
            </div>
            <div class="col-md-3 col-sm-12 text-center mt-0 mt-md-4">
                <p>СПб, 16-я линия В.О., д. 75</p>
            </div>
            <div class="col-md-3 col-sm-12 text-center mt-0 mt-md-4">
                <a href="tel:+78124480892" onclick="ym(52772032, \'reachGoal\', \'phoneCallId\');"><p>+7 (812) 448-08-92</p></a>
            </div>
            <div class="col-md-3 col-sm-12 text-center mt-0 mt-md-4">
                <a href="mailto:info@dig-studio.ru"><p>info@dig-studio.ru</p></a>
            </div>
        </div>
        <hr>
        <div class="row">
            <div class="col mt-3 pb-2">
                <p style="text-align: center;">Создание сайтов и их продвижение в Санкт-Петербурге. Разработка мобильных приложений.<br>&copy; «Digital Studio» 2016-2019.</p>
            </div>
        </div>
    </footer>
</div>
',
          'locked' => false,
          'properties' => 
          array (
          ),
          'static' => false,
          'static_file' => '',
          'content' => '<div class="footer-background">
    <footer class="container">
        <div class="row row-with-logo">
            <div class="col-md-3 col-sm-12 text-center mt-4">
                <a href="/">
                    <img class="logo-img" src="/assets/img/logos/logo-main-white.png" alt="Создание и продвижение сайтов" title="Создание и продвижение сайтов в Санкт-Петербурге">
                </a>
            </div>
            <div class="col-md-3 col-sm-12 text-center mt-0 mt-md-4">
                <p>СПб, 16-я линия В.О., д. 75</p>
            </div>
            <div class="col-md-3 col-sm-12 text-center mt-0 mt-md-4">
                <a href="tel:+78124480892" onclick="ym(52772032, \'reachGoal\', \'phoneCallId\');"><p>+7 (812) 448-08-92</p></a>
            </div>
            <div class="col-md-3 col-sm-12 text-center mt-0 mt-md-4">
                <a href="mailto:info@dig-studio.ru"><p>info@dig-studio.ru</p></a>
            </div>
        </div>
        <hr>
        <div class="row">
            <div class="col mt-3 pb-2">
                <p style="text-align: center;">Создание сайтов и их продвижение в Санкт-Петербурге. Разработка мобильных приложений.<br>&copy; «Digital Studio» 2016-2019.</p>
            </div>
        </div>
    </footer>
</div>
',
        ),
        'policies' => 
        array (
        ),
        'source' => 
        array (
          'id' => 1,
          'name' => 'Filesystem',
          'description' => '',
          'class_key' => 'sources.modFileMediaSource',
          'properties' => 
          array (
          ),
          'is_stream' => true,
        ),
      ),
      'FinalScripts' => 
      array (
        'fields' => 
        array (
          'id' => 4,
          'source' => 1,
          'property_preprocess' => false,
          'name' => 'FinalScripts',
          'description' => '',
          'editor_type' => 0,
          'category' => 0,
          'cache_type' => 0,
          'snippet' => '<!--<script src="https://cdnjs.cloudflare.com/ajax/libs/1000hz-bootstrap-validator/0.11.9/validator.min.js"></script>-->
<script>
    function showModal() {
        $("#form1").modal(\'show\');
    }
    function showModalIfDesktopOrTablet() {
        var w = $(document).width();
        if (w >= 768) {
            showModal();
        }
    }
    $("#btnUp").on(\'click\', function() {
        jQuery(\'html,body\').animate({scrollTop:0},700);
    });
    function scrollTop() {
        
        
    }
    function validateForm() {
        var isChecked = $(\'#licenceCheck\').prop(\'checked\');
        if (!isChecked) {
            $(\'#licence-check-id\').attr(\'style\',  \'color: red\');
        } else {
            $(\'#licence-check-id\').removeAttr(\'style\');
        }
        var phone = document.getElementById(\'inputPhone\').value;
        var isPhoneOk = (phone.length >= 7);
        if (!isPhoneOk) {
            $(\'#form1 #inputPhone\').attr(\'style\', \'border: 1px solid red;\');
            if (phone.length == 0) {
                $(\'#form1 #errorPhoneIncorrectId\').attr(\'style\', \'display: none;\');
                $(\'#form1 #errorPhoneEmptyId\').attr(\'style\', \'display: inline;\');
            } else {
                $(\'#form1 #errorPhoneEmptyId\').attr(\'style\', \'display: none;\');
                $(\'#form1 #errorPhoneIncorrectId\').attr(\'style\', \'display: inline;\');
            }
        } else {
            $(\'#form1 #errorPhoneIncorrectId\').attr(\'style\', \'display: none;\');
            $(\'#form1 #errorPhoneEmptyId\').attr(\'style\', \'display: none;\');
            $(\'#form1 #inputPhone\').removeAttr(\'style\');
        }
        return isChecked && isPhoneOk;
    }
    function submitForm() {
        var inputEmail = document.getElementById("inputEmail").value;
        var inputPhone = document.getElementById("inputPhone").value;
        var inputName = document.getElementById("inputName").value;
        var inputComment = document.getElementById("inputComment").value;
        var isValid = validateForm();
        if (!isValid) {
            return;
        }
        $.ajax({
            type: \'POST\',
            url: \'https://dig-studio.ru/assets/php/mailer.php/\',
            data: { 
                \'inputEmail\': inputEmail, 
                \'inputPhone\': inputPhone,
                \'inputName\': inputName,
                \'inputComment\': inputComment
            },
            success: function(msg){
                //alert("Server Response:\\n" + msg);
                if (msg.localeCompare("200")==0) {
                    $("#modal-success").modal(\'show\');
                }
            }
        });
        ym(52772032, \'reachGoal\', \'sendFormId\');
        $("#form1").modal(\'hide\');
    }
</script>',
          'locked' => false,
          'properties' => 
          array (
          ),
          'static' => false,
          'static_file' => '',
          'content' => '<!--<script src="https://cdnjs.cloudflare.com/ajax/libs/1000hz-bootstrap-validator/0.11.9/validator.min.js"></script>-->
<script>
    function showModal() {
        $("#form1").modal(\'show\');
    }
    function showModalIfDesktopOrTablet() {
        var w = $(document).width();
        if (w >= 768) {
            showModal();
        }
    }
    $("#btnUp").on(\'click\', function() {
        jQuery(\'html,body\').animate({scrollTop:0},700);
    });
    function scrollTop() {
        
        
    }
    function validateForm() {
        var isChecked = $(\'#licenceCheck\').prop(\'checked\');
        if (!isChecked) {
            $(\'#licence-check-id\').attr(\'style\',  \'color: red\');
        } else {
            $(\'#licence-check-id\').removeAttr(\'style\');
        }
        var phone = document.getElementById(\'inputPhone\').value;
        var isPhoneOk = (phone.length >= 7);
        if (!isPhoneOk) {
            $(\'#form1 #inputPhone\').attr(\'style\', \'border: 1px solid red;\');
            if (phone.length == 0) {
                $(\'#form1 #errorPhoneIncorrectId\').attr(\'style\', \'display: none;\');
                $(\'#form1 #errorPhoneEmptyId\').attr(\'style\', \'display: inline;\');
            } else {
                $(\'#form1 #errorPhoneEmptyId\').attr(\'style\', \'display: none;\');
                $(\'#form1 #errorPhoneIncorrectId\').attr(\'style\', \'display: inline;\');
            }
        } else {
            $(\'#form1 #errorPhoneIncorrectId\').attr(\'style\', \'display: none;\');
            $(\'#form1 #errorPhoneEmptyId\').attr(\'style\', \'display: none;\');
            $(\'#form1 #inputPhone\').removeAttr(\'style\');
        }
        return isChecked && isPhoneOk;
    }
    function submitForm() {
        var inputEmail = document.getElementById("inputEmail").value;
        var inputPhone = document.getElementById("inputPhone").value;
        var inputName = document.getElementById("inputName").value;
        var inputComment = document.getElementById("inputComment").value;
        var isValid = validateForm();
        if (!isValid) {
            return;
        }
        $.ajax({
            type: \'POST\',
            url: \'https://dig-studio.ru/assets/php/mailer.php/\',
            data: { 
                \'inputEmail\': inputEmail, 
                \'inputPhone\': inputPhone,
                \'inputName\': inputName,
                \'inputComment\': inputComment
            },
            success: function(msg){
                //alert("Server Response:\\n" + msg);
                if (msg.localeCompare("200")==0) {
                    $("#modal-success").modal(\'show\');
                }
            }
        });
        ym(52772032, \'reachGoal\', \'sendFormId\');
        $("#form1").modal(\'hide\');
    }
</script>',
        ),
        'policies' => 
        array (
        ),
        'source' => 
        array (
          'id' => 1,
          'name' => 'Filesystem',
          'description' => '',
          'class_key' => 'sources.modFileMediaSource',
          'properties' => 
          array (
          ),
          'is_stream' => true,
        ),
      ),
      'CloseHTML' => 
      array (
        'fields' => 
        array (
          'id' => 22,
          'source' => 1,
          'property_preprocess' => false,
          'name' => 'CloseHTML',
          'description' => '',
          'editor_type' => 0,
          'category' => 0,
          'cache_type' => 0,
          'snippet' => '</body>
</html>',
          'locked' => false,
          'properties' => 
          array (
          ),
          'static' => false,
          'static_file' => '',
          'content' => '</body>
</html>',
        ),
        'policies' => 
        array (
        ),
        'source' => 
        array (
          'id' => 1,
          'name' => 'Filesystem',
          'description' => '',
          'class_key' => 'sources.modFileMediaSource',
          'properties' => 
          array (
          ),
          'is_stream' => true,
        ),
      ),
    ),
    'modSnippet' => 
    array (
      'LinkExternals' => 
      array (
        'fields' => 
        array (
          'id' => 4,
          'source' => 1,
          'property_preprocess' => false,
          'name' => 'LinkExternals',
          'description' => 'Подключает пользовательские стили',
          'editor_type' => 0,
          'category' => 0,
          'cache_type' => 0,
          'snippet' => '$modx->regClientCSS(MODX_ASSETS_URL."css/style.css");
$modx->regClientCSS(\'https://fonts.googleapis.com/icon?family=Material+Icons\');',
          'locked' => false,
          'properties' => 
          array (
          ),
          'moduleguid' => '',
          'static' => false,
          'static_file' => '',
          'content' => '$modx->regClientCSS(MODX_ASSETS_URL."css/style.css");
$modx->regClientCSS(\'https://fonts.googleapis.com/icon?family=Material+Icons\');',
        ),
        'policies' => 
        array (
        ),
        'source' => 
        array (
          'id' => 1,
          'name' => 'Filesystem',
          'description' => '',
          'class_key' => 'sources.modFileMediaSource',
          'properties' => 
          array (
          ),
          'is_stream' => true,
        ),
      ),
      'IsPageActive' => 
      array (
        'fields' => 
        array (
          'id' => 12,
          'source' => 1,
          'property_preprocess' => false,
          'name' => 'IsPageActive',
          'description' => '',
          'editor_type' => 0,
          'category' => 0,
          'cache_type' => 0,
          'snippet' => '$title = $modx->resource->get(\'menutitle\'); //получаем ID текущей страницы
if (strcmp($title, $pageTitle) == 0) {
    return "active";
} else {
    return "";
}',
          'locked' => false,
          'properties' => 
          array (
            'pageTitle' => 
            array (
              'name' => 'pageTitle',
              'desc' => '',
              'type' => 'textfield',
              'options' => 
              array (
              ),
              'value' => '',
              'lexicon' => NULL,
              'area' => '',
              'desc_trans' => '',
              'area_trans' => '',
            ),
          ),
          'moduleguid' => '',
          'static' => false,
          'static_file' => '',
          'content' => '$title = $modx->resource->get(\'menutitle\'); //получаем ID текущей страницы
if (strcmp($title, $pageTitle) == 0) {
    return "active";
} else {
    return "";
}',
        ),
        'policies' => 
        array (
        ),
        'source' => 
        array (
          'id' => 1,
          'name' => 'Filesystem',
          'description' => '',
          'class_key' => 'sources.modFileMediaSource',
          'properties' => 
          array (
          ),
          'is_stream' => true,
        ),
      ),
    ),
    'modTemplateVar' => 
    array (
      'PhoneNumber' => 
      array (
        'fields' => 
        array (
          'id' => 1,
          'source' => 1,
          'property_preprocess' => false,
          'type' => 'text',
          'name' => 'PhoneNumber',
          'caption' => 'Номер основного телефона',
          'description' => 'Номер основного телефона',
          'editor_type' => 0,
          'category' => 0,
          'locked' => false,
          'elements' => '',
          'rank' => 0,
          'display' => 'default',
          'default_text' => '+7 (812) 448-08-92',
          'properties' => 
          array (
          ),
          'input_properties' => 
          array (
            'allowBlank' => 'true',
            'minLength' => '',
            'maxLength' => '',
            'regex' => '',
            'regexText' => '',
          ),
          'output_properties' => 
          array (
          ),
          'static' => false,
          'static_file' => '',
          'content' => '+7 (812) 448-08-92',
        ),
        'policies' => 
        array (
        ),
        'source' => 
        array (
          'id' => 1,
          'name' => 'Filesystem',
          'description' => '',
          'class_key' => 'sources.modFileMediaSource',
          'properties' => 
          array (
          ),
          'is_stream' => true,
        ),
      ),
    ),
  ),
);