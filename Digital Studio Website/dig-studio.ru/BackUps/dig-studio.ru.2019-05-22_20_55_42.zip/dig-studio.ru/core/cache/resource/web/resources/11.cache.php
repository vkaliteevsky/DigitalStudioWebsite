<?php  return array (
  'resourceClass' => 'modDocument',
  'resource' => 
  array (
    'id' => 11,
    'type' => 'document',
    'contentType' => 'text/html',
    'pagetitle' => 'Vizitka',
    'longtitle' => 'Создание Сайтов-Визиток в Санкт-Петербурге',
    'description' => 'Разработка сайтов-визиток для Вашего бизнеса. Настройка Интернет-рекламы и аналитики. Формирование имиджа и репутации компании через креативный Web-дизайн.',
    'alias' => 'services/vizitka',
    'alias_visible' => 1,
    'link_attributes' => '',
    'published' => 1,
    'pub_date' => 0,
    'unpub_date' => 0,
    'parent' => 0,
    'isfolder' => 0,
    'introtext' => '',
    'content' => '',
    'richtext' => 1,
    'template' => 9,
    'menuindex' => 4,
    'searchable' => 1,
    'cacheable' => 1,
    'createdby' => 1,
    'createdon' => 1553007528,
    'editedby' => 1,
    'editedon' => 1553080088,
    'deleted' => 0,
    'deletedon' => 0,
    'deletedby' => 0,
    'publishedon' => 1553080020,
    'publishedby' => 1,
    'menutitle' => 'Сайт-визитка',
    'donthit' => 0,
    'privateweb' => 0,
    'privatemgr' => 0,
    'content_dispo' => 0,
    'hidemenu' => 1,
    'class_key' => 'modDocument',
    'context_key' => 'web',
    'content_type' => 1,
    'uri' => 'services/vizitka',
    'uri_override' => 0,
    'hide_children_in_tree' => 0,
    'show_in_tree' => 1,
    'properties' => NULL,
    '_content' => '<!DOCTYPE html>
<html>
<head>
    <title>Digital Studio - Создание Сайтов-Визиток в Санкт-Петербурге</title>
    <base href="[[!++site_url]]" />
    <link rel="shortcut icon" href="/favicon.ico" type="image/x-icon">
    <meta name="robots" content="all" />
    <meta name="description" content="Разработка сайтов-визиток для Вашего бизнеса. Настройка Интернет-рекламы и аналитики. Формирование имиджа и репутации компании через креативный Web-дизайн." />
    <meta name="keywords" content="сайт-визитка,разработка,продвижение" />
    <meta charset="utf-8">
    <meta name="yandex-verification" content="f2b30d0ade77a2f3" />
    <!-- Yandex.Metrika counter -->
    <script type="text/javascript" >
       (function(m,e,t,r,i,k,a){m[i]=m[i]||function(){(m[i].a=m[i].a||[]).push(arguments)};
       m[i].l=1*new Date();k=e.createElement(t),a=e.getElementsByTagName(t)[0],k.async=1,k.src=r,a.parentNode.insertBefore(k,a)})
       (window, document, "script", "https://mc.yandex.ru/metrika/tag.js", "ym");
    
       ym(52772032, "init", {
            clickmap:true,
            trackLinks:true,
            accurateTrackBounce:true,
            webvisor:true
       });
    </script>
    <noscript><div><img src="https://mc.yandex.ru/watch/52772032" style="position:absolute; left:-9999px;" alt="" /></div></noscript>
<!-- /Yandex.Metrika counter -->
<!-- Global site tag (gtag.js) - Google Analytics -->
    <script async src="https://www.googletagmanager.com/gtag/js?id=UA-136491796-1"></script>
    <script>
      window.dataLayer = window.dataLayer || [];
      function gtag(){dataLayer.push(arguments);}
      gtag(\'js\', new Date());
      gtag(\'config\', \'UA-136491796-1\');
    </script>
<!-- /Google Counter -->
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js" integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy" crossorigin="anonymous"></script>
    <script>
        function callModal() {
            alert("Modal Called");
            $(\'#modal-success\').modal(\'show\');
        }
    </script>
    <!--
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    -->
    
</head>
<body>
<div class="modal fade" id="form1" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title text-center">Оставить заявку</h4>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form id="actualForm">
                    <div class="form-group">
                        <input class="form-control" type="text" id="inputName" aria-describedby="nameHelp" placeholder="Ваше имя" />
                    </div>
                    <div class="form-group">
                        <input type="tel" class="form-control" id="inputPhone" aria-describedby="phoneHelp" placeholder="+7 (921) 123-45-67" />
                        <div style="color: red; font-size: 0.9em; padding-left: 5px;">
                            <span id="errorPhoneIncorrectId" style="display: none;">* Введен некорректный номер телефона</span>
                            <span id="errorPhoneEmptyId" style="display: none;">* Не введен номер телефона</span>
                        </div>
                    </div>

                    <div class="form-group">
                        <input type="email" class="form-control" id="inputEmail" aria-describedby="emailHelp" placeholder="Email" />
                        <div class="invalid-feedback">
                            Введите корректный Email
                        </div>
                    </div>
                    <div class="form-group">
                        <input class="form-control" type="text" id="inputComment" aria-describedby="commentHelp" placeholder="Комментарий" />
                    </div>
                    <div class="form-check">
                        <input type="checkbox" class="form-check-input" id="licenceCheck" checked required>
                        <label class="form-check-label" for="exampleCheck1" id="licence-check-id">
                            Я согласен на передачу и обработку моих персональных данных в соответствии с
                            "<a href="/assets/legal/PC.pdf" target="_blank" rel="nofollow">Политикой конфиденциальности</a>"
                        </label>
                    </div>
                    <div class="form-group text-center mt-3">
                        <button type="button" class="btn btn-primary btn-md" id="ajaxSubmit" onclick="submitForm();">Отправить</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<div id="modal-success" class="modal fade">
    <div class="modal-dialog modal-confirm modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <div class="icon-box text-center">
                    <i class="material-icons">&#xE876;</i>
                </div>
                <button type="button" class="close" data-dismiss="modal">&times;</button>
            </div>
            <div class="modal-body text-center">
                <h5>Сообщение успешно отправлено!</h5>
                <p class="pt-2 pb-0 mb-0">Наши специалисты свяжутся с Вами в ближайшее время.</p>
                <button type="button" class="btn btn-success mb-0 mt-4" data-dismiss="modal"><span>Ok</span></button>
            </div>
        </div>
    </div>
</div>
<header class="header">
    <div class="container">
        <nav class="navbar navbar-expand-lg navbar-light" id="myNavbar">
            <a class="navbar-brand" href="/">
                <img class="img-logo" src="/assets/img/logos/logo-main.png" alt="Разработка и продвижение веб-сайтов" title="Разработка и продвижение сайтов в Санкт-Петербурге">
            </a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav ml-auto">
                    <li class="nav-item ">
                        <a class="nav-link mr-2" href="https://dig-studio.ru/" title="Главная">Главная</a>
                    </li>
                    <li class="nav-item ">
                        <a class="nav-link mr-2" href="portfolio" title="Портфолио">Портфолио</a>
                    </li>
                    
                    <li class="nav-item dropdown">
                        <!-- <a class="nav-link" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"> -->
                        <a class="nav-link" href="#" id="navbarDropdown">
                          Услуги
                        </a>
                        <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                          <a class="dropdown-item" href="/services/landing">Лендинг</a>
                          <a class="dropdown-item" href="/services/vizitka">Сайт-визитка</a>
                          <a class="dropdown-item" href="/services/web-design">Разработка веб-дизайна</a>
                        </div>
                    </li>
                    <li class="nav-item ">
                        <a class="nav-link mr-2" href="about" title="О компании">О нас</a>
                    </li>
                    <li class="nav-item ">
                        <a class="nav-link mr-2" href="contacts" title="Контакты">Контакты</a>
                    </li>
                </ul>
            </div>
            <div class="phone-button ml-0 ml-md-3 text-center text-sm-right">
                <a href="tel:+78124480892" onclick="ym(52772032, \'reachGoal\', \'phoneCallId\');"><button class="btn btn-primary btn-md" type="button">+7 (812) 448-08-92</button></a>
            </div>
        </nav>
    </div>
</header>
<img class="d-none d-lg-block" src="/assets/img/icons/scroll-up.png" id="btnUp" alt="Вверх" title="Вверх">
<div class="container-fluid">
    <div class="row mb-4">
        <div class="col">
            <div class="my-jumbotron" style="background-image: url(\'/assets/img/services/vizitka/vizitka-jumbo.jpg\');">
                <h1 class="inner-text">Создаем сайты-визитки, работающие на Вашу репутацию</h1>
            </div>            
        </div>
    </div>

</div>
<div class="container-fluid">
    <div class="row mt-4 mb-4">
        
    </div>
</div>
<div class="container">
    <div class="row">
        <div class="col">
            <h2 class="text-center">Какие возможности дает бизнесу разработка сайта-визитки?</h2>
        </div>
    </div>
</div>
<div class="container-fluid">
    <div class="row mt-4 mb-4">
        
    </div>
</div>
<div class="container vizitka-service">
    <div class="row mb-3">
        <div class="col-md-6 col-sm-12 text-center">
            <img class="img-fluid text-center mx-auto" src="/assets/img/services/vizitka/vizitka01.png" alt="Заказать сайт-визитку в Санкт-Петербурге" title="Заказать сайт-визитку">
        </div>
        <div class="col-md-6 col-sm-12">
            <ul>
                <li><b>Презентация компании в Интернете. </b>На сегодняшний день все солидные компании имеют публичные web-сайты.</li>
                <li><b>Формирование имиджа и репутации бизнеса. </b>Качественное стилистическое оформление сайта формирует положительное отношение людей к компании и ее деятельности в целом.</li>
                <li><b>Предоставление информации портребителям. </b>Через Web-сайт компания может осуществлять коммуникацию со своей целевой аудиторией.</li>
            </ul>
        </div>
    </div>
</div>
<div class="container-fluid greyrow pt-1">
    <div class="container-fluid mt-4">
    <div class="row">
        <div class="col">
            <h2 style="text-align: center;">
                Примеры наших работ
            </h2>
        </div>
    </div>
</div>
    <div class="container">
        <div class="row">
            <div class="col-lg-4 col-md-6 col-sm-12">
        <div class="portfolio-tile mt-4">
            <a href="http://spb.b-frant.ru/" target="_blank" rel="nofollow">
                <div class="card" style="width: 100%;" title="Франт">
                    <div class="background-img">
                        <div class="portfolio-img" style="background-image: url(\'/assets/img/portfolio/frant.jpg\');">
                        </div>
                    </div>
                    <div class="card-body">
                        <p class="card-text">Салоны красоты, барбершопы</p>
                        <h5 class="card-title">Франт</h5>
                    </div>
                </div>
            </a>
        </div>
    </div>
            <div class="col-lg-4 col-md-6 col-sm-12">
        <div class="portfolio-tile mt-4">
            <a href="https://www.mixplatformit.com/" target="_blank" rel="nofollow">
                <div class="card" style="width: 100%;" title="MixPlatform">
                    <div class="background-img">
                        <div class="portfolio-img" style="background-image: url(\'/assets/img/portfolio/mixplatformit.jpg\');">
                        </div>
                    </div>
                    <div class="card-body">
                        <p class="card-text">B2B-компании</p>
                        <h5 class="card-title">MixPlatform</h5>
                    </div>
                </div>
            </a>
        </div>
    </div>
            <div class="col-lg-4 col-md-6 col-sm-12">
        <div class="portfolio-tile mt-4">
            <a href="https://www.hotel-aquamarin.ru/" target="_blank" rel="nofollow">
                <div class="card" style="width: 100%;" title="Отель Аквамарин">
                    <div class="background-img">
                        <div class="portfolio-img" style="background-image: url(\'/assets/img/portfolio/aquamarin.jpg\');">
                        </div>
                    </div>
                    <div class="card-body">
                        <p class="card-text">Гостиницы</p>
                        <h5 class="card-title">Отель Аквамарин</h5>
                    </div>
                </div>
            </a>
        </div>
    </div>
            <div class="col-lg-4 col-md-6 col-sm-12">
        <div class="portfolio-tile mt-4">
            <a href="https://eperty.info/" target="_blank" rel="nofollow">
                <div class="card" style="width: 100%;" title="Eperty">
                    <div class="background-img">
                        <div class="portfolio-img" style="background-image: url(\'/assets/img/portfolio/eperty.jpg\');">
                        </div>
                    </div>
                    <div class="card-body">
                        <p class="card-text">Магазины</p>
                        <h5 class="card-title">Eperty</h5>
                    </div>
                </div>
            </a>
        </div>
    </div>
            <div class="col-lg-4 col-md-6 col-sm-12">
        <div class="portfolio-tile mt-4">
            <a href="http://www.mia-rest.ru/" target="_blank" rel="nofollow">
                <div class="card" style="width: 100%;" title="Mia Familia">
                    <div class="background-img">
                        <div class="portfolio-img" style="background-image: url(\'/assets/img/portfolio/mia-rest.jpg\');">
                        </div>
                    </div>
                    <div class="card-body">
                        <p class="card-text">Рестораны, кафе</p>
                        <h5 class="card-title">Mia Familia</h5>
                    </div>
                </div>
            </a>
        </div>
    </div>
            <div class="col-lg-4 col-md-6 col-sm-12">
        <div class="portfolio-tile mt-4">
            <a href="https://www.bahroma1.ru/" target="_blank" rel="nofollow">
                <div class="card" style="width: 100%;" title="Ресторан Bahroma">
                    <div class="background-img">
                        <div class="portfolio-img" style="background-image: url(\'/assets/img/portfolio/bahroma.jpg\');">
                        </div>
                    </div>
                    <div class="card-body">
                        <p class="card-text">Рестораны, кафе</p>
                        <h5 class="card-title">Ресторан Bahroma</h5>
                    </div>
                </div>
            </a>
        </div>
    </div>
        </div>
    </div>
    <div class="row text-center mb-4">
        <div class="col mt-3">
            <a href="portfolio"><button type="button" class="btn btn-primary btn-lg">Смотреть все работы</button></a>
        </div>
        <div class="container-fluid">
    <div class="row mt-4 mb-4">
        
    </div>
</div>
    </div>
</div>
<div class="container-fluid mt-4">
    <div class="row">
        <div class="col">
            <h2 style="text-align: center;">
                Какие работы проводятся при создании сайта-визитки?
            </h2>
        </div>
    </div>
</div>
<div class="container-fluid">
    <div class="row mt-4 mb-4">
        
    </div>
</div>
<div class="container">
    <div class="row">
    <div class="col price-section mb-2">
        <article>
            <ul>
              <li class="bg-purple">
                <button>Пакет "Базовый"</button>
              </li>
              <li class="bg-blue active">
                <button>Пакет "Стандарт"</button>
              </li>
              <li class="bg-blue">
                <button>Пакет "Полный"</button>
              </li>
            </ul> 
        </article>
        
        <table>
          <thead>
            <tr>
              <th class="hide"></th>
              <th class="bg-purple">Пакет "Базовый"</th>
              <th class="bg-blue">Пакет "Стандарт"</th>
              <th class="bg-blue default">Пакет "Полный"</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td>Стоимость</td>
              <td><span class="txt-l">&asymp; 15 000 ₽</span></td>
              <td class="default"><span class="txt-l">&asymp; 40 000 ₽</span></td>
              <td><span class="txt-l">&asymp; 70 000 ₽</span></td>
            </tr>
            <tr>
                <td>Адаптивный дизайн</td>
                <td><span class="tick">&#10004;</span></td>
                <td class="default"><span class="tick">&#10004;</span></td>
                <td><span class="tick">&#10004;</span></td>
            </tr>
            <tr>
              <td>HTML-верстка и программирование</td>
              <td><span class="tick">&#10004;</span></td>
              <td class="default"><span class="tick">&#10004;</span></td>
              <td><span class="tick">&#10004;</span></td>
            </tr>
            <tr>
              <td>Анимационные эффекты</td>
              <td><span class="tick">&#10004;</span></td>
              <td class="default"><span class="tick">&#10004;</span></td>
              <td><span class="tick">&#10004;</span></td>
            </tr>
            <tr>
              <td>Визуальный редактор текста и фото (CMS)</td>
              <td><span class="tick">&#10004;</span></td>
              <td class="default"><span class="tick">&#10004;</span></td>
              <td><span class="tick">&#10004;</span></td>
            </tr>
            <tr>
              <td>SSL-сертификат</td>
              <td><span class="tick">&#10004;</span></td>
              <td class="default"><span class="tick">&#10004;</span></td>
              <td><span class="tick">&#10004;</span></td>
            </tr>
            <tr>
              <td>Подключение Яндекс Метрики и Google Analytics</td>
              <td><span class="tick">&#10004;</span></td>
              <td class="default"><span class="tick">&#10004;</span></td>
              <td><span class="tick">&#10004;</span></td>
            </tr>
            <tr>
              <td>Разработка нескольких прототипов дизайна</td>
              <td><span class="neg">-</span></td>
              <td class="default"><span class="tick">&#10004;</span></td>
              <td><span class="tick">&#10004;</span></td>
            </tr>
            <tr>
              <td>Уникальный дизайн</td>
              <td><span class="neg">Шаблонный</span></td>
              <td class="default"><span class="tick">&#10004;</span></td>
              <td><span class="tick">&#10004;</span></td>
            </tr>
            <tr>
              <td>Написание уникальных текстов</td>
              <td><span class="neg">-</span></td>
              <td class="default"><span class="tick">&#10004;</span></td>
              <td><span class="tick">&#10004;</span></td>
            </tr>
            <tr>
              <td>SEO-оптимизация</td>
              <td><span class="neg">-</span></td>
              <td class="default"><span class="tick">&#10004;</span></td>
              <td><span class="tick">&#10004;</span></td>
            </tr>
            <tr>
              <td>Анализ конкурентов и лидеров рынка</td>
              <td><span class="neg">-</span></td>
              <td class="default"><span class="neg">-</span></td>
              <td><span class="tick">&#10004;</span></td>
            </tr>
            <tr>
              <td>Настройка рекламы Яндекс и Google</td>
              <td><span class="neg">-</span></td>
              <td class="default"><span class="neg">-</span></td>
              <td><span class="tick">&#10004;</span></td>
            </tr>   
            <tr>
              <td>Отладка рекламы в течение 3 месяцев</td>
              <td><span class="neg">-</span></td>
              <td class="default"><span class="neg">-</span></td>
              <td><span class="tick">&#10004;</span></td>
            </tr>
            <tr>
              <td>Интеграция с почтой и CRM</td>
              <td><span class="neg">-</span></td>
              <td class="default"><span class="neg">-</span></td>
              <td><span class="tick">&#10004;</span></td>
            </tr>
            <tr>
              <td>SMS-информирование</td>
              <td><span class="neg">-</span></td>
              <td class="default"><span class="neg">-</span></td>
              <td><span class="tick">&#10004;</span></td>
            </tr>
          </tbody>
        </table>
</div>
    </div>
    </div>
</div>
<script>
    $( ".price-section ul" ).on( "click", "li", function() {
  var pos = $(this).index()+2;
  $(".price-section tr").find(\'td:not(:eq(0))\').hide();
  $(\'.price-section td:nth-child(\'+pos+\')\').css(\'display\',\'table-cell\');
  $(".price-section tr").find(\'th:not(:eq(0))\').hide();
  $(\'.price-section li\').removeClass(\'active\');
  $(this).addClass(\'active\');
});

// Initialize the media query
  var mediaQuery = window.matchMedia(\'(min-width: 768px)\');
  
  // Add a listen event
  mediaQuery.addListener(doSomething);
  
  // Function to do something with the media query
  function doSomething(mediaQuery) {    
    if (mediaQuery.matches) {
      $(\'.sep\').attr(\'colspan\',5);
    } else {
      $(\'.sep\').attr(\'colspan\',2);
    }
  }
  
  // On load
  doSomething(mediaQuery);
</script>

<div class="container-fluid mt-4">
    <div class="row">
        <div class="col">
            <h2 style="text-align: center;">
                Оставьте заявку и узнайте точную стоимость Вашего проекта!
            </h2>
        </div>
    </div>
</div>
<div class="row">
    <div class="col text-center mt-3">
        <button type="button" class="btn btn-primary btn-lg" data-toggle="modal" data-target="#form1">Оставить заявку</button>
    </div>
</div>
<div class="container-fluid">
    <div class="row mt-4 mb-4">
        
    </div>
</div>

<!--<script src="https://cdnjs.cloudflare.com/ajax/libs/1000hz-bootstrap-validator/0.11.9/validator.min.js"></script>-->
<script>
    function showModal() {
        $("#form1").modal(\'show\');
    }
    function showModalIfDesktopOrTablet() {
        var w = $(document).width();
        if (w >= 768) {
            showModal();
        }
    }
    $("#btnUp").on(\'click\', function() {
        jQuery(\'html,body\').animate({scrollTop:0},700);
    });
    function scrollTop() {
        
        
    }
    function validateForm() {
        var isChecked = $(\'#licenceCheck\').prop(\'checked\');
        if (!isChecked) {
            $(\'#licence-check-id\').attr(\'style\',  \'color: red\');
        } else {
            $(\'#licence-check-id\').removeAttr(\'style\');
        }
        var phone = document.getElementById(\'inputPhone\').value;
        var isPhoneOk = (phone.length >= 7);
        if (!isPhoneOk) {
            $(\'#form1 #inputPhone\').attr(\'style\', \'border: 1px solid red;\');
            if (phone.length == 0) {
                $(\'#form1 #errorPhoneIncorrectId\').attr(\'style\', \'display: none;\');
                $(\'#form1 #errorPhoneEmptyId\').attr(\'style\', \'display: inline;\');
            } else {
                $(\'#form1 #errorPhoneEmptyId\').attr(\'style\', \'display: none;\');
                $(\'#form1 #errorPhoneIncorrectId\').attr(\'style\', \'display: inline;\');
            }
        } else {
            $(\'#form1 #errorPhoneIncorrectId\').attr(\'style\', \'display: none;\');
            $(\'#form1 #errorPhoneEmptyId\').attr(\'style\', \'display: none;\');
            $(\'#form1 #inputPhone\').removeAttr(\'style\');
        }
        return isChecked && isPhoneOk;
    }
    function submitForm() {
        var inputEmail = document.getElementById("inputEmail").value;
        var inputPhone = document.getElementById("inputPhone").value;
        var inputName = document.getElementById("inputName").value;
        var inputComment = document.getElementById("inputComment").value;
        var isValid = validateForm();
        if (!isValid) {
            return;
        }
        $.ajax({
            type: \'POST\',
            url: \'https://dig-studio.ru/assets/php/mailer.php/\',
            data: { 
                \'inputEmail\': inputEmail, 
                \'inputPhone\': inputPhone,
                \'inputName\': inputName,
                \'inputComment\': inputComment
            },
            success: function(msg){
                //alert("Server Response:\\n" + msg);
                if (msg.localeCompare("200")==0) {
                    $("#modal-success").modal(\'show\');
                }
            }
        });
        ym(52772032, \'reachGoal\', \'sendFormId\');
        $("#form1").modal(\'hide\');
    }
</script>
<div class="footer-background">
    <footer class="container">
        <div class="row row-with-logo">
            <div class="col-md-3 col-sm-12 text-center mt-4">
                <a href="/">
                    <img class="logo-img" src="/assets/img/logos/logo-main-white.png" alt="Создание и продвижение сайтов" title="Создание и продвижение сайтов в Санкт-Петербурге">
                </a>
            </div>
            <div class="col-md-3 col-sm-12 text-center mt-0 mt-md-4">
                <p>СПб, 16-я линия В.О., д. 75</p>
            </div>
            <div class="col-md-3 col-sm-12 text-center mt-0 mt-md-4">
                <a href="tel:+78124480892" onclick="ym(52772032, \'reachGoal\', \'phoneCallId\');"><p>+7 (812) 448-08-92</p></a>
            </div>
            <div class="col-md-3 col-sm-12 text-center mt-0 mt-md-4">
                <a href="mailto:info@dig-studio.ru"><p>info@dig-studio.ru</p></a>
            </div>
        </div>
        <hr>
        <div class="row">
            <div class="col mt-3 pb-2">
                <p style="text-align: center;">Создание сайтов и их продвижение в Санкт-Петербурге. Разработка мобильных приложений.<br>&copy; «Digital Studio» 2016-2019.</p>
            </div>
        </div>
    </footer>
</div>

</body>
</html>',
    '_isForward' => false,
    '_sjscripts' => 
    array (
      0 => '<link rel="stylesheet" href="/assets/css/style.css" type="text/css" />',
      1 => '<link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons" type="text/css" />',
    ),
    '_loadedjscripts' => 
    array (
      '/assets/css/style.css' => true,
      'https://fonts.googleapis.com/icon?family=Material+Icons' => true,
    ),
  ),
  'contentType' => 
  array (
    'id' => 1,
    'name' => 'HTML',
    'description' => 'HTML content',
    'mime_type' => 'text/html',
    'file_extensions' => '',
    'headers' => NULL,
    'binary' => 0,
  ),
  'policyCache' => 
  array (
  ),
  'elementCache' => 
  array (
    '[[*longtitle]]' => 'Создание Сайтов-Визиток в Санкт-Петербурге',
    '[[*description]]' => 'Разработка сайтов-визиток для Вашего бизнеса. Настройка Интернет-рекламы и аналитики. Формирование имиджа и репутации компании через креативный Web-дизайн.',
    '[[LinkExternals]]' => '',
    '[[$HEAD]]' => '<!DOCTYPE html>
<html>
<head>
    <title>Digital Studio - Создание Сайтов-Визиток в Санкт-Петербурге</title>
    <base href="[[!++site_url]]" />
    <link rel="shortcut icon" href="/favicon.ico" type="image/x-icon">
    <meta name="robots" content="all" />
    <meta name="description" content="Разработка сайтов-визиток для Вашего бизнеса. Настройка Интернет-рекламы и аналитики. Формирование имиджа и репутации компании через креативный Web-дизайн." />
    <meta name="keywords" content="сайт-визитка,разработка,продвижение" />
    <meta charset="utf-8">
    <meta name="yandex-verification" content="f2b30d0ade77a2f3" />
    <!-- Yandex.Metrika counter -->
    <script type="text/javascript" >
       (function(m,e,t,r,i,k,a){m[i]=m[i]||function(){(m[i].a=m[i].a||[]).push(arguments)};
       m[i].l=1*new Date();k=e.createElement(t),a=e.getElementsByTagName(t)[0],k.async=1,k.src=r,a.parentNode.insertBefore(k,a)})
       (window, document, "script", "https://mc.yandex.ru/metrika/tag.js", "ym");
    
       ym(52772032, "init", {
            clickmap:true,
            trackLinks:true,
            accurateTrackBounce:true,
            webvisor:true
       });
    </script>
    <noscript><div><img src="https://mc.yandex.ru/watch/52772032" style="position:absolute; left:-9999px;" alt="" /></div></noscript>
<!-- /Yandex.Metrika counter -->
<!-- Global site tag (gtag.js) - Google Analytics -->
    <script async src="https://www.googletagmanager.com/gtag/js?id=UA-136491796-1"></script>
    <script>
      window.dataLayer = window.dataLayer || [];
      function gtag(){dataLayer.push(arguments);}
      gtag(\'js\', new Date());
      gtag(\'config\', \'UA-136491796-1\');
    </script>
<!-- /Google Counter -->
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js" integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy" crossorigin="anonymous"></script>
    <script>
        function callModal() {
            alert("Modal Called");
            $(\'#modal-success\').modal(\'show\');
        }
    </script>
    <!--
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    -->
    
</head>
<body>',
    '[[$ModalForm1]]' => '<div class="modal fade" id="form1" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title text-center">Оставить заявку</h4>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form id="actualForm">
                    <div class="form-group">
                        <input class="form-control" type="text" id="inputName" aria-describedby="nameHelp" placeholder="Ваше имя" />
                    </div>
                    <div class="form-group">
                        <input type="tel" class="form-control" id="inputPhone" aria-describedby="phoneHelp" placeholder="+7 (921) 123-45-67" />
                        <div style="color: red; font-size: 0.9em; padding-left: 5px;">
                            <span id="errorPhoneIncorrectId" style="display: none;">* Введен некорректный номер телефона</span>
                            <span id="errorPhoneEmptyId" style="display: none;">* Не введен номер телефона</span>
                        </div>
                    </div>

                    <div class="form-group">
                        <input type="email" class="form-control" id="inputEmail" aria-describedby="emailHelp" placeholder="Email" />
                        <div class="invalid-feedback">
                            Введите корректный Email
                        </div>
                    </div>
                    <div class="form-group">
                        <input class="form-control" type="text" id="inputComment" aria-describedby="commentHelp" placeholder="Комментарий" />
                    </div>
                    <div class="form-check">
                        <input type="checkbox" class="form-check-input" id="licenceCheck" checked required>
                        <label class="form-check-label" for="exampleCheck1" id="licence-check-id">
                            Я согласен на передачу и обработку моих персональных данных в соответствии с
                            "<a href="/assets/legal/PC.pdf" target="_blank" rel="nofollow">Политикой конфиденциальности</a>"
                        </label>
                    </div>
                    <div class="form-group text-center mt-3">
                        <button type="button" class="btn btn-primary btn-md" id="ajaxSubmit" onclick="submitForm();">Отправить</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>',
    '[[$ModalSuccess]]' => '<div id="modal-success" class="modal fade">
    <div class="modal-dialog modal-confirm modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <div class="icon-box text-center">
                    <i class="material-icons">&#xE876;</i>
                </div>
                <button type="button" class="close" data-dismiss="modal">&times;</button>
            </div>
            <div class="modal-body text-center">
                <h5>Сообщение успешно отправлено!</h5>
                <p class="pt-2 pb-0 mb-0">Наши специалисты свяжутся с Вами в ближайшее время.</p>
                <button type="button" class="btn btn-success mb-0 mt-4" data-dismiss="modal"><span>Ok</span></button>
            </div>
        </div>
    </div>
</div>',
    '[[IsPageActive? &pageTitle=`Главная`]]' => '',
    '[[IsPageActive? &pageTitle=`Портфолио`]]' => '',
    '[[IsPageActive? &pageTitle=`О компании`]]' => '',
    '[[IsPageActive? &pageTitle=`Контакты`]]' => '',
    '[[*PhoneNumber]]' => '+7 (812) 448-08-92',
    '[[$HEADER]]' => '<header class="header">
    <div class="container">
        <nav class="navbar navbar-expand-lg navbar-light" id="myNavbar">
            <a class="navbar-brand" href="/">
                <img class="img-logo" src="/assets/img/logos/logo-main.png" alt="Разработка и продвижение веб-сайтов" title="Разработка и продвижение сайтов в Санкт-Петербурге">
            </a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav ml-auto">
                    <li class="nav-item ">
                        <a class="nav-link mr-2" href="https://dig-studio.ru/" title="Главная">Главная</a>
                    </li>
                    <li class="nav-item ">
                        <a class="nav-link mr-2" href="portfolio" title="Портфолио">Портфолио</a>
                    </li>
                    
                    <li class="nav-item dropdown">
                        <!-- <a class="nav-link" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"> -->
                        <a class="nav-link" href="#" id="navbarDropdown">
                          Услуги
                        </a>
                        <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                          <a class="dropdown-item" href="/services/landing">Лендинг</a>
                          <a class="dropdown-item" href="/services/vizitka">Сайт-визитка</a>
                          <a class="dropdown-item" href="/services/web-design">Разработка веб-дизайна</a>
                        </div>
                    </li>
                    <li class="nav-item ">
                        <a class="nav-link mr-2" href="about" title="О компании">О нас</a>
                    </li>
                    <li class="nav-item ">
                        <a class="nav-link mr-2" href="contacts" title="Контакты">Контакты</a>
                    </li>
                </ul>
            </div>
            <div class="phone-button ml-0 ml-md-3 text-center text-sm-right">
                <a href="tel:+78124480892" onclick="ym(52772032, \'reachGoal\', \'phoneCallId\');"><button class="btn btn-primary btn-md" type="button">+7 (812) 448-08-92</button></a>
            </div>
        </nav>
    </div>
</header>',
    '[[$Jumbo? &pathToFile=`/assets/img/services/vizitka/vizitka-jumbo.jpg` &text=`Создаем сайты-визитки, работающие на Вашу репутацию`]]' => '<div class="container-fluid">
    <div class="row mb-4">
        <div class="col">
            <div class="my-jumbotron" style="background-image: url(\'/assets/img/services/vizitka/vizitka-jumbo.jpg\');">
                <h1 class="inner-text">Создаем сайты-визитки, работающие на Вашу репутацию</h1>
            </div>            
        </div>
    </div>

</div>',
    '[[$SpaceLine]]' => '<div class="container-fluid">
    <div class="row mt-4 mb-4">
        
    </div>
</div>',
    '[[$Zagolovok? &headingText=`Примеры наших работ` &level=`2`]]' => '<div class="container-fluid mt-4">
    <div class="row">
        <div class="col">
            <h2 style="text-align: center;">
                Примеры наших работ
            </h2>
        </div>
    </div>
</div>',
    '[[GenPortfolioTile? &link=`http://spb.b-frant.ru/` &src=`/assets/img/portfolio/frant.jpg` &name=`Франт` &group=`Салоны красоты, барбершопы`]]' => '<div class="col-lg-4 col-md-6 col-sm-12">
        <div class="portfolio-tile mt-4">
            <a href="http://spb.b-frant.ru/" target="_blank" rel="nofollow">
                <div class="card" style="width: 100%;" title="Франт">
                    <div class="background-img">
                        <div class="portfolio-img" style="background-image: url(\'/assets/img/portfolio/frant.jpg\');">
                        </div>
                    </div>
                    <div class="card-body">
                        <p class="card-text">Салоны красоты, барбершопы</p>
                        <h5 class="card-title">Франт</h5>
                    </div>
                </div>
            </a>
        </div>
    </div>',
    '[[GenPortfolioTile? &link=`https://www.mixplatformit.com/` &src=`/assets/img/portfolio/mixplatformit.jpg` &name=`MixPlatform` &group=`B2B-компании`]]' => '<div class="col-lg-4 col-md-6 col-sm-12">
        <div class="portfolio-tile mt-4">
            <a href="https://www.mixplatformit.com/" target="_blank" rel="nofollow">
                <div class="card" style="width: 100%;" title="MixPlatform">
                    <div class="background-img">
                        <div class="portfolio-img" style="background-image: url(\'/assets/img/portfolio/mixplatformit.jpg\');">
                        </div>
                    </div>
                    <div class="card-body">
                        <p class="card-text">B2B-компании</p>
                        <h5 class="card-title">MixPlatform</h5>
                    </div>
                </div>
            </a>
        </div>
    </div>',
    '[[GenPortfolioTile? &link=`https://www.hotel-aquamarin.ru/` &src=`/assets/img/portfolio/aquamarin.jpg` &name=`Отель Аквамарин` &group=`Гостиницы`]]' => '<div class="col-lg-4 col-md-6 col-sm-12">
        <div class="portfolio-tile mt-4">
            <a href="https://www.hotel-aquamarin.ru/" target="_blank" rel="nofollow">
                <div class="card" style="width: 100%;" title="Отель Аквамарин">
                    <div class="background-img">
                        <div class="portfolio-img" style="background-image: url(\'/assets/img/portfolio/aquamarin.jpg\');">
                        </div>
                    </div>
                    <div class="card-body">
                        <p class="card-text">Гостиницы</p>
                        <h5 class="card-title">Отель Аквамарин</h5>
                    </div>
                </div>
            </a>
        </div>
    </div>',
    '[[GenPortfolioTile? &link=`https://eperty.info/` &src=`/assets/img/portfolio/eperty.jpg` &name=`Eperty` &group=`Магазины`]]' => '<div class="col-lg-4 col-md-6 col-sm-12">
        <div class="portfolio-tile mt-4">
            <a href="https://eperty.info/" target="_blank" rel="nofollow">
                <div class="card" style="width: 100%;" title="Eperty">
                    <div class="background-img">
                        <div class="portfolio-img" style="background-image: url(\'/assets/img/portfolio/eperty.jpg\');">
                        </div>
                    </div>
                    <div class="card-body">
                        <p class="card-text">Магазины</p>
                        <h5 class="card-title">Eperty</h5>
                    </div>
                </div>
            </a>
        </div>
    </div>',
    '[[GenPortfolioTile? &link=`http://www.mia-rest.ru/` &src=`/assets/img/portfolio/mia-rest.jpg` &name=`Mia Familia` &group=`Рестораны, кафе`]]' => '<div class="col-lg-4 col-md-6 col-sm-12">
        <div class="portfolio-tile mt-4">
            <a href="http://www.mia-rest.ru/" target="_blank" rel="nofollow">
                <div class="card" style="width: 100%;" title="Mia Familia">
                    <div class="background-img">
                        <div class="portfolio-img" style="background-image: url(\'/assets/img/portfolio/mia-rest.jpg\');">
                        </div>
                    </div>
                    <div class="card-body">
                        <p class="card-text">Рестораны, кафе</p>
                        <h5 class="card-title">Mia Familia</h5>
                    </div>
                </div>
            </a>
        </div>
    </div>',
    '[[GenPortfolioTile? &link=`https://www.bahroma1.ru/` &src=`/assets/img/portfolio/bahroma.jpg` &name=`Ресторан Bahroma` &group=`Рестораны, кафе`]]' => '<div class="col-lg-4 col-md-6 col-sm-12">
        <div class="portfolio-tile mt-4">
            <a href="https://www.bahroma1.ru/" target="_blank" rel="nofollow">
                <div class="card" style="width: 100%;" title="Ресторан Bahroma">
                    <div class="background-img">
                        <div class="portfolio-img" style="background-image: url(\'/assets/img/portfolio/bahroma.jpg\');">
                        </div>
                    </div>
                    <div class="card-body">
                        <p class="card-text">Рестораны, кафе</p>
                        <h5 class="card-title">Ресторан Bahroma</h5>
                    </div>
                </div>
            </a>
        </div>
    </div>',
    '[[~3]]' => 'portfolio',
    '[[$Zagolovok? &headingText=`Какие работы проводятся при создании сайта-визитки?` &level=`2`]]' => '<div class="container-fluid mt-4">
    <div class="row">
        <div class="col">
            <h2 style="text-align: center;">
                Какие работы проводятся при создании сайта-визитки?
            </h2>
        </div>
    </div>
</div>',
    '[[$PricingVizitka]]' => '<div class="container">
    <div class="row">
    <div class="col price-section mb-2">
        <article>
            <ul>
              <li class="bg-purple">
                <button>Пакет "Базовый"</button>
              </li>
              <li class="bg-blue active">
                <button>Пакет "Стандарт"</button>
              </li>
              <li class="bg-blue">
                <button>Пакет "Полный"</button>
              </li>
            </ul> 
        </article>
        
        <table>
          <thead>
            <tr>
              <th class="hide"></th>
              <th class="bg-purple">Пакет "Базовый"</th>
              <th class="bg-blue">Пакет "Стандарт"</th>
              <th class="bg-blue default">Пакет "Полный"</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td>Стоимость</td>
              <td><span class="txt-l">&asymp; 15 000 ₽</span></td>
              <td class="default"><span class="txt-l">&asymp; 40 000 ₽</span></td>
              <td><span class="txt-l">&asymp; 70 000 ₽</span></td>
            </tr>
            <tr>
                <td>Адаптивный дизайн</td>
                <td><span class="tick">&#10004;</span></td>
                <td class="default"><span class="tick">&#10004;</span></td>
                <td><span class="tick">&#10004;</span></td>
            </tr>
            <tr>
              <td>HTML-верстка и программирование</td>
              <td><span class="tick">&#10004;</span></td>
              <td class="default"><span class="tick">&#10004;</span></td>
              <td><span class="tick">&#10004;</span></td>
            </tr>
            <tr>
              <td>Анимационные эффекты</td>
              <td><span class="tick">&#10004;</span></td>
              <td class="default"><span class="tick">&#10004;</span></td>
              <td><span class="tick">&#10004;</span></td>
            </tr>
            <tr>
              <td>Визуальный редактор текста и фото (CMS)</td>
              <td><span class="tick">&#10004;</span></td>
              <td class="default"><span class="tick">&#10004;</span></td>
              <td><span class="tick">&#10004;</span></td>
            </tr>
            <tr>
              <td>SSL-сертификат</td>
              <td><span class="tick">&#10004;</span></td>
              <td class="default"><span class="tick">&#10004;</span></td>
              <td><span class="tick">&#10004;</span></td>
            </tr>
            <tr>
              <td>Подключение Яндекс Метрики и Google Analytics</td>
              <td><span class="tick">&#10004;</span></td>
              <td class="default"><span class="tick">&#10004;</span></td>
              <td><span class="tick">&#10004;</span></td>
            </tr>
            <tr>
              <td>Разработка нескольких прототипов дизайна</td>
              <td><span class="neg">-</span></td>
              <td class="default"><span class="tick">&#10004;</span></td>
              <td><span class="tick">&#10004;</span></td>
            </tr>
            <tr>
              <td>Уникальный дизайн</td>
              <td><span class="neg">Шаблонный</span></td>
              <td class="default"><span class="tick">&#10004;</span></td>
              <td><span class="tick">&#10004;</span></td>
            </tr>
            <tr>
              <td>Написание уникальных текстов</td>
              <td><span class="neg">-</span></td>
              <td class="default"><span class="tick">&#10004;</span></td>
              <td><span class="tick">&#10004;</span></td>
            </tr>
            <tr>
              <td>SEO-оптимизация</td>
              <td><span class="neg">-</span></td>
              <td class="default"><span class="tick">&#10004;</span></td>
              <td><span class="tick">&#10004;</span></td>
            </tr>
            <tr>
              <td>Анализ конкурентов и лидеров рынка</td>
              <td><span class="neg">-</span></td>
              <td class="default"><span class="neg">-</span></td>
              <td><span class="tick">&#10004;</span></td>
            </tr>
            <tr>
              <td>Настройка рекламы Яндекс и Google</td>
              <td><span class="neg">-</span></td>
              <td class="default"><span class="neg">-</span></td>
              <td><span class="tick">&#10004;</span></td>
            </tr>   
            <tr>
              <td>Отладка рекламы в течение 3 месяцев</td>
              <td><span class="neg">-</span></td>
              <td class="default"><span class="neg">-</span></td>
              <td><span class="tick">&#10004;</span></td>
            </tr>
            <tr>
              <td>Интеграция с почтой и CRM</td>
              <td><span class="neg">-</span></td>
              <td class="default"><span class="neg">-</span></td>
              <td><span class="tick">&#10004;</span></td>
            </tr>
            <tr>
              <td>SMS-информирование</td>
              <td><span class="neg">-</span></td>
              <td class="default"><span class="neg">-</span></td>
              <td><span class="tick">&#10004;</span></td>
            </tr>
          </tbody>
        </table>
</div>
    </div>
    </div>
</div>
<script>
    $( ".price-section ul" ).on( "click", "li", function() {
  var pos = $(this).index()+2;
  $(".price-section tr").find(\'td:not(:eq(0))\').hide();
  $(\'.price-section td:nth-child(\'+pos+\')\').css(\'display\',\'table-cell\');
  $(".price-section tr").find(\'th:not(:eq(0))\').hide();
  $(\'.price-section li\').removeClass(\'active\');
  $(this).addClass(\'active\');
});

// Initialize the media query
  var mediaQuery = window.matchMedia(\'(min-width: 768px)\');
  
  // Add a listen event
  mediaQuery.addListener(doSomething);
  
  // Function to do something with the media query
  function doSomething(mediaQuery) {    
    if (mediaQuery.matches) {
      $(\'.sep\').attr(\'colspan\',5);
    } else {
      $(\'.sep\').attr(\'colspan\',2);
    }
  }
  
  // On load
  doSomething(mediaQuery);
</script>',
    '[[$Zagolovok? &headingText=`Оставьте заявку и узнайте точную стоимость Вашего проекта!` &level=`2`]]' => '<div class="container-fluid mt-4">
    <div class="row">
        <div class="col">
            <h2 style="text-align: center;">
                Оставьте заявку и узнайте точную стоимость Вашего проекта!
            </h2>
        </div>
    </div>
</div>',
    '[[$ButtonCenter? &text=`Оставить заявку` &link=`#form1`]]' => '<div class="row">
    <div class="col text-center mt-3">
        <button type="button" class="btn btn-primary btn-lg" data-toggle="modal" data-target="#form1">Оставить заявку</button>
    </div>
</div>',
    '[[$FinalScripts]]' => '<!--<script src="https://cdnjs.cloudflare.com/ajax/libs/1000hz-bootstrap-validator/0.11.9/validator.min.js"></script>-->
<script>
    function showModal() {
        $("#form1").modal(\'show\');
    }
    function showModalIfDesktopOrTablet() {
        var w = $(document).width();
        if (w >= 768) {
            showModal();
        }
    }
    $("#btnUp").on(\'click\', function() {
        jQuery(\'html,body\').animate({scrollTop:0},700);
    });
    function scrollTop() {
        
        
    }
    function validateForm() {
        var isChecked = $(\'#licenceCheck\').prop(\'checked\');
        if (!isChecked) {
            $(\'#licence-check-id\').attr(\'style\',  \'color: red\');
        } else {
            $(\'#licence-check-id\').removeAttr(\'style\');
        }
        var phone = document.getElementById(\'inputPhone\').value;
        var isPhoneOk = (phone.length >= 7);
        if (!isPhoneOk) {
            $(\'#form1 #inputPhone\').attr(\'style\', \'border: 1px solid red;\');
            if (phone.length == 0) {
                $(\'#form1 #errorPhoneIncorrectId\').attr(\'style\', \'display: none;\');
                $(\'#form1 #errorPhoneEmptyId\').attr(\'style\', \'display: inline;\');
            } else {
                $(\'#form1 #errorPhoneEmptyId\').attr(\'style\', \'display: none;\');
                $(\'#form1 #errorPhoneIncorrectId\').attr(\'style\', \'display: inline;\');
            }
        } else {
            $(\'#form1 #errorPhoneIncorrectId\').attr(\'style\', \'display: none;\');
            $(\'#form1 #errorPhoneEmptyId\').attr(\'style\', \'display: none;\');
            $(\'#form1 #inputPhone\').removeAttr(\'style\');
        }
        return isChecked && isPhoneOk;
    }
    function submitForm() {
        var inputEmail = document.getElementById("inputEmail").value;
        var inputPhone = document.getElementById("inputPhone").value;
        var inputName = document.getElementById("inputName").value;
        var inputComment = document.getElementById("inputComment").value;
        var isValid = validateForm();
        if (!isValid) {
            return;
        }
        $.ajax({
            type: \'POST\',
            url: \'https://dig-studio.ru/assets/php/mailer.php/\',
            data: { 
                \'inputEmail\': inputEmail, 
                \'inputPhone\': inputPhone,
                \'inputName\': inputName,
                \'inputComment\': inputComment
            },
            success: function(msg){
                //alert("Server Response:\\n" + msg);
                if (msg.localeCompare("200")==0) {
                    $("#modal-success").modal(\'show\');
                }
            }
        });
        ym(52772032, \'reachGoal\', \'sendFormId\');
        $("#form1").modal(\'hide\');
    }
</script>',
    '[[$FOOTER]]' => '<div class="footer-background">
    <footer class="container">
        <div class="row row-with-logo">
            <div class="col-md-3 col-sm-12 text-center mt-4">
                <a href="/">
                    <img class="logo-img" src="/assets/img/logos/logo-main-white.png" alt="Создание и продвижение сайтов" title="Создание и продвижение сайтов в Санкт-Петербурге">
                </a>
            </div>
            <div class="col-md-3 col-sm-12 text-center mt-0 mt-md-4">
                <p>СПб, 16-я линия В.О., д. 75</p>
            </div>
            <div class="col-md-3 col-sm-12 text-center mt-0 mt-md-4">
                <a href="tel:+78124480892" onclick="ym(52772032, \'reachGoal\', \'phoneCallId\');"><p>+7 (812) 448-08-92</p></a>
            </div>
            <div class="col-md-3 col-sm-12 text-center mt-0 mt-md-4">
                <a href="mailto:info@dig-studio.ru"><p>info@dig-studio.ru</p></a>
            </div>
        </div>
        <hr>
        <div class="row">
            <div class="col mt-3 pb-2">
                <p style="text-align: center;">Создание сайтов и их продвижение в Санкт-Петербурге. Разработка мобильных приложений.<br>&copy; «Digital Studio» 2016-2019.</p>
            </div>
        </div>
    </footer>
</div>
',
    '[[$CloseHTML]]' => '</body>
</html>',
  ),
  'sourceCache' => 
  array (
    'modChunk' => 
    array (
      'HEAD' => 
      array (
        'fields' => 
        array (
          'id' => 1,
          'source' => 1,
          'property_preprocess' => false,
          'name' => 'HEAD',
          'description' => '',
          'editor_type' => 0,
          'category' => 0,
          'cache_type' => 0,
          'snippet' => '<!DOCTYPE html>
<html>
<head>
    <title>[[++site_name]] - [[*longtitle]]</title>
    <base href="[[!++site_url]]" />
    <link rel="shortcut icon" href="/favicon.ico" type="image/x-icon">
    <meta name="robots" content="all" />
    <meta name="description" content="[[*description]]" />
    <meta name="keywords" content="[[+seoPro.keywords]]" />
    <meta charset="utf-8">
    <meta name="yandex-verification" content="f2b30d0ade77a2f3" />
    <!-- Yandex.Metrika counter -->
    <script type="text/javascript" >
       (function(m,e,t,r,i,k,a){m[i]=m[i]||function(){(m[i].a=m[i].a||[]).push(arguments)};
       m[i].l=1*new Date();k=e.createElement(t),a=e.getElementsByTagName(t)[0],k.async=1,k.src=r,a.parentNode.insertBefore(k,a)})
       (window, document, "script", "https://mc.yandex.ru/metrika/tag.js", "ym");
    
       ym(52772032, "init", {
            clickmap:true,
            trackLinks:true,
            accurateTrackBounce:true,
            webvisor:true
       });
    </script>
    <noscript><div><img src="https://mc.yandex.ru/watch/52772032" style="position:absolute; left:-9999px;" alt="" /></div></noscript>
<!-- /Yandex.Metrika counter -->
<!-- Global site tag (gtag.js) - Google Analytics -->
    <script async src="https://www.googletagmanager.com/gtag/js?id=UA-136491796-1"></script>
    <script>
      window.dataLayer = window.dataLayer || [];
      function gtag(){dataLayer.push(arguments);}
      gtag(\'js\', new Date());
      gtag(\'config\', \'UA-136491796-1\');
    </script>
<!-- /Google Counter -->
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js" integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy" crossorigin="anonymous"></script>
    <script>
        function callModal() {
            alert("Modal Called");
            $(\'#modal-success\').modal(\'show\');
        }
    </script>
    <!--
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    -->
    [[LinkExternals]]
</head>
<body>',
          'locked' => false,
          'properties' => 
          array (
          ),
          'static' => false,
          'static_file' => '',
          'content' => '<!DOCTYPE html>
<html>
<head>
    <title>[[++site_name]] - [[*longtitle]]</title>
    <base href="[[!++site_url]]" />
    <link rel="shortcut icon" href="/favicon.ico" type="image/x-icon">
    <meta name="robots" content="all" />
    <meta name="description" content="[[*description]]" />
    <meta name="keywords" content="[[+seoPro.keywords]]" />
    <meta charset="utf-8">
    <meta name="yandex-verification" content="f2b30d0ade77a2f3" />
    <!-- Yandex.Metrika counter -->
    <script type="text/javascript" >
       (function(m,e,t,r,i,k,a){m[i]=m[i]||function(){(m[i].a=m[i].a||[]).push(arguments)};
       m[i].l=1*new Date();k=e.createElement(t),a=e.getElementsByTagName(t)[0],k.async=1,k.src=r,a.parentNode.insertBefore(k,a)})
       (window, document, "script", "https://mc.yandex.ru/metrika/tag.js", "ym");
    
       ym(52772032, "init", {
            clickmap:true,
            trackLinks:true,
            accurateTrackBounce:true,
            webvisor:true
       });
    </script>
    <noscript><div><img src="https://mc.yandex.ru/watch/52772032" style="position:absolute; left:-9999px;" alt="" /></div></noscript>
<!-- /Yandex.Metrika counter -->
<!-- Global site tag (gtag.js) - Google Analytics -->
    <script async src="https://www.googletagmanager.com/gtag/js?id=UA-136491796-1"></script>
    <script>
      window.dataLayer = window.dataLayer || [];
      function gtag(){dataLayer.push(arguments);}
      gtag(\'js\', new Date());
      gtag(\'config\', \'UA-136491796-1\');
    </script>
<!-- /Google Counter -->
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js" integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy" crossorigin="anonymous"></script>
    <script>
        function callModal() {
            alert("Modal Called");
            $(\'#modal-success\').modal(\'show\');
        }
    </script>
    <!--
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    -->
    [[LinkExternals]]
</head>
<body>',
        ),
        'policies' => 
        array (
        ),
        'source' => 
        array (
          'id' => 1,
          'name' => 'Filesystem',
          'description' => '',
          'class_key' => 'sources.modFileMediaSource',
          'properties' => 
          array (
          ),
          'is_stream' => true,
        ),
      ),
      'ModalForm1' => 
      array (
        'fields' => 
        array (
          'id' => 6,
          'source' => 1,
          'property_preprocess' => false,
          'name' => 'ModalForm1',
          'description' => '',
          'editor_type' => 0,
          'category' => 0,
          'cache_type' => 0,
          'snippet' => '<div class="modal fade" id="form1" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title text-center">Оставить заявку</h4>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form id="actualForm">
                    <div class="form-group">
                        <input class="form-control" type="text" id="inputName" aria-describedby="nameHelp" placeholder="Ваше имя" />
                    </div>
                    <div class="form-group">
                        <input type="tel" class="form-control" id="inputPhone" aria-describedby="phoneHelp" placeholder="+7 (921) 123-45-67" />
                        <div style="color: red; font-size: 0.9em; padding-left: 5px;">
                            <span id="errorPhoneIncorrectId" style="display: none;">* Введен некорректный номер телефона</span>
                            <span id="errorPhoneEmptyId" style="display: none;">* Не введен номер телефона</span>
                        </div>
                    </div>

                    <div class="form-group">
                        <input type="email" class="form-control" id="inputEmail" aria-describedby="emailHelp" placeholder="Email" />
                        <div class="invalid-feedback">
                            Введите корректный Email
                        </div>
                    </div>
                    <div class="form-group">
                        <input class="form-control" type="text" id="inputComment" aria-describedby="commentHelp" placeholder="Комментарий" />
                    </div>
                    <div class="form-check">
                        <input type="checkbox" class="form-check-input" id="licenceCheck" checked required>
                        <label class="form-check-label" for="exampleCheck1" id="licence-check-id">
                            Я согласен на передачу и обработку моих персональных данных в соответствии с
                            "<a href="/assets/legal/PC.pdf" target="_blank" rel="nofollow">Политикой конфиденциальности</a>"
                        </label>
                    </div>
                    <div class="form-group text-center mt-3">
                        <button type="button" class="btn btn-primary btn-md" id="ajaxSubmit" onclick="submitForm();">Отправить</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>',
          'locked' => false,
          'properties' => 
          array (
          ),
          'static' => false,
          'static_file' => '',
          'content' => '<div class="modal fade" id="form1" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title text-center">Оставить заявку</h4>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form id="actualForm">
                    <div class="form-group">
                        <input class="form-control" type="text" id="inputName" aria-describedby="nameHelp" placeholder="Ваше имя" />
                    </div>
                    <div class="form-group">
                        <input type="tel" class="form-control" id="inputPhone" aria-describedby="phoneHelp" placeholder="+7 (921) 123-45-67" />
                        <div style="color: red; font-size: 0.9em; padding-left: 5px;">
                            <span id="errorPhoneIncorrectId" style="display: none;">* Введен некорректный номер телефона</span>
                            <span id="errorPhoneEmptyId" style="display: none;">* Не введен номер телефона</span>
                        </div>
                    </div>

                    <div class="form-group">
                        <input type="email" class="form-control" id="inputEmail" aria-describedby="emailHelp" placeholder="Email" />
                        <div class="invalid-feedback">
                            Введите корректный Email
                        </div>
                    </div>
                    <div class="form-group">
                        <input class="form-control" type="text" id="inputComment" aria-describedby="commentHelp" placeholder="Комментарий" />
                    </div>
                    <div class="form-check">
                        <input type="checkbox" class="form-check-input" id="licenceCheck" checked required>
                        <label class="form-check-label" for="exampleCheck1" id="licence-check-id">
                            Я согласен на передачу и обработку моих персональных данных в соответствии с
                            "<a href="/assets/legal/PC.pdf" target="_blank" rel="nofollow">Политикой конфиденциальности</a>"
                        </label>
                    </div>
                    <div class="form-group text-center mt-3">
                        <button type="button" class="btn btn-primary btn-md" id="ajaxSubmit" onclick="submitForm();">Отправить</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>',
        ),
        'policies' => 
        array (
        ),
        'source' => 
        array (
          'id' => 1,
          'name' => 'Filesystem',
          'description' => '',
          'class_key' => 'sources.modFileMediaSource',
          'properties' => 
          array (
          ),
          'is_stream' => true,
        ),
      ),
      'ModalSuccess' => 
      array (
        'fields' => 
        array (
          'id' => 7,
          'source' => 1,
          'property_preprocess' => false,
          'name' => 'ModalSuccess',
          'description' => '',
          'editor_type' => 0,
          'category' => 0,
          'cache_type' => 0,
          'snippet' => '<div id="modal-success" class="modal fade">
    <div class="modal-dialog modal-confirm modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <div class="icon-box text-center">
                    <i class="material-icons">&#xE876;</i>
                </div>
                <button type="button" class="close" data-dismiss="modal">&times;</button>
            </div>
            <div class="modal-body text-center">
                <h5>Сообщение успешно отправлено!</h5>
                <p class="pt-2 pb-0 mb-0">Наши специалисты свяжутся с Вами в ближайшее время.</p>
                <button type="button" class="btn btn-success mb-0 mt-4" data-dismiss="modal"><span>Ok</span></button>
            </div>
        </div>
    </div>
</div>',
          'locked' => false,
          'properties' => 
          array (
          ),
          'static' => false,
          'static_file' => '',
          'content' => '<div id="modal-success" class="modal fade">
    <div class="modal-dialog modal-confirm modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <div class="icon-box text-center">
                    <i class="material-icons">&#xE876;</i>
                </div>
                <button type="button" class="close" data-dismiss="modal">&times;</button>
            </div>
            <div class="modal-body text-center">
                <h5>Сообщение успешно отправлено!</h5>
                <p class="pt-2 pb-0 mb-0">Наши специалисты свяжутся с Вами в ближайшее время.</p>
                <button type="button" class="btn btn-success mb-0 mt-4" data-dismiss="modal"><span>Ok</span></button>
            </div>
        </div>
    </div>
</div>',
        ),
        'policies' => 
        array (
        ),
        'source' => 
        array (
          'id' => 1,
          'name' => 'Filesystem',
          'description' => '',
          'class_key' => 'sources.modFileMediaSource',
          'properties' => 
          array (
          ),
          'is_stream' => true,
        ),
      ),
      'HEADER' => 
      array (
        'fields' => 
        array (
          'id' => 2,
          'source' => 1,
          'property_preprocess' => false,
          'name' => 'HEADER',
          'description' => '',
          'editor_type' => 0,
          'category' => 0,
          'cache_type' => 0,
          'snippet' => '<header class="header">
    <div class="container">
        <nav class="navbar navbar-expand-lg navbar-light" id="myNavbar">
            <a class="navbar-brand" href="/">
                <img class="img-logo" src="/assets/img/logos/logo-main.png" alt="Разработка и продвижение веб-сайтов" title="Разработка и продвижение сайтов в Санкт-Петербурге">
            </a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav ml-auto">
                    <li class="nav-item [[IsPageActive? &pageTitle=`Главная`]]">
                        <a class="nav-link mr-2" href="https://dig-studio.ru/" title="Главная">Главная</a>
                    </li>
                    <li class="nav-item [[IsPageActive? &pageTitle=`Портфолио`]]">
                        <a class="nav-link mr-2" href="portfolio" title="Портфолио">Портфолио</a>
                    </li>
                    
                    <li class="nav-item dropdown">
                        <!-- <a class="nav-link" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"> -->
                        <a class="nav-link" href="#" id="navbarDropdown">
                          Услуги
                        </a>
                        <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                          <a class="dropdown-item" href="/services/landing">Лендинг</a>
                          <a class="dropdown-item" href="/services/vizitka">Сайт-визитка</a>
                          <a class="dropdown-item" href="/services/web-design">Разработка веб-дизайна</a>
                        </div>
                    </li>
                    <li class="nav-item [[IsPageActive? &pageTitle=`О компании`]]">
                        <a class="nav-link mr-2" href="about" title="О компании">О нас</a>
                    </li>
                    <li class="nav-item [[IsPageActive? &pageTitle=`Контакты`]]">
                        <a class="nav-link mr-2" href="contacts" title="Контакты">Контакты</a>
                    </li>
                </ul>
            </div>
            <div class="phone-button ml-0 ml-md-3 text-center text-sm-right">
                <a href="tel:+78124480892" onclick="ym(52772032, \'reachGoal\', \'phoneCallId\');"><button class="btn btn-primary btn-md" type="button">[[*PhoneNumber]]</button></a>
            </div>
        </nav>
    </div>
</header>',
          'locked' => false,
          'properties' => 
          array (
          ),
          'static' => false,
          'static_file' => '',
          'content' => '<header class="header">
    <div class="container">
        <nav class="navbar navbar-expand-lg navbar-light" id="myNavbar">
            <a class="navbar-brand" href="/">
                <img class="img-logo" src="/assets/img/logos/logo-main.png" alt="Разработка и продвижение веб-сайтов" title="Разработка и продвижение сайтов в Санкт-Петербурге">
            </a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav ml-auto">
                    <li class="nav-item [[IsPageActive? &pageTitle=`Главная`]]">
                        <a class="nav-link mr-2" href="https://dig-studio.ru/" title="Главная">Главная</a>
                    </li>
                    <li class="nav-item [[IsPageActive? &pageTitle=`Портфолио`]]">
                        <a class="nav-link mr-2" href="portfolio" title="Портфолио">Портфолио</a>
                    </li>
                    
                    <li class="nav-item dropdown">
                        <!-- <a class="nav-link" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"> -->
                        <a class="nav-link" href="#" id="navbarDropdown">
                          Услуги
                        </a>
                        <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                          <a class="dropdown-item" href="/services/landing">Лендинг</a>
                          <a class="dropdown-item" href="/services/vizitka">Сайт-визитка</a>
                          <a class="dropdown-item" href="/services/web-design">Разработка веб-дизайна</a>
                        </div>
                    </li>
                    <li class="nav-item [[IsPageActive? &pageTitle=`О компании`]]">
                        <a class="nav-link mr-2" href="about" title="О компании">О нас</a>
                    </li>
                    <li class="nav-item [[IsPageActive? &pageTitle=`Контакты`]]">
                        <a class="nav-link mr-2" href="contacts" title="Контакты">Контакты</a>
                    </li>
                </ul>
            </div>
            <div class="phone-button ml-0 ml-md-3 text-center text-sm-right">
                <a href="tel:+78124480892" onclick="ym(52772032, \'reachGoal\', \'phoneCallId\');"><button class="btn btn-primary btn-md" type="button">[[*PhoneNumber]]</button></a>
            </div>
        </nav>
    </div>
</header>',
        ),
        'policies' => 
        array (
        ),
        'source' => 
        array (
          'id' => 1,
          'name' => 'Filesystem',
          'description' => '',
          'class_key' => 'sources.modFileMediaSource',
          'properties' => 
          array (
          ),
          'is_stream' => true,
        ),
      ),
      'Jumbo' => 
      array (
        'fields' => 
        array (
          'id' => 16,
          'source' => 1,
          'property_preprocess' => false,
          'name' => 'Jumbo',
          'description' => '',
          'editor_type' => 0,
          'category' => 0,
          'cache_type' => 0,
          'snippet' => '<div class="container-fluid">
    <div class="row mb-4">
        <div class="col">
            <div class="my-jumbotron" style="background-image: url(\'[[+pathToFile]]\');">
                <h1 class="inner-text">[[+text]]</h1>
            </div>            
        </div>
    </div>

</div>',
          'locked' => false,
          'properties' => 
          array (
            'pathToFile' => 
            array (
              'name' => 'pathToFile',
              'desc' => '',
              'type' => 'textfield',
              'options' => 
              array (
              ),
              'value' => '',
              'lexicon' => NULL,
              'area' => '',
              'desc_trans' => '',
              'area_trans' => '',
            ),
            'text' => 
            array (
              'name' => 'text',
              'desc' => '',
              'type' => 'textfield',
              'options' => 
              array (
              ),
              'value' => '',
              'lexicon' => NULL,
              'area' => '',
              'desc_trans' => '',
              'area_trans' => '',
            ),
          ),
          'static' => false,
          'static_file' => '',
          'content' => '<div class="container-fluid">
    <div class="row mb-4">
        <div class="col">
            <div class="my-jumbotron" style="background-image: url(\'[[+pathToFile]]\');">
                <h1 class="inner-text">[[+text]]</h1>
            </div>            
        </div>
    </div>

</div>',
        ),
        'policies' => 
        array (
        ),
        'source' => 
        array (
          'id' => 1,
          'name' => 'Filesystem',
          'description' => '',
          'class_key' => 'sources.modFileMediaSource',
          'properties' => 
          array (
          ),
          'is_stream' => true,
        ),
      ),
      'SpaceLine' => 
      array (
        'fields' => 
        array (
          'id' => 13,
          'source' => 1,
          'property_preprocess' => false,
          'name' => 'SpaceLine',
          'description' => '',
          'editor_type' => 0,
          'category' => 0,
          'cache_type' => 0,
          'snippet' => '<div class="container-fluid">
    <div class="row mt-4 mb-4">
        
    </div>
</div>',
          'locked' => false,
          'properties' => 
          array (
          ),
          'static' => false,
          'static_file' => '',
          'content' => '<div class="container-fluid">
    <div class="row mt-4 mb-4">
        
    </div>
</div>',
        ),
        'policies' => 
        array (
        ),
        'source' => 
        array (
          'id' => 1,
          'name' => 'Filesystem',
          'description' => '',
          'class_key' => 'sources.modFileMediaSource',
          'properties' => 
          array (
          ),
          'is_stream' => true,
        ),
      ),
      'Zagolovok' => 
      array (
        'fields' => 
        array (
          'id' => 12,
          'source' => 1,
          'property_preprocess' => false,
          'name' => 'Zagolovok',
          'description' => '',
          'editor_type' => 0,
          'category' => 0,
          'cache_type' => 0,
          'snippet' => '<div class="container-fluid mt-4">
    <div class="row">
        <div class="col">
            <h[[+level]] style="text-align: center;">
                [[+headingText]]
            </h[[+level]]>
        </div>
    </div>
</div>',
          'locked' => false,
          'properties' => 
          array (
            'headingText' => 
            array (
              'name' => 'headingText',
              'desc' => '',
              'type' => 'textfield',
              'options' => 
              array (
              ),
              'value' => '',
              'lexicon' => NULL,
              'area' => '',
              'desc_trans' => '',
              'area_trans' => '',
            ),
            'level' => 
            array (
              'name' => 'level',
              'desc' => '',
              'type' => 'numberfield',
              'options' => 
              array (
              ),
              'value' => '3',
              'lexicon' => NULL,
              'area' => '',
              'desc_trans' => '',
              'area_trans' => '',
            ),
          ),
          'static' => false,
          'static_file' => '',
          'content' => '<div class="container-fluid mt-4">
    <div class="row">
        <div class="col">
            <h[[+level]] style="text-align: center;">
                [[+headingText]]
            </h[[+level]]>
        </div>
    </div>
</div>',
        ),
        'policies' => 
        array (
        ),
        'source' => 
        array (
          'id' => 1,
          'name' => 'Filesystem',
          'description' => '',
          'class_key' => 'sources.modFileMediaSource',
          'properties' => 
          array (
          ),
          'is_stream' => true,
        ),
      ),
      'PricingVizitka' => 
      array (
        'fields' => 
        array (
          'id' => 28,
          'source' => 1,
          'property_preprocess' => false,
          'name' => 'PricingVizitka',
          'description' => '',
          'editor_type' => 0,
          'category' => 0,
          'cache_type' => 0,
          'snippet' => '<div class="container">
    <div class="row">
    <div class="col price-section mb-2">
        <article>
            <ul>
              <li class="bg-purple">
                <button>Пакет "Базовый"</button>
              </li>
              <li class="bg-blue active">
                <button>Пакет "Стандарт"</button>
              </li>
              <li class="bg-blue">
                <button>Пакет "Полный"</button>
              </li>
            </ul> 
        </article>
        
        <table>
          <thead>
            <tr>
              <th class="hide"></th>
              <th class="bg-purple">Пакет "Базовый"</th>
              <th class="bg-blue">Пакет "Стандарт"</th>
              <th class="bg-blue default">Пакет "Полный"</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td>Стоимость</td>
              <td><span class="txt-l">&asymp; 15 000 ₽</span></td>
              <td class="default"><span class="txt-l">&asymp; 40 000 ₽</span></td>
              <td><span class="txt-l">&asymp; 70 000 ₽</span></td>
            </tr>
            <tr>
                <td>Адаптивный дизайн</td>
                <td><span class="tick">&#10004;</span></td>
                <td class="default"><span class="tick">&#10004;</span></td>
                <td><span class="tick">&#10004;</span></td>
            </tr>
            <tr>
              <td>HTML-верстка и программирование</td>
              <td><span class="tick">&#10004;</span></td>
              <td class="default"><span class="tick">&#10004;</span></td>
              <td><span class="tick">&#10004;</span></td>
            </tr>
            <tr>
              <td>Анимационные эффекты</td>
              <td><span class="tick">&#10004;</span></td>
              <td class="default"><span class="tick">&#10004;</span></td>
              <td><span class="tick">&#10004;</span></td>
            </tr>
            <tr>
              <td>Визуальный редактор текста и фото (CMS)</td>
              <td><span class="tick">&#10004;</span></td>
              <td class="default"><span class="tick">&#10004;</span></td>
              <td><span class="tick">&#10004;</span></td>
            </tr>
            <tr>
              <td>SSL-сертификат</td>
              <td><span class="tick">&#10004;</span></td>
              <td class="default"><span class="tick">&#10004;</span></td>
              <td><span class="tick">&#10004;</span></td>
            </tr>
            <tr>
              <td>Подключение Яндекс Метрики и Google Analytics</td>
              <td><span class="tick">&#10004;</span></td>
              <td class="default"><span class="tick">&#10004;</span></td>
              <td><span class="tick">&#10004;</span></td>
            </tr>
            <tr>
              <td>Разработка нескольких прототипов дизайна</td>
              <td><span class="neg">-</span></td>
              <td class="default"><span class="tick">&#10004;</span></td>
              <td><span class="tick">&#10004;</span></td>
            </tr>
            <tr>
              <td>Уникальный дизайн</td>
              <td><span class="neg">Шаблонный</span></td>
              <td class="default"><span class="tick">&#10004;</span></td>
              <td><span class="tick">&#10004;</span></td>
            </tr>
            <tr>
              <td>Написание уникальных текстов</td>
              <td><span class="neg">-</span></td>
              <td class="default"><span class="tick">&#10004;</span></td>
              <td><span class="tick">&#10004;</span></td>
            </tr>
            <tr>
              <td>SEO-оптимизация</td>
              <td><span class="neg">-</span></td>
              <td class="default"><span class="tick">&#10004;</span></td>
              <td><span class="tick">&#10004;</span></td>
            </tr>
            <tr>
              <td>Анализ конкурентов и лидеров рынка</td>
              <td><span class="neg">-</span></td>
              <td class="default"><span class="neg">-</span></td>
              <td><span class="tick">&#10004;</span></td>
            </tr>
            <tr>
              <td>Настройка рекламы Яндекс и Google</td>
              <td><span class="neg">-</span></td>
              <td class="default"><span class="neg">-</span></td>
              <td><span class="tick">&#10004;</span></td>
            </tr>   
            <tr>
              <td>Отладка рекламы в течение 3 месяцев</td>
              <td><span class="neg">-</span></td>
              <td class="default"><span class="neg">-</span></td>
              <td><span class="tick">&#10004;</span></td>
            </tr>
            <tr>
              <td>Интеграция с почтой и CRM</td>
              <td><span class="neg">-</span></td>
              <td class="default"><span class="neg">-</span></td>
              <td><span class="tick">&#10004;</span></td>
            </tr>
            <tr>
              <td>SMS-информирование</td>
              <td><span class="neg">-</span></td>
              <td class="default"><span class="neg">-</span></td>
              <td><span class="tick">&#10004;</span></td>
            </tr>
          </tbody>
        </table>
</div>
    </div>
    </div>
</div>
<script>
    $( ".price-section ul" ).on( "click", "li", function() {
  var pos = $(this).index()+2;
  $(".price-section tr").find(\'td:not(:eq(0))\').hide();
  $(\'.price-section td:nth-child(\'+pos+\')\').css(\'display\',\'table-cell\');
  $(".price-section tr").find(\'th:not(:eq(0))\').hide();
  $(\'.price-section li\').removeClass(\'active\');
  $(this).addClass(\'active\');
});

// Initialize the media query
  var mediaQuery = window.matchMedia(\'(min-width: 768px)\');
  
  // Add a listen event
  mediaQuery.addListener(doSomething);
  
  // Function to do something with the media query
  function doSomething(mediaQuery) {    
    if (mediaQuery.matches) {
      $(\'.sep\').attr(\'colspan\',5);
    } else {
      $(\'.sep\').attr(\'colspan\',2);
    }
  }
  
  // On load
  doSomething(mediaQuery);
</script>',
          'locked' => false,
          'properties' => 
          array (
          ),
          'static' => false,
          'static_file' => '',
          'content' => '<div class="container">
    <div class="row">
    <div class="col price-section mb-2">
        <article>
            <ul>
              <li class="bg-purple">
                <button>Пакет "Базовый"</button>
              </li>
              <li class="bg-blue active">
                <button>Пакет "Стандарт"</button>
              </li>
              <li class="bg-blue">
                <button>Пакет "Полный"</button>
              </li>
            </ul> 
        </article>
        
        <table>
          <thead>
            <tr>
              <th class="hide"></th>
              <th class="bg-purple">Пакет "Базовый"</th>
              <th class="bg-blue">Пакет "Стандарт"</th>
              <th class="bg-blue default">Пакет "Полный"</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td>Стоимость</td>
              <td><span class="txt-l">&asymp; 15 000 ₽</span></td>
              <td class="default"><span class="txt-l">&asymp; 40 000 ₽</span></td>
              <td><span class="txt-l">&asymp; 70 000 ₽</span></td>
            </tr>
            <tr>
                <td>Адаптивный дизайн</td>
                <td><span class="tick">&#10004;</span></td>
                <td class="default"><span class="tick">&#10004;</span></td>
                <td><span class="tick">&#10004;</span></td>
            </tr>
            <tr>
              <td>HTML-верстка и программирование</td>
              <td><span class="tick">&#10004;</span></td>
              <td class="default"><span class="tick">&#10004;</span></td>
              <td><span class="tick">&#10004;</span></td>
            </tr>
            <tr>
              <td>Анимационные эффекты</td>
              <td><span class="tick">&#10004;</span></td>
              <td class="default"><span class="tick">&#10004;</span></td>
              <td><span class="tick">&#10004;</span></td>
            </tr>
            <tr>
              <td>Визуальный редактор текста и фото (CMS)</td>
              <td><span class="tick">&#10004;</span></td>
              <td class="default"><span class="tick">&#10004;</span></td>
              <td><span class="tick">&#10004;</span></td>
            </tr>
            <tr>
              <td>SSL-сертификат</td>
              <td><span class="tick">&#10004;</span></td>
              <td class="default"><span class="tick">&#10004;</span></td>
              <td><span class="tick">&#10004;</span></td>
            </tr>
            <tr>
              <td>Подключение Яндекс Метрики и Google Analytics</td>
              <td><span class="tick">&#10004;</span></td>
              <td class="default"><span class="tick">&#10004;</span></td>
              <td><span class="tick">&#10004;</span></td>
            </tr>
            <tr>
              <td>Разработка нескольких прототипов дизайна</td>
              <td><span class="neg">-</span></td>
              <td class="default"><span class="tick">&#10004;</span></td>
              <td><span class="tick">&#10004;</span></td>
            </tr>
            <tr>
              <td>Уникальный дизайн</td>
              <td><span class="neg">Шаблонный</span></td>
              <td class="default"><span class="tick">&#10004;</span></td>
              <td><span class="tick">&#10004;</span></td>
            </tr>
            <tr>
              <td>Написание уникальных текстов</td>
              <td><span class="neg">-</span></td>
              <td class="default"><span class="tick">&#10004;</span></td>
              <td><span class="tick">&#10004;</span></td>
            </tr>
            <tr>
              <td>SEO-оптимизация</td>
              <td><span class="neg">-</span></td>
              <td class="default"><span class="tick">&#10004;</span></td>
              <td><span class="tick">&#10004;</span></td>
            </tr>
            <tr>
              <td>Анализ конкурентов и лидеров рынка</td>
              <td><span class="neg">-</span></td>
              <td class="default"><span class="neg">-</span></td>
              <td><span class="tick">&#10004;</span></td>
            </tr>
            <tr>
              <td>Настройка рекламы Яндекс и Google</td>
              <td><span class="neg">-</span></td>
              <td class="default"><span class="neg">-</span></td>
              <td><span class="tick">&#10004;</span></td>
            </tr>   
            <tr>
              <td>Отладка рекламы в течение 3 месяцев</td>
              <td><span class="neg">-</span></td>
              <td class="default"><span class="neg">-</span></td>
              <td><span class="tick">&#10004;</span></td>
            </tr>
            <tr>
              <td>Интеграция с почтой и CRM</td>
              <td><span class="neg">-</span></td>
              <td class="default"><span class="neg">-</span></td>
              <td><span class="tick">&#10004;</span></td>
            </tr>
            <tr>
              <td>SMS-информирование</td>
              <td><span class="neg">-</span></td>
              <td class="default"><span class="neg">-</span></td>
              <td><span class="tick">&#10004;</span></td>
            </tr>
          </tbody>
        </table>
</div>
    </div>
    </div>
</div>
<script>
    $( ".price-section ul" ).on( "click", "li", function() {
  var pos = $(this).index()+2;
  $(".price-section tr").find(\'td:not(:eq(0))\').hide();
  $(\'.price-section td:nth-child(\'+pos+\')\').css(\'display\',\'table-cell\');
  $(".price-section tr").find(\'th:not(:eq(0))\').hide();
  $(\'.price-section li\').removeClass(\'active\');
  $(this).addClass(\'active\');
});

// Initialize the media query
  var mediaQuery = window.matchMedia(\'(min-width: 768px)\');
  
  // Add a listen event
  mediaQuery.addListener(doSomething);
  
  // Function to do something with the media query
  function doSomething(mediaQuery) {    
    if (mediaQuery.matches) {
      $(\'.sep\').attr(\'colspan\',5);
    } else {
      $(\'.sep\').attr(\'colspan\',2);
    }
  }
  
  // On load
  doSomething(mediaQuery);
</script>',
        ),
        'policies' => 
        array (
        ),
        'source' => 
        array (
          'id' => 1,
          'name' => 'Filesystem',
          'description' => '',
          'class_key' => 'sources.modFileMediaSource',
          'properties' => 
          array (
          ),
          'is_stream' => true,
        ),
      ),
      'ButtonCenter' => 
      array (
        'fields' => 
        array (
          'id' => 17,
          'source' => 1,
          'property_preprocess' => false,
          'name' => 'ButtonCenter',
          'description' => '',
          'editor_type' => 0,
          'category' => 0,
          'cache_type' => 0,
          'snippet' => '<div class="row">
    <div class="col text-center mt-3">
        <button type="button" class="btn btn-primary btn-lg" data-toggle="modal" data-target="[[+link]]">[[+text]]</button>
    </div>
</div>',
          'locked' => false,
          'properties' => 
          array (
            'link' => 
            array (
              'name' => 'link',
              'desc' => '',
              'type' => 'textfield',
              'options' => 
              array (
              ),
              'value' => '#',
              'lexicon' => NULL,
              'area' => '',
              'desc_trans' => '',
              'area_trans' => '',
            ),
            'text' => 
            array (
              'name' => 'text',
              'desc' => '',
              'type' => 'textfield',
              'options' => 
              array (
              ),
              'value' => '',
              'lexicon' => NULL,
              'area' => '',
              'desc_trans' => '',
              'area_trans' => '',
            ),
          ),
          'static' => false,
          'static_file' => '',
          'content' => '<div class="row">
    <div class="col text-center mt-3">
        <button type="button" class="btn btn-primary btn-lg" data-toggle="modal" data-target="[[+link]]">[[+text]]</button>
    </div>
</div>',
        ),
        'policies' => 
        array (
        ),
        'source' => 
        array (
          'id' => 1,
          'name' => 'Filesystem',
          'description' => '',
          'class_key' => 'sources.modFileMediaSource',
          'properties' => 
          array (
          ),
          'is_stream' => true,
        ),
      ),
      'FinalScripts' => 
      array (
        'fields' => 
        array (
          'id' => 4,
          'source' => 1,
          'property_preprocess' => false,
          'name' => 'FinalScripts',
          'description' => '',
          'editor_type' => 0,
          'category' => 0,
          'cache_type' => 0,
          'snippet' => '<!--<script src="https://cdnjs.cloudflare.com/ajax/libs/1000hz-bootstrap-validator/0.11.9/validator.min.js"></script>-->
<script>
    function showModal() {
        $("#form1").modal(\'show\');
    }
    function showModalIfDesktopOrTablet() {
        var w = $(document).width();
        if (w >= 768) {
            showModal();
        }
    }
    $("#btnUp").on(\'click\', function() {
        jQuery(\'html,body\').animate({scrollTop:0},700);
    });
    function scrollTop() {
        
        
    }
    function validateForm() {
        var isChecked = $(\'#licenceCheck\').prop(\'checked\');
        if (!isChecked) {
            $(\'#licence-check-id\').attr(\'style\',  \'color: red\');
        } else {
            $(\'#licence-check-id\').removeAttr(\'style\');
        }
        var phone = document.getElementById(\'inputPhone\').value;
        var isPhoneOk = (phone.length >= 7);
        if (!isPhoneOk) {
            $(\'#form1 #inputPhone\').attr(\'style\', \'border: 1px solid red;\');
            if (phone.length == 0) {
                $(\'#form1 #errorPhoneIncorrectId\').attr(\'style\', \'display: none;\');
                $(\'#form1 #errorPhoneEmptyId\').attr(\'style\', \'display: inline;\');
            } else {
                $(\'#form1 #errorPhoneEmptyId\').attr(\'style\', \'display: none;\');
                $(\'#form1 #errorPhoneIncorrectId\').attr(\'style\', \'display: inline;\');
            }
        } else {
            $(\'#form1 #errorPhoneIncorrectId\').attr(\'style\', \'display: none;\');
            $(\'#form1 #errorPhoneEmptyId\').attr(\'style\', \'display: none;\');
            $(\'#form1 #inputPhone\').removeAttr(\'style\');
        }
        return isChecked && isPhoneOk;
    }
    function submitForm() {
        var inputEmail = document.getElementById("inputEmail").value;
        var inputPhone = document.getElementById("inputPhone").value;
        var inputName = document.getElementById("inputName").value;
        var inputComment = document.getElementById("inputComment").value;
        var isValid = validateForm();
        if (!isValid) {
            return;
        }
        $.ajax({
            type: \'POST\',
            url: \'https://dig-studio.ru/assets/php/mailer.php/\',
            data: { 
                \'inputEmail\': inputEmail, 
                \'inputPhone\': inputPhone,
                \'inputName\': inputName,
                \'inputComment\': inputComment
            },
            success: function(msg){
                //alert("Server Response:\\n" + msg);
                if (msg.localeCompare("200")==0) {
                    $("#modal-success").modal(\'show\');
                }
            }
        });
        ym(52772032, \'reachGoal\', \'sendFormId\');
        $("#form1").modal(\'hide\');
    }
</script>',
          'locked' => false,
          'properties' => 
          array (
          ),
          'static' => false,
          'static_file' => '',
          'content' => '<!--<script src="https://cdnjs.cloudflare.com/ajax/libs/1000hz-bootstrap-validator/0.11.9/validator.min.js"></script>-->
<script>
    function showModal() {
        $("#form1").modal(\'show\');
    }
    function showModalIfDesktopOrTablet() {
        var w = $(document).width();
        if (w >= 768) {
            showModal();
        }
    }
    $("#btnUp").on(\'click\', function() {
        jQuery(\'html,body\').animate({scrollTop:0},700);
    });
    function scrollTop() {
        
        
    }
    function validateForm() {
        var isChecked = $(\'#licenceCheck\').prop(\'checked\');
        if (!isChecked) {
            $(\'#licence-check-id\').attr(\'style\',  \'color: red\');
        } else {
            $(\'#licence-check-id\').removeAttr(\'style\');
        }
        var phone = document.getElementById(\'inputPhone\').value;
        var isPhoneOk = (phone.length >= 7);
        if (!isPhoneOk) {
            $(\'#form1 #inputPhone\').attr(\'style\', \'border: 1px solid red;\');
            if (phone.length == 0) {
                $(\'#form1 #errorPhoneIncorrectId\').attr(\'style\', \'display: none;\');
                $(\'#form1 #errorPhoneEmptyId\').attr(\'style\', \'display: inline;\');
            } else {
                $(\'#form1 #errorPhoneEmptyId\').attr(\'style\', \'display: none;\');
                $(\'#form1 #errorPhoneIncorrectId\').attr(\'style\', \'display: inline;\');
            }
        } else {
            $(\'#form1 #errorPhoneIncorrectId\').attr(\'style\', \'display: none;\');
            $(\'#form1 #errorPhoneEmptyId\').attr(\'style\', \'display: none;\');
            $(\'#form1 #inputPhone\').removeAttr(\'style\');
        }
        return isChecked && isPhoneOk;
    }
    function submitForm() {
        var inputEmail = document.getElementById("inputEmail").value;
        var inputPhone = document.getElementById("inputPhone").value;
        var inputName = document.getElementById("inputName").value;
        var inputComment = document.getElementById("inputComment").value;
        var isValid = validateForm();
        if (!isValid) {
            return;
        }
        $.ajax({
            type: \'POST\',
            url: \'https://dig-studio.ru/assets/php/mailer.php/\',
            data: { 
                \'inputEmail\': inputEmail, 
                \'inputPhone\': inputPhone,
                \'inputName\': inputName,
                \'inputComment\': inputComment
            },
            success: function(msg){
                //alert("Server Response:\\n" + msg);
                if (msg.localeCompare("200")==0) {
                    $("#modal-success").modal(\'show\');
                }
            }
        });
        ym(52772032, \'reachGoal\', \'sendFormId\');
        $("#form1").modal(\'hide\');
    }
</script>',
        ),
        'policies' => 
        array (
        ),
        'source' => 
        array (
          'id' => 1,
          'name' => 'Filesystem',
          'description' => '',
          'class_key' => 'sources.modFileMediaSource',
          'properties' => 
          array (
          ),
          'is_stream' => true,
        ),
      ),
      'FOOTER' => 
      array (
        'fields' => 
        array (
          'id' => 3,
          'source' => 1,
          'property_preprocess' => false,
          'name' => 'FOOTER',
          'description' => '',
          'editor_type' => 0,
          'category' => 0,
          'cache_type' => 0,
          'snippet' => '<div class="footer-background">
    <footer class="container">
        <div class="row row-with-logo">
            <div class="col-md-3 col-sm-12 text-center mt-4">
                <a href="/">
                    <img class="logo-img" src="/assets/img/logos/logo-main-white.png" alt="Создание и продвижение сайтов" title="Создание и продвижение сайтов в Санкт-Петербурге">
                </a>
            </div>
            <div class="col-md-3 col-sm-12 text-center mt-0 mt-md-4">
                <p>СПб, 16-я линия В.О., д. 75</p>
            </div>
            <div class="col-md-3 col-sm-12 text-center mt-0 mt-md-4">
                <a href="tel:+78124480892" onclick="ym(52772032, \'reachGoal\', \'phoneCallId\');"><p>+7 (812) 448-08-92</p></a>
            </div>
            <div class="col-md-3 col-sm-12 text-center mt-0 mt-md-4">
                <a href="mailto:info@dig-studio.ru"><p>info@dig-studio.ru</p></a>
            </div>
        </div>
        <hr>
        <div class="row">
            <div class="col mt-3 pb-2">
                <p style="text-align: center;">Создание сайтов и их продвижение в Санкт-Петербурге. Разработка мобильных приложений.<br>&copy; «Digital Studio» 2016-2019.</p>
            </div>
        </div>
    </footer>
</div>
',
          'locked' => false,
          'properties' => 
          array (
          ),
          'static' => false,
          'static_file' => '',
          'content' => '<div class="footer-background">
    <footer class="container">
        <div class="row row-with-logo">
            <div class="col-md-3 col-sm-12 text-center mt-4">
                <a href="/">
                    <img class="logo-img" src="/assets/img/logos/logo-main-white.png" alt="Создание и продвижение сайтов" title="Создание и продвижение сайтов в Санкт-Петербурге">
                </a>
            </div>
            <div class="col-md-3 col-sm-12 text-center mt-0 mt-md-4">
                <p>СПб, 16-я линия В.О., д. 75</p>
            </div>
            <div class="col-md-3 col-sm-12 text-center mt-0 mt-md-4">
                <a href="tel:+78124480892" onclick="ym(52772032, \'reachGoal\', \'phoneCallId\');"><p>+7 (812) 448-08-92</p></a>
            </div>
            <div class="col-md-3 col-sm-12 text-center mt-0 mt-md-4">
                <a href="mailto:info@dig-studio.ru"><p>info@dig-studio.ru</p></a>
            </div>
        </div>
        <hr>
        <div class="row">
            <div class="col mt-3 pb-2">
                <p style="text-align: center;">Создание сайтов и их продвижение в Санкт-Петербурге. Разработка мобильных приложений.<br>&copy; «Digital Studio» 2016-2019.</p>
            </div>
        </div>
    </footer>
</div>
',
        ),
        'policies' => 
        array (
        ),
        'source' => 
        array (
          'id' => 1,
          'name' => 'Filesystem',
          'description' => '',
          'class_key' => 'sources.modFileMediaSource',
          'properties' => 
          array (
          ),
          'is_stream' => true,
        ),
      ),
      'CloseHTML' => 
      array (
        'fields' => 
        array (
          'id' => 22,
          'source' => 1,
          'property_preprocess' => false,
          'name' => 'CloseHTML',
          'description' => '',
          'editor_type' => 0,
          'category' => 0,
          'cache_type' => 0,
          'snippet' => '</body>
</html>',
          'locked' => false,
          'properties' => 
          array (
          ),
          'static' => false,
          'static_file' => '',
          'content' => '</body>
</html>',
        ),
        'policies' => 
        array (
        ),
        'source' => 
        array (
          'id' => 1,
          'name' => 'Filesystem',
          'description' => '',
          'class_key' => 'sources.modFileMediaSource',
          'properties' => 
          array (
          ),
          'is_stream' => true,
        ),
      ),
    ),
    'modSnippet' => 
    array (
      'LinkExternals' => 
      array (
        'fields' => 
        array (
          'id' => 4,
          'source' => 1,
          'property_preprocess' => false,
          'name' => 'LinkExternals',
          'description' => 'Подключает пользовательские стили',
          'editor_type' => 0,
          'category' => 0,
          'cache_type' => 0,
          'snippet' => '$modx->regClientCSS(MODX_ASSETS_URL."css/style.css");
$modx->regClientCSS(\'https://fonts.googleapis.com/icon?family=Material+Icons\');',
          'locked' => false,
          'properties' => 
          array (
          ),
          'moduleguid' => '',
          'static' => false,
          'static_file' => '',
          'content' => '$modx->regClientCSS(MODX_ASSETS_URL."css/style.css");
$modx->regClientCSS(\'https://fonts.googleapis.com/icon?family=Material+Icons\');',
        ),
        'policies' => 
        array (
        ),
        'source' => 
        array (
          'id' => 1,
          'name' => 'Filesystem',
          'description' => '',
          'class_key' => 'sources.modFileMediaSource',
          'properties' => 
          array (
          ),
          'is_stream' => true,
        ),
      ),
      'IsPageActive' => 
      array (
        'fields' => 
        array (
          'id' => 12,
          'source' => 1,
          'property_preprocess' => false,
          'name' => 'IsPageActive',
          'description' => '',
          'editor_type' => 0,
          'category' => 0,
          'cache_type' => 0,
          'snippet' => '$title = $modx->resource->get(\'menutitle\'); //получаем ID текущей страницы
if (strcmp($title, $pageTitle) == 0) {
    return "active";
} else {
    return "";
}',
          'locked' => false,
          'properties' => 
          array (
            'pageTitle' => 
            array (
              'name' => 'pageTitle',
              'desc' => '',
              'type' => 'textfield',
              'options' => 
              array (
              ),
              'value' => '',
              'lexicon' => NULL,
              'area' => '',
              'desc_trans' => '',
              'area_trans' => '',
            ),
          ),
          'moduleguid' => '',
          'static' => false,
          'static_file' => '',
          'content' => '$title = $modx->resource->get(\'menutitle\'); //получаем ID текущей страницы
if (strcmp($title, $pageTitle) == 0) {
    return "active";
} else {
    return "";
}',
        ),
        'policies' => 
        array (
        ),
        'source' => 
        array (
          'id' => 1,
          'name' => 'Filesystem',
          'description' => '',
          'class_key' => 'sources.modFileMediaSource',
          'properties' => 
          array (
          ),
          'is_stream' => true,
        ),
      ),
      'GenPortfolioTile' => 
      array (
        'fields' => 
        array (
          'id' => 11,
          'source' => 1,
          'property_preprocess' => false,
          'name' => 'GenPortfolioTile',
          'description' => '',
          'editor_type' => 0,
          'category' => 0,
          'cache_type' => 0,
          'snippet' => 'require_once MODX_BASE_PATH.\'/assets/php/lib.php\';
return genWorkTile($link, $src, $name, $group);',
          'locked' => false,
          'properties' => 
          array (
            'group' => 
            array (
              'name' => 'group',
              'desc' => '',
              'type' => 'textfield',
              'options' => 
              array (
              ),
              'value' => '',
              'lexicon' => NULL,
              'area' => '',
              'desc_trans' => '',
              'area_trans' => '',
            ),
            'link' => 
            array (
              'name' => 'link',
              'desc' => '',
              'type' => 'textfield',
              'options' => 
              array (
              ),
              'value' => '',
              'lexicon' => NULL,
              'area' => '',
              'desc_trans' => '',
              'area_trans' => '',
            ),
            'name' => 
            array (
              'name' => 'name',
              'desc' => '',
              'type' => 'textfield',
              'options' => 
              array (
              ),
              'value' => '',
              'lexicon' => NULL,
              'area' => '',
              'desc_trans' => '',
              'area_trans' => '',
            ),
            'src' => 
            array (
              'name' => 'src',
              'desc' => '',
              'type' => 'textfield',
              'options' => 
              array (
              ),
              'value' => '',
              'lexicon' => NULL,
              'area' => '',
              'desc_trans' => '',
              'area_trans' => '',
            ),
          ),
          'moduleguid' => '',
          'static' => true,
          'static_file' => 'assets/php/genWorkTile.php',
          'content' => 'require_once MODX_BASE_PATH.\'/assets/php/lib.php\';
return genWorkTile($link, $src, $name, $group);',
        ),
        'policies' => 
        array (
        ),
        'source' => 
        array (
          'id' => 1,
          'name' => 'Filesystem',
          'description' => '',
          'class_key' => 'sources.modFileMediaSource',
          'properties' => 
          array (
          ),
          'is_stream' => true,
        ),
      ),
    ),
    'modTemplateVar' => 
    array (
      'PhoneNumber' => 
      array (
        'fields' => 
        array (
          'id' => 1,
          'source' => 1,
          'property_preprocess' => false,
          'type' => 'text',
          'name' => 'PhoneNumber',
          'caption' => 'Номер основного телефона',
          'description' => 'Номер основного телефона',
          'editor_type' => 0,
          'category' => 0,
          'locked' => false,
          'elements' => '',
          'rank' => 0,
          'display' => 'default',
          'default_text' => '+7 (812) 448-08-92',
          'properties' => 
          array (
          ),
          'input_properties' => 
          array (
            'allowBlank' => 'true',
            'minLength' => '',
            'maxLength' => '',
            'regex' => '',
            'regexText' => '',
          ),
          'output_properties' => 
          array (
          ),
          'static' => false,
          'static_file' => '',
          'content' => '+7 (812) 448-08-92',
        ),
        'policies' => 
        array (
        ),
        'source' => 
        array (
          'id' => 1,
          'name' => 'Filesystem',
          'description' => '',
          'class_key' => 'sources.modFileMediaSource',
          'properties' => 
          array (
          ),
          'is_stream' => true,
        ),
      ),
    ),
  ),
);