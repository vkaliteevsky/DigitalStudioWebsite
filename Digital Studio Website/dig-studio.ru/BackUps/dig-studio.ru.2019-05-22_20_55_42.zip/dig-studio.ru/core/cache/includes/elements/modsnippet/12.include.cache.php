<?php
$title = $modx->resource->get('menutitle'); //получаем ID текущей страницы
if (strcmp($title, $pageTitle) == 0) {
    return "active";
} else {
    return "";
}
return;
