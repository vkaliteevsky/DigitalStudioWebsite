<?php
/* Smarty version 3.1.33, created on 2019-03-14 22:53:26
  from '/var/www/u0667852/data/www/dig-studio.ru/manager/templates/default/element/plugin/update.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.33',
  'unifunc' => 'content_5c8ab136bd3c48_87567611',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'cf8077fd7591964a4a40c53479ab1b4e8235ac86' => 
    array (
      0 => '/var/www/u0667852/data/www/dig-studio.ru/manager/templates/default/element/plugin/update.tpl',
      1 => 1550128366,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5c8ab136bd3c48_87567611 (Smarty_Internal_Template $_smarty_tpl) {
?><div id="modx-panel-plugin-div"></div>
<?php echo $_smarty_tpl->tpl_vars['onPluginFormPrerender']->value;
}
}
