<?php
/* Smarty version 3.1.33, created on 2019-03-13 12:22:18
  from '/var/www/u0667852/data/www/dig-studio.ru/core/components/stercseo/templates/home.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.33',
  'unifunc' => 'content_5c88cbcaa2bf26_28839009',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '8135df56bbfd6a4ca46867afb9970ea1f06cd2ea' => 
    array (
      0 => '/var/www/u0667852/data/www/dig-studio.ru/core/components/stercseo/templates/home.tpl',
      1 => 1552465028,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5c88cbcaa2bf26_28839009 (Smarty_Internal_Template $_smarty_tpl) {
?><div id="stercseo-panel-home-div"></div><?php }
}
