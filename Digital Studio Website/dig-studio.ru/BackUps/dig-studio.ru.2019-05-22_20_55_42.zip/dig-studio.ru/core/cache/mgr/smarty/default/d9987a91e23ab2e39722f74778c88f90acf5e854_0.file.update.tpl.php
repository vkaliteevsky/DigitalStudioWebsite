<?php
/* Smarty version 3.1.33, created on 2019-03-15 00:02:05
  from '/var/www/u0667852/data/www/dig-studio.ru/manager/templates/default/resource/staticresource/update.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.33',
  'unifunc' => 'content_5c8ac14dd18f31_27917714',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'd9987a91e23ab2e39722f74778c88f90acf5e854' => 
    array (
      0 => '/var/www/u0667852/data/www/dig-studio.ru/manager/templates/default/resource/staticresource/update.tpl',
      1 => 1550128366,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5c8ac14dd18f31_27917714 (Smarty_Internal_Template $_smarty_tpl) {
?><div id="modx-panel-static-div"></div>
<div id="modx-resource-tvs-div" class="modx-resource-tab x-form-label-left x-panel"><?php echo (($tmp = @$_smarty_tpl->tpl_vars['tvOutput']->value)===null||$tmp==='' ? '' : $tmp);?>
</div>

<?php echo $_smarty_tpl->tpl_vars['onDocFormPrerender']->value;?>

<?php if ($_smarty_tpl->tpl_vars['resource']->value->richtext && $_smarty_tpl->tpl_vars['_config']->value['use_editor']) {?>
    <?php echo $_smarty_tpl->tpl_vars['onRichTextEditorInit']->value;?>

<?php }
}
}
