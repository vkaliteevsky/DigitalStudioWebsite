<?php
/* Smarty version 3.1.33, created on 2019-03-17 12:07:06
  from '/var/www/u0667852/data/www/dig-studio.ru/manager/templates/default/element/chunk/create.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.33',
  'unifunc' => 'content_5c8e0e3a6f57c4_64600766',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '310f2fdfa3682e8de2a8e2551b914d0a8b138285' => 
    array (
      0 => '/var/www/u0667852/data/www/dig-studio.ru/manager/templates/default/element/chunk/create.tpl',
      1 => 1550128366,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5c8e0e3a6f57c4_64600766 (Smarty_Internal_Template $_smarty_tpl) {
?><div id="modx-panel-chunk-div"></div>
<?php echo $_smarty_tpl->tpl_vars['onChunkFormPrerender']->value;
}
}
