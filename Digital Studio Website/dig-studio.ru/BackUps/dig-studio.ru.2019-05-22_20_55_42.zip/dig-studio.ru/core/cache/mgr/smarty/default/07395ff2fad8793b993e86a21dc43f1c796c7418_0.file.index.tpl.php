<?php
/* Smarty version 3.1.33, created on 2019-03-14 22:51:36
  from '/var/www/u0667852/data/www/dig-studio.ru/manager/templates/default/workspaces/index.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.33',
  'unifunc' => 'content_5c8ab0c8029d21_85168571',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '07395ff2fad8793b993e86a21dc43f1c796c7418' => 
    array (
      0 => '/var/www/u0667852/data/www/dig-studio.ru/manager/templates/default/workspaces/index.tpl',
      1 => 1550128366,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5c8ab0c8029d21_85168571 (Smarty_Internal_Template $_smarty_tpl) {
echo (($tmp = @$_smarty_tpl->tpl_vars['error']->value)===null||$tmp==='' ? '' : $tmp);?>

<div id="modx-panel-workspace-div"></div>
<?php }
}
