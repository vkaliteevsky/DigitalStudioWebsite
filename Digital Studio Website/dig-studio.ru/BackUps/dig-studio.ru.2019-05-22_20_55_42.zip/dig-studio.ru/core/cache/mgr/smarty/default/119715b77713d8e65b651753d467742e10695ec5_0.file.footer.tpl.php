<?php
/* Smarty version 3.1.33, created on 2019-03-13 11:35:59
  from '/var/www/u0667852/data/www/dig-studio.ru/manager/templates/default/footer.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.33',
  'unifunc' => 'content_5c88c0efb79146_08576324',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '119715b77713d8e65b651753d467742e10695ec5' => 
    array (
      0 => '/var/www/u0667852/data/www/dig-studio.ru/manager/templates/default/footer.tpl',
      1 => 1550128366,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5c88c0efb79146_08576324 (Smarty_Internal_Template $_smarty_tpl) {
?>    </div>
    <!-- #modx-content-->
    <div id="modx-footer"></div>
</div>
<!-- #modx-container -->

</body>
</html><?php }
}
