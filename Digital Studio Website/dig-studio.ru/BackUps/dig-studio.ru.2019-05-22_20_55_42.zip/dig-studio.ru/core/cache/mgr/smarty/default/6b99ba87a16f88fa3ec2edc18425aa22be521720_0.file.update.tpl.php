<?php
/* Smarty version 3.1.33, created on 2019-03-13 11:55:38
  from '/var/www/u0667852/data/www/dig-studio.ru/manager/templates/default/element/chunk/update.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.33',
  'unifunc' => 'content_5c88c58a27ca92_97038420',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '6b99ba87a16f88fa3ec2edc18425aa22be521720' => 
    array (
      0 => '/var/www/u0667852/data/www/dig-studio.ru/manager/templates/default/element/chunk/update.tpl',
      1 => 1550128366,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5c88c58a27ca92_97038420 (Smarty_Internal_Template $_smarty_tpl) {
?><div id="modx-panel-chunk-div"></div>
<?php echo $_smarty_tpl->tpl_vars['onChunkFormPrerender']->value;
}
}
