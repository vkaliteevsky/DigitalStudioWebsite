<?php
/* Smarty version 3.1.33, created on 2019-03-17 12:28:46
  from '/var/www/u0667852/data/www/dig-studio.ru/manager/templates/default/element/snippet/create.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.33',
  'unifunc' => 'content_5c8e134e2e1664_27055920',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'b8086e80bbc1d962bbe6048a25dc28518860e781' => 
    array (
      0 => '/var/www/u0667852/data/www/dig-studio.ru/manager/templates/default/element/snippet/create.tpl',
      1 => 1550128366,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5c8e134e2e1664_27055920 (Smarty_Internal_Template $_smarty_tpl) {
?><div id="modx-panel-snippet-div"></div>
<?php echo $_smarty_tpl->tpl_vars['onSnipFormPrerender']->value;
}
}
