<?php
/* Smarty version 3.1.33, created on 2019-03-18 19:57:13
  from '/var/www/u0667852/data/www/dig-studio.ru/manager/templates/default/element/template/create.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.33',
  'unifunc' => 'content_5c8fcde949c1d2_66411962',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '9473a1b29db5c496312410fa80ca97c9c0a2a5ce' => 
    array (
      0 => '/var/www/u0667852/data/www/dig-studio.ru/manager/templates/default/element/template/create.tpl',
      1 => 1550128366,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5c8fcde949c1d2_66411962 (Smarty_Internal_Template $_smarty_tpl) {
?><div id="modx-panel-template-div"></div>
<?php echo $_smarty_tpl->tpl_vars['onTempFormPrerender']->value;
}
}
