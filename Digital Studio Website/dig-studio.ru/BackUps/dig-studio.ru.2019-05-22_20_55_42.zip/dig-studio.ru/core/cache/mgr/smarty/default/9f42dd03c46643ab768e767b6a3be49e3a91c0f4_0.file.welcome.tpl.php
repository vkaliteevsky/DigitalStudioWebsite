<?php
/* Smarty version 3.1.33, created on 2019-03-13 11:35:59
  from '/var/www/u0667852/data/www/dig-studio.ru/manager/templates/default/welcome.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.33',
  'unifunc' => 'content_5c88c0efb75b85_83817135',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '9f42dd03c46643ab768e767b6a3be49e3a91c0f4' => 
    array (
      0 => '/var/www/u0667852/data/www/dig-studio.ru/manager/templates/default/welcome.tpl',
      1 => 1550128366,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5c88c0efb75b85_83817135 (Smarty_Internal_Template $_smarty_tpl) {
?><div id="modx-panel-welcome-div"></div>

<div id="modx-dashboard" class="dashboard">
<?php echo $_smarty_tpl->tpl_vars['dashboard']->value;?>

</div><?php }
}
