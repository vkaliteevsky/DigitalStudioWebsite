<?php
/* Smarty version 3.1.33, created on 2019-03-13 11:36:11
  from '/var/www/u0667852/data/www/dig-studio.ru/manager/templates/default/element/template/update.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.33',
  'unifunc' => 'content_5c88c0fb4c3b45_50530355',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'c3b630405e612544c42c1837078ad4c7b3336e2d' => 
    array (
      0 => '/var/www/u0667852/data/www/dig-studio.ru/manager/templates/default/element/template/update.tpl',
      1 => 1550128366,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5c88c0fb4c3b45_50530355 (Smarty_Internal_Template $_smarty_tpl) {
?><div id="modx-panel-template-div"></div>
<?php echo $_smarty_tpl->tpl_vars['onTempFormPrerender']->value;
}
}
