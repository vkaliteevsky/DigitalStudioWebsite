<?php  return array (
  'modx_news' => 'MODX News',
  'security_notices' => 'Security Notices',
  'welcome_messages' => 'Your Inbox contains <strong>%d</strong> message(s), of which <strong>%s</strong> are unread.',
  'welcome_title' => 'Welcome to your MODX Content Manager',
  'yourinfo_message' => 'This section shows some information about you:',
  'yourinfo_previous_login' => 'Your last login:',
  'yourinfo_title' => 'Your info',
  'yourinfo_total_logins' => 'Total number of logins:',
  'yourinfo_username' => 'You are logged in as:',
);