<?php  return array (
  'clear' => 'Clear',
  'error_log' => 'Error Log',
  'error_log_desc' => 'Here is the error log for MODX Revolution:',
  'error_log_download' => 'Download Error Log ([[+size]])',
  'error_log_too_large' => 'The error log at <em>[[+name]]</em> is too large to be viewed. You can download it via the button below.',
  'system_events' => 'System Events',
  'priority' => 'Priority',
);